"""Harmless owned-process/file fixtures only; no root, bus, VM or devices."""
import copy,hashlib,importlib.util,json,os,pathlib,signal,stat,subprocess,sys,tempfile,time
BASE=pathlib.Path('/tmp')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
F=load('family',BASE/'linuxcast-s003-root-proof-family.py');G=load('guest',BASE/'linuxcast-s003-root-proof-guest.py');C=load('control',BASE/'linuxcast-s003-root-proof-control.py')
assert os.getuid()!=0
checks={}
def denied(call):
 try:call()
 except (AssertionError,ValueError,TypeError,FileExistsError):return
 raise AssertionError('negative accepted')
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-offline-') as raw:
 root=pathlib.Path(raw);target=root/'unrelated';target.write_bytes(b'unchanged');link=root/'collision';link.symlink_to(target)
 journal=G.Journal()
 with F.Cancellation() as guard:denied(lambda:journal.create(link,b'new',guard=guard))
 assert target.read_bytes()==b'unchanged' and link.is_symlink() and journal.entries==[];checks['exclusiveCollisionPreserved']=True
 journal=G.Journal();a=root/'a';b=root/'b'
 with F.Cancellation() as guard:journal.create(a,b'a',guard=guard);journal.create(b,b'b',guard=guard)
 a.unlink();a.write_bytes(b'replacement')
 assert journal.cleanup()is False and a.read_bytes()==b'replacement' and not b.exists();checks['independentInodeCleanup']=True
 journal=G.Journal();partial=root/'partial';fsync=G.os.fsync
 def fault(fd):raise OSError()
 G.os.fsync=fault
 try:
  with F.Cancellation() as guard:denied(lambda:journal.create(partial,b'partial',guard=guard))
 except OSError:pass
 finally:G.os.fsync=fsync
 assert journal.cleanup() and not partial.exists();checks['partialWriteOwnedCleanup']=True
 # Exact critical-spawn method restores the pre-critical signal mask.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import signal;assert not signal.pthread_sigmask(signal.SIG_BLOCK,set()) & {signal.SIGTERM,signal.SIGHUP,signal.SIGINT};print('READY',flush=True);signal.pause()"],guard,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert p.stdout.readline()==b'READY\n';clean=family.stop()
  assert all(clean.values()) and p.returncode==-signal.SIGTERM
  p.stdout.close();p.stderr.close()
 checks['guardedSpawnMaskRestored']=True
 # Post-Popen bookkeeping failure cannot hide an internally owned process.
 family=F.Family();adopt=family.adopt
 def post_spawn_fault():adopt();raise RuntimeError()
 family.adopt=post_spawn_fault
 with F.Cancellation() as guard:
  try:family.spawn([sys.executable,'-I','-S','-c','import signal;signal.pause()'],guard)
  except RuntimeError:pass
  else:raise AssertionError()
  family.adopt=adopt;assert all(family.stop().values())
 checks['postSpawnFailureCleanup']=True
 # Already-exited leader leaves a real descendant; pidfd-group cleanup must
 # reach it instead of deciding the entire experiment ended with the leader.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import os,signal;pid=os.fork();os._exit(0) if pid else signal.pause()"],guard)
  end=time.monotonic()+1
  while family.exited(p.pid)is None and time.monotonic()<end:time.sleep(.005)
  assert family.exited(p.pid)==0;assert all(family.stop().values())
 checks['exitedLeaderDescendantCleanup']=True
 # Ordinary cancellation enters all independent owned-file cleanup steps.
 journal=G.Journal();marker=root/'marker';old=root/'old';old.write_bytes(b'old')
 with F.Cancellation() as guard:
  try:journal.create(marker,b'canary',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:guard.cleanup();ok=journal.cleanup()
 assert ok and not marker.exists() and old.read_bytes()==b'old';checks['ordinaryCancellationCleanup']=True
 # Bounded controller transport rejects flood without retaining raw output.
 try:C.command([sys.executable,'-I','-S','-c',"import sys;sys.stdout.write('X'*1000000)"],timeout=1)
 except AssertionError:pass
 else:raise AssertionError()
 checks['transportFloodBound']=True
# Schema rejects additional fields and private content, duplicate JSON keys,
# malformed rows, missing evidence and unsupported-as-success. No native run.
minimal={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootReport':{'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','failureCode':'ROOT_DENIAL_BOOTSTRAP_INCOMPLETE','wrapperGatePassed':False},'rootCapsuleRemoved':False,'bootstrapCancellationObserved':False,'complete':False}
C.validate(minimal)
for path in ('outer','root','row'):
 bad=copy.deepcopy(minimal)
 if path=='outer':bad['PrivateCanary']='/private/path'
 elif path=='root':bad['rootReport']['PrivateCanary']='/private/path'
 else:bad['rootReport']['actualRows']=[{'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'PrivateCanary','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}]
 denied(lambda:C.validate(bad))
bad=copy.deepcopy(minimal);bad['complete']=True;denied(lambda:C.validate(bad))
denied(lambda:C.strict('{"a":1,"a":2}'));denied(lambda:C.strict('{"a":NaN}'))
row={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'UNSUPPORTED','decisionVeto':'PENDING','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
bad=copy.deepcopy(minimal);bad['rootReport']['actualRows']=[row];C.validate(bad)
bad['complete']=True;denied(lambda:C.validate(bad));checks['strictPublicSchemaAndUnsupportedIncomplete']=True
goodrow={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'REMOTE','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
first=copy.deepcopy(goodrow);first['evidenceVeto']='PENDING';first['decisionVeto']='PENDING'
keys={'nativeOriginalsUnchanged','inputProgramsAbsent','graphicalSessionsAbsent','manufacturedDevicesAbsent','markerAbsent','privateDesktopRootsAbsent','guiProcessesAbsent','busBaselineUnchanged'}
good={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootCapsuleRemoved':True,'bootstrapCancellationObserved':False,'complete':True,'rootReport':{
 'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','preflight':dict.fromkeys(keys,True),'postflight':dict.fromkeys(keys,True),'runtime':{'distribution':'debian','debianVersion':'13.7','kernel':'6.12.113+deb13-amd64','architecture':'x86_64','libsystemdVersion':'257.13-1~deb13u1','pythonVersion':'3.13.5'},
 'supervisorSha256':G.PINS['linuxcast-input-spike-supervisor'],'helperSha256':G.PINS['linuxcast-input-spike-denial-helper'],'actualRows':[first]+[copy.deepcopy(goodrow) for _ in range(19)],'diagnostics':[],'actualRootDropProof':True,'ownConnectorPeerBound':True,'pdeathProofKind':'READY_REQUIRES_REVIEWED_HELPER_SELF_READBACK','directParentDeathTrialPerformed':False,'noInputBranchExecuted':True,'wrapperGatePassed':True,'nativeExitCode':0,'nativeElapsedMs':4751,
 'credentialProof':dict.fromkeys({'allUserIdsMatchExpected','allGroupIdsMatchPrimary','supplementalGroupsEmpty','capabilitiesAndAmbientEmpty','noNewPrivileges','coreSoftHardZero','descriptorCategoriesPrivate','helperExecutableHashMatches','helperParentBindingObserved','helperAliveDuringObservation'},True),
 'helperStartupSelfReadbacksEstablishedByReady':True,'cleanup':dict.fromkeys({'ownedChildrenAbsent','ownedGroupsAbsent','signalOperationsSucceeded','ownedObjectsRemoved','withinCleanupBudget'},True),'helperPathAbsent':True,'ownedLifetimeObservation':{'knownLive':1,'knownExitReady':1,'unknown':0,'knownReaped':0},'ownedStopElapsedMs':5,'criticalCleanupElapsedMs':6,'ordinaryCancellationObserved':False}}
C.validate(good)
for mutate in (
 lambda r:r.pop('runtime'),lambda r:r['credentialProof'].update({'capabilitiesAndAmbientEmpty':False}),lambda r:r['actualRows'][1].update({'decisionVeto':'PENDING'}),lambda r:r['actualRows'][1].update({'evidenceVeto':'UNSUPPORTED'}),lambda r:r.update({'ownedStopElapsedMs':2001}),lambda r:r.update({'directParentDeathTrialPerformed':True}),lambda r:r.update({'diagnostics':[{'component':'PrivateCanary','stage':'STARTUP','code':'PANIC','io_kind':None,'errno':None}]})):
 bad=copy.deepcopy(good);mutate(bad['rootReport']);denied(lambda:C.validate(bad))
checks['successRequiresActualNegativeAndCredentialEvidence']=True
# Exact post-fork own-child binding rejects another live same-UID connector.
import socket,select,contextlib,io,shlex,ast
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-peer-') as raw:
 listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);listener.bind(raw+'/peer');listener.listen(2);listener.settimeout(1)
 def child(parent):
  assert F.libc.prctl(1,signal.SIGKILL,0,0,0)==0 and os.getppid()==parent
  s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(raw+'/peer')
  while True:signal.pause()
 family=F.Family()
 with F.Cancellation() as guard:
  try:
   first=family.fork(child,guard);assert os.getpgid(first)==first
   accepted,_=listener.accept();G.own_peer(accepted,first,family,os.getuid())
   second=family.fork(child,guard);assert os.getpgid(second)==second
   wrong,_=listener.accept();denied(lambda:G.own_peer(wrong,first,family,os.getuid()))
   wrong.close();accepted.close()
  finally:guard.cleanup();assert all(family.stop().values());listener.close()
 checks['exactOwnPeerAndPreAdoptGroupBinding']=True
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cancel-') as raw:
 p=pathlib.Path(raw)/'owned';journal=G.Journal()
 with F.Cancellation() as guard:
  try:journal.create(p,b'owned',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:
   # These occur BEFORE the cleanup-state assignment, the formerly unsafe gap.
   for number in (signal.SIGHUP,signal.SIGTERM,signal.SIGINT,signal.SIGTERM):os.kill(os.getpid(),number)
   guard.cleanup();assert journal.cleanup()
 assert not p.exists();checks['repeatedCancellationCannotSkipFinally']=True
 # fdopen failure after O_EXCL must close the acquired descriptor too.
 before=len(os.listdir('/proc/self/fd'));original=G.os.fdopen;journal=G.Journal()
 def fdopen_fault(*args,**kwargs):raise OSError()
 G.os.fdopen=fdopen_fault
 try:
  with F.Cancellation() as guard:
   try:journal.create(p,b'owned',guard=guard)
   except OSError:pass
 finally:G.os.fdopen=original
 assert len(os.listdir('/proc/self/fd'))==before and journal.cleanup();checks['partialDescriptorAcquisitionClosed']=True
# Real harmless own executable with a synthetic proc directory avoids reading
# other users' host processes; tests the exact retention predicate and journal.
import types
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-exe-') as raw:
 root=pathlib.Path(raw);exe=root/'owned-sleep';journal=G.Journal()
 with F.Cancellation() as guard:journal.create(exe,pathlib.Path('/usr/bin/sleep').read_bytes(),guard=guard,executable=True)
 process=subprocess.Popen([str(exe),'2'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 fake=root/'proc';fake.mkdir();(fake/str(process.pid)).symlink_to('/proc/'+str(process.pid),target_is_directory=True)
 previous=G.pathlib;G.pathlib=types.SimpleNamespace(Path=lambda raw:fake if str(raw)=='/proc' else pathlib.Path(raw))
 try:
  assert G.executable_in_use(exe) and journal.cleanup()is False and exe.exists()
  process.kill();process.wait();assert journal.cleanup() and not exe.exists()
 finally:
  G.pathlib=previous
  if process.poll()is None:process.kill();process.wait()
 checks['actualOwnExecutableRetainedUntilDeathMockedProcNamespace']=True
# Controller-level TERM/HUP must stop its real CLI leader and descendant.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cli-') as raw:
 for index,number in enumerate((signal.SIGTERM,signal.SIGHUP)):
  ready=pathlib.Path(raw)/str(index)
  target="import json,os,pathlib,signal;pid=os.fork();\nif pid==0:signal.pause()\nelse:\n pathlib.Path("+repr(str(ready))+").write_text(json.dumps([os.getpid(),pid]));signal.pause()"
  script="import importlib.util,json,sys;s=importlib.util.spec_from_file_location('c','/tmp/linuxcast-s003-root-proof-control.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)\ntry:c.command([sys.executable,'-I','-S','-c',"+repr(target)+"],timeout=3)\nexcept BaseException:print('{\"cancelled\":true}',flush=True)"
  process=subprocess.Popen([sys.executable,'-I','-S','-c',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  handles=[]
  try:
   end=time.monotonic()+2
   while not ready.exists() and time.monotonic()<end:time.sleep(.005)
   assert ready.exists()
   for pid in json.loads(ready.read_text()):handles.append(os.pidfd_open(pid,0))
   for _ in range(4):os.kill(process.pid,number);time.sleep(.002)
   out,err=process.communicate(timeout=4);assert process.returncode==0 and out==b'{"cancelled":true}\n' and not err
   for fd in handles:
    poll=select.poll();poll.register(fd,select.POLLIN);assert poll.poll(100)
  finally:
   if process.poll()is None:process.kill();process.wait()
   for fd in handles:
    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
    except ProcessLookupError:pass
    os.close(fd)
 checks['fullTransportTermAndHupDescendantCleanup']=True
# Durable UNKNOWN intent is created before transport: a lost first reply may
# never cause a second dispatch, even with no first-result file written.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-attempt-') as raw:
 original=(C.STATE,C.local_gate,C.own_state,C.command);C.STATE=pathlib.Path(raw);calls=[]
 C.local_gate=lambda:'fixture';C.own_state=lambda:{'guest':'/not-executed','files':{}}
 def lost_reply(*args,**kwargs):calls.append(True);raise RuntimeError()
 C.command=lost_reply
 try:
  try:C.run()
  except RuntimeError:pass
  denied(C.run);assert len(calls)==1 and json.loads((C.STATE/'attempt.json').read_text())['outcome']=='UNKNOWN_BEFORE_DISPATCH'
 finally:C.STATE,C.local_gate,C.own_state,C.command=original
 checks['durableIntentPreventsSecondDispatch']=True
# Mocked transport only; actual ordinary private files exercise the exact
# generated partial-cleanup inode/hash logic with a synthetic /proc directory.
# No root preflight/query/copy is executed or counted as platform evidence.
from unittest import mock

def generated(code,data=None,proc_mock=False):
 # Execute unchanged generated guards on actual ordinary UID1000 files.
 # Only external /proc executable enumeration is synthetic, not UID/mode/
 # inode checks. The byte writer gets an actual bounded in-memory stdin.
 output=io.StringIO();old_stdin=sys.stdin;remaining=signal.alarm(0);status=0
 original_readlink=os.readlink
 def fixture_readlink(path,*args,**kwargs):
  if str(path).startswith('/proc/') and str(path).endswith('/exe'):return '/synthetic/not-a-staged-executable'
  return original_readlink(path,*args,**kwargs)
 try:
  if data is not None:sys.stdin=types.SimpleNamespace(buffer=io.BytesIO(data))
  with contextlib.redirect_stdout(output),mock.patch('os.readlink',side_effect=fixture_readlink) if proc_mock else contextlib.nullcontext():
   try:exec(compile(code,'exact-generated-uid1000-guard','exec'),{})
   except SystemExit as e:status=e.code
 finally:
  signal.alarm(0);sys.stdin=old_stdin
  if remaining:signal.alarm(remaining)
 return status,output.getvalue().encode()

class RemoteFixture:
 def __init__(self,root,fault):self.root=root;self.paths={};self.counter=0;self.fault=fault
 def call(self,argv,**kwargs):
  code=argv[-1] if argv[-2]=='-c' else shlex.split(argv[-1])[-1];answer=None;mutation=False
  if code.startswith('PATH='):
   values={node.targets[0].id:ast.literal_eval(node.value) for node in ast.parse(code).body[:6]}
   physical=self.paths[values['PATH']]
   revised=C.stage_cleanup_code(str(physical),values['IDENTITY'],values['FILES'],values['UID'],values['ENTRIES'],partial=values['PARTIAL'])
   status,output=generated(revised,proc_mock=True)
   result=subprocess.CompletedProcess(argv,status,output,b'');result.owned_cli_cleanup=True;return result
  tree=ast.parse(code)
  if kwargs.get('data')is not None:
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:5]};base,name=values['TARGET'].rsplit('/',1);path=self.paths[base]/name
   status,output=generated(C.write_code(str(path),values['IDENTITY'],values['EXPECTED_UID'],values['LENGTH'],values['WANTED']),kwargs['data'])
   assert status==0;answer=json.loads(output);mutation=True
  elif code.startswith('TARGET=') and 'GENERATED='in code:
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:3]}
   if values['GENERATED']:
    status,output=generated(C.directory_code(str(self.root),values['EXPECTED_UID'],generated=True));assert status==0
    physical,identity=json.loads(output);logical='/home/debian/linuxcast-s003-root-proof-fixture';self.paths[logical]=pathlib.Path(physical);answer=[logical,identity]
   else:
    logical=values['TARGET'];path=self.root/'container';status,output=generated(C.directory_code(str(path),values['EXPECTED_UID']));assert status==0
    self.paths[logical]=path;answer=json.loads(output)
   mutation=True
  elif code.startswith('DIRECTORY='):
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:4]}
   physical=self.paths[values['DIRECTORY']]
   status,output=generated(C.precreate_code(str(physical),values['IDENTITY'],values['NAME'],values['EXPECTED_UID']))
   assert status==0;answer=json.loads(output);mutation=True
  else:answer={'ready':True}
  if mutation:
   self.counter+=1
   if self.counter==self.fault:raise OSError()
  result=subprocess.CompletedProcess(argv,0,json.dumps(answer).encode(),b'');result.owned_cli_cleanup=True;return result
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-prepare-') as raw:
 root=pathlib.Path(raw);original=(C.STATE,C.local_gate,C.command,C.save,C.SOURCES)
 dummy=root/'dummy';dummy.write_bytes(b'public synthetic bytes')
 C.SOURCES={'collector.py':BASE/'linuxcast-s003-root-proof-guest.py','family.py':dummy,'linuxcast-input-spike-supervisor':dummy,'linuxcast-input-spike-denial-helper':dummy}
 C.local_gate=lambda:'mocked-fixed-manifest';cases=0
 try:
  healthy=root/'healthy';healthy.mkdir();C.STATE=healthy/'state';remote=RemoteFixture(healthy,0);C.command=remote.call
  with contextlib.redirect_stdout(io.StringIO()):C.prepare()
  state=json.loads((C.STATE/'state.json').read_bytes());assert C.CONTAINER_UID==C.GUEST_UID==os.getuid()==1000
  assert C.cleanup_stages(state)=={'guest':True,'container':True} and all(not p.exists() for p in remote.paths.values())
  checks['exactGeneratedUid1000HealthyPrepareAndCleanup']=True
  for remote_fault,save_fault,after in [(n,0,False) for n in range(1,19)]+[(0,n,a) for n in range(1,28) for a in (False,True)]:
   case=root/str(cases);case.mkdir();C.STATE=case/'state';remote=RemoteFixture(case,remote_fault);C.command=remote.call;count=[0]
   def save_faulted(value):
    count[0]+=1
    if count[0]==save_fault and not after:raise OSError()
    original[3](value)
    if count[0]==save_fault and after:raise OSError()
   C.save=save_faulted
   try:
    with contextlib.redirect_stdout(io.StringIO()):C.prepare()
   except OSError:pass
   cleanup=json.loads((C.STATE/'prepare-cleanup.json').read_text());remaining=any(p.exists() for p in remote.paths.values())
   assert cleanup['prepareComplete']is False and (not remaining or cleanup['retainedResources']is True)
   if not cleanup['retainedResources']:assert not remaining
   cases+=1
 finally:C.STATE,C.local_gate,C.command,C.save,C.SOURCES=original
 assert cases==72;checks['mockedPrepare72AcquisitionAndStateFaults']=True
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-uid-contract-') as raw:
 root=pathlib.Path(raw);directory=root/'stage'
 # Both exact generated directory guards reject UID0 BEFORE mkdir/mkdtemp,
 # not merely before later file creation. No UID function is mocked.
 for generated_directory,target in ((False,directory),(True,root)):
  before=set(root.iterdir())
  denied(lambda:generated(C.directory_code(str(target),0,generated=generated_directory)))
  assert set(root.iterdir())==before and not directory.exists()
 status,output=generated(C.directory_code(str(directory),1000));assert status==0;identity=json.loads(output)
 status,output=generated(C.directory_code(str(root),1000,generated=True));assert status==0
 temporary,temporary_id=json.loads(output);temporary=pathlib.Path(temporary)
 assert temporary.parent==root and temporary.stat().st_uid==1000 and temporary.stat().st_mode & 0o777==0o700
 status,output=generated(C.stage_cleanup_code(str(temporary),temporary_id,{},1000,{}),proc_mock=True);assert status==0 and not temporary.exists()
 checks['bothDirectoryGuardsRejectWrongUidBeforeCreation']=True
 try:generated(C.precreate_code(str(directory),identity,'collector.py',0))
 except AssertionError:pass
 else:raise AssertionError('wrong UID accepted')
 assert list(directory.iterdir())==[]
 status,output=generated(C.precreate_code(str(directory),identity,'collector.py',1000));assert status==0;file_id=json.loads(output)
 data=b'fixed public bytes';wanted=hashlib.sha256(data).hexdigest()
 status,output=generated(C.write_code(str(directory/'collector.py'),file_id,1000,len(data),wanted),data);assert status==0 and (directory/'collector.py').read_bytes()==data and (directory/'collector.py').stat().st_uid==1000
 entries={'collector.py':{'identity':file_id,'complete':True}};files={'collector.py':wanted}
 try:generated(C.stage_cleanup_code(str(directory),identity,files,0,entries),proc_mock=True)
 except AssertionError:pass
 else:raise AssertionError('wrong UID cleanup accepted')
 assert directory.exists() and (directory/'collector.py').read_bytes()==data
 status,output=generated(C.stage_cleanup_code(str(directory),identity,files,1000,entries),proc_mock=True);assert status==0 and not directory.exists()
 checks['wrongUidZeroRejectedBeforeCreateAndCleanup']=True
# Strict integers reject booleans at both version positions.
for key in ('outer','root'):
 bad=copy.deepcopy(minimal)
 if key=='outer':bad['schemaVersion']=True
 else:bad['rootReport']['schemaVersion']=True
 denied(lambda:C.validate(bad))
checks['booleanSchemaVersionsRejected']=True
# Parse-only all fixed remote bootstrap/preflight/release code; execute none.
compile('STAGE="/private/notexecuted"\nPINS={}\n'+C.BOOTSTRAP,'bootstrap','exec')
compile(C.preflight_code(),'preflight','exec')
compile(C.stage_cleanup_code('/private/notexecuted',[1,2],{},1000,{}),'release','exec')
checks['remoteCodeSyntaxOnly']=True
# Helper installation mode: actual ordinary555 execution/readback negatives,
# plus explicitly mocked root metadata. This is NOT actual root-drop proof.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-helper-mode-') as raw:
 root=pathlib.Path(raw);exe=root/'owned-benign';journal=G.Journal();data=b'#!/bin/sh\nexit 0\n'
 previous_umask=os.umask(0o077)
 try:
  with F.Cancellation() as guard:journal.create(exe,data,mode=G.HELPER_INSTALL_MODE,guard=guard,executable=True)
 finally:os.umask(previous_umask)
 info=exe.stat();assert stat.S_IMODE(info.st_mode)==0o555 and subprocess.run([str(exe)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 identity=(info.st_dev,info.st_ino);wanted=hashlib.sha256(data).hexdigest()
 denied(lambda:G.verify_installed_helper(exe,identity,wanted)) # actual UID1000 owner is NOT root
 # Fixed mocked UID0 on the actual opened inode exercises exact bytes/hash,
 # identity and fd closure; this remains explicitly simulated root metadata.
 root_fields=list(info);root_fields[4]=0;root_info=os.stat_result(root_fields)
 before_fds=len(os.listdir('/proc/self/fd'))
 with mock.patch.object(G.os,'fstat',return_value=root_info):
  G.verify_installed_helper(exe,identity,wanted)
  denied(lambda:G.verify_installed_helper(exe,identity,'0'*64))
  denied(lambda:G.verify_installed_helper(exe,(identity[0],identity[1]+1),wanted))
 assert len(os.listdir('/proc/self/fd'))==before_fds
 link=root/'symlink';link.symlink_to(exe)
 try:G.verify_installed_helper(link,identity,wanted)
 except OSError:pass
 else:raise AssertionError('symlink accepted')
 link.unlink()
 metadata=types.SimpleNamespace(st_dev=1,st_ino=2,st_mode=stat.S_IFREG|0o555,st_uid=0,st_nlink=1,st_size=100)
 G.helper_install_metadata(metadata,(1,2))
 for key,value in [('st_uid',1000),('st_nlink',2),('st_mode',stat.S_IFREG|0o500),('st_mode',stat.S_IFREG|0o755),('st_mode',stat.S_IFREG|0o4555),('st_ino',3)]:
  invalid=copy.copy(metadata);setattr(invalid,key,value);denied(lambda:G.helper_install_metadata(invalid,(1,2)))
 fake_proc=root/'proc';fake_proc.mkdir()
 previous=G.pathlib;G.pathlib=types.SimpleNamespace(Path=lambda raw:fake_proc if str(raw)=='/proc'else pathlib.Path(raw))
 try:assert journal.cleanup()
 finally:G.pathlib=previous
 checks['helper555ActualOrdinaryExecAndMockedRootMetadata']=True
# Execute actual collect() stage assignment/except code with a wholly mocked
# authority/native backend, injecting one failure at EACH exact13boundary.
# No root credentials, libsystemd, process spawn, device or live query happens.
assert G.FAILURE_STAGES==C.FAILURE_STAGES and len(G.FAILURE_STAGES)==13
with tempfile.TemporaryDirectory(prefix='linuxcast-root-stage-faults-') as raw:
 root=pathlib.Path(raw);real_listdir=os.listdir
 for target in sorted(G.FAILURE_STAGES):
  case=root/target;case.mkdir();native=case/'native';native.mkdir();directory=case/'peer-dir'
  class Journal:
   def __init__(self):self.entries=[]
   def create(self,*args,**kwargs):
    if target=='INSTALL_HELPER':raise OSError('PrivateCanaryMustNeverExport')
    self.entries.append((args[0],(1,2),'executable',None))
   def own(self,p,*args):return p
   def cleanup(self):return True
  class Stream:
   def fileno(self):return 7
   def bind(self,p):pathlib.Path(p).write_bytes(b'')
   def listen(self,*a):pass
   def settimeout(self,*a):pass
   def accept(self):
    if target=='ACCEPT_CONNECTOR':raise OSError('PrivateCanaryMustNeverExport')
    return Stream(),None
   def close(self):pass
   def sendmsg(self,*a):
    if target=='SEND_BOOTSTRAP':raise OSError('PrivateCanaryMustNeverExport')
    return 1
  class Family:
   def fork(self,*a):
    if target=='FORK_CONNECTOR':raise OSError('PrivateCanaryMustNeverExport')
    return 1
   def spawn(self,*a,**kw):
    if target=='SPAWN_SUPERVISOR':raise OSError('PrivateCanaryMustNeverExport')
    return types.SimpleNamespace(pid=2,stdout=Stream(),stderr=Stream())
   def alive(self,*a):return True
   def exited(self,*a):return 0
   def observation(self):return {'knownLive':0,'knownExitReady':0,'unknown':0,'knownReaped':0}
   def stop(self,*a):return dict.fromkeys(('ownedChildrenAbsent','ownedGroupsAbsent','signalOperationsSucceeded'),True)
  class Selector:
   def register(self,*a):pass
   def select(self,*a):return [(types.SimpleNamespace(data='stdout',fd=7),None)] if target=='READ_HELPER_PROOF'else []
   def get_map(self):return {}
   def close(self):pass
  def make_directory(*a,**kw):
   if target=='CREATE_PEER_DIRECTORY':raise OSError('PrivateCanaryMustNeverExport')
   directory.mkdir();return str(directory)
  def socket(*a,**kw):
   if target=='BIND_LISTENER':raise OSError('PrivateCanaryMustNeverExport')
   return Stream()
  def own_peer(*a):
   if target=='BIND_OWN_PEER':raise OSError('PrivateCanaryMustNeverExport')
  def pair(*a):
   if target=='CREATE_PARENT_CHANNEL':raise OSError('PrivateCanaryMustNeverExport')
   return Stream(),Stream()
  def dup(*a,**kw):
   if target=='RESERVE_PARENT_FD':raise OSError('PrivateCanaryMustNeverExport')
  def selector():
   if target=='OBSERVE_NATIVE':raise OSError('PrivateCanaryMustNeverExport')
   return Selector()
  def proof(*a):raise OSError('PrivateCanaryMustNeverExport')
  def trusted(path,mode=None):return types.SimpleNamespace(st_mode=(stat.S_IFREG if mode==0o500 else stat.S_IFDIR)|(mode or 0o755))
  output=io.StringIO()
  with contextlib.ExitStack() as stack:
   patches=[(G,'__file__',str(native/'linuxcast-s003-root-proof-capsule'/'collector.py')),(G,'NATIVE',native),(G,'Journal',Journal),(G,'Family',Family),(G,'trusted',trusted),(G,'digest',lambda p:G.PINS[p.name]),(G,'verified_bytes',lambda *a:b'public'),(G,'verify_installed_helper',lambda *a:None),(G,'runtime',lambda:{}),(G,'baseline',lambda:dict.fromkeys(keys,True)),(G,'read',lambda *a:'13.7'),(G,'own_peer',own_peer),(G,'proc_proof',proof),(G.sys,'argv',['collector','--collect']),(G.os,'getresuid',lambda:(0,0,0)),(G.os,'listdir',lambda p:[] if p=='/proc/self/fd'else real_listdir(p)),(G.os,'uname',lambda:types.SimpleNamespace(release='6.12.113+deb13-amd64')),(G.os,'chown',lambda *a:None),(G.os,'dup2',dup),(G.os,'set_blocking',lambda *a:None),(G.os,'statvfs',lambda *a:types.SimpleNamespace(f_flag=0)),(G.os,'read',lambda *a:(json.dumps(goodrow)+'\n').encode()),(G.pwd,'getpwnam',lambda *a:types.SimpleNamespace(pw_uid=1000,pw_gid=1000)),(G.tempfile,'mkdtemp',make_directory),(G.socket,'socket',socket),(G.socket,'socketpair',pair),(G.fcntl,'fcntl',lambda *a:64),(G.selectors,'DefaultSelector',selector)]
   for obj,name,value in patches:stack.enter_context(mock.patch.object(obj,name,value))
   with contextlib.redirect_stdout(output):assert G.collect()==3
  report=json.loads(output.getvalue());assert report['failureStage']==target and report['failureCode']=='ROOT_DENIAL_OBSERVATION_INCOMPLETE' and 'PrivateCanary'not in output.getvalue(),(target,report.get('failureStage'))
  outer=copy.deepcopy(minimal);outer['rootReport']={'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','failureCode':'ROOT_DENIAL_OBSERVATION_INCOMPLETE','failureStage':target,'wrapperGatePassed':False};C.validate(outer)
 checks['exactCollect13MockedStageFaultsNoPrivateError']=True
 for value in ('PrivateCanary',True,None,13,{'private':'payload'}):
  bad=copy.deepcopy(outer);bad['rootReport']['failureStage']=value;denied(lambda:C.validate(bad))
 bad=copy.deepcopy(outer);bad['rootReport'].pop('failureStage');denied(lambda:C.validate(bad))
 bad=copy.deepcopy(good);bad['rootReport']['failureStage']='INSTALL_HELPER';denied(lambda:C.validate(bad))
 checks['incompleteStageStrictSchemaAndNoSuccessStage']=True
assert str(C.STATE)=='/tmp/linuxcast-s003-root-proof-control-native-capsule'
checks['newVersionedStatePreservesBothHistoricalFailures']=True

# Exact BOOTSTRAP guards and creation block on ordinary private directories;
# UID0/statvfs are explicit mocks, never actual root/mount/VM/native evidence.
with tempfile.TemporaryDirectory(prefix='linuxcast-capsule-guards-') as raw:
 root=pathlib.Path(raw);opt=root/'opt';opt.mkdir(mode=0o755);native=opt/'linuxcast-input-spike';native.mkdir(mode=0o755);run=root/'run';run.mkdir()
 real_lstat=pathlib.Path.lstat;real_mkdtemp=tempfile.mkdtemp;calls=[];flags={'parent':0,'capsule':0};mock_owner=[True]
 def path(value):return opt if str(value)=='/opt'else native if str(value)=='/opt/linuxcast-input-spike'else run if str(value)=='/run'else pathlib.Path(value)
 def lstat(p,*args,**kwargs):
  value=real_lstat(p,*args,**kwargs)
  if mock_owner[0]and(p==opt or p==native or p.parent==native):
   fields=list(value);fields[4]=0;return os.stat_result(fields)
  return value
 def statvfs(p):return types.SimpleNamespace(f_flag=flags['parent']if pathlib.Path(p)==native else flags['capsule'])
 def mkdirtemp(*args,**kwargs):
  calls.append(True);assert kwargs['dir']=='/opt/linuxcast-input-spike'
  return real_mkdtemp(prefix=kwargs['prefix'],dir=native)
 bootstrap=ast.parse(C.BOOTSTRAP);guards=[n for n in bootstrap.body if isinstance(n,ast.FunctionDef)and n.name in {'execution_parent_identity','execution_capsule_identity'}]
 acquisition=next(n for n in ast.walk(bootstrap)if isinstance(n,ast.With)and any(isinstance(a,ast.Call)and isinstance(a.func,ast.Attribute)and a.func.attr=='mkdtemp'for a in ast.walk(n)))
 namespace={'pathlib':types.SimpleNamespace(Path=path),'os':types.SimpleNamespace(statvfs=statvfs,ST_NOEXEC=os.ST_NOEXEC),'stat':stat,'tempfile':types.SimpleNamespace(mkdtemp=mkdirtemp)}
 exec(compile(ast.Module(body=guards,type_ignores=[]),'exact-bootstrap-guards','exec'),namespace)
 create=compile(ast.Module(body=acquisition.body,type_ignores=[]),'exact-bootstrap-acquisition','exec')
 with mock.patch.object(pathlib.Path,'lstat',lstat):
  # Noexec/unknown/wrong-owner/symlink/writable checks happen BEFORE mkdir.
  for kind in ('noexec','unknown','owner','symlink','write'):
   calls.clear();flags['parent']=os.ST_NOEXEC if kind=='noexec'else 0;mock_owner[0]=kind!='owner'
   if kind=='unknown':del namespace['os'].ST_NOEXEC
   if kind=='write':native.chmod(0o777)
   if kind=='symlink':native.rename(opt/'saved');native.symlink_to(opt/'saved',target_is_directory=True)
   try:exec(create,namespace)
   except (AssertionError,AttributeError):pass
   else:raise AssertionError('unsafe parent accepted')
   assert calls==[]
   if kind=='unknown':namespace['os'].ST_NOEXEC=os.ST_NOEXEC
   if kind=='write':native.chmod(0o755)
   if kind=='symlink':native.unlink();(opt/'saved').rename(native)
  mock_owner[0]=True;flags['parent']=0;flags['capsule']=0;calls.clear();exec(create,namespace)
  capsule=namespace['root'];identity=namespace['root_id'];actual=real_lstat(capsule)
  assert len(calls)==1 and capsule.parent==native and actual.st_uid==os.getuid()==1000 and stat.S_IMODE(actual.st_mode)==0o700 and (actual.st_dev,actual.st_ino)==identity
  capsule.rmdir();checks['exactBootstrapTrustedParentAndOrdinaryCapsuleMockRoot']=True
  flags['capsule']=os.ST_NOEXEC;calls.clear()
  try:exec(create,namespace)
  except AssertionError:pass
  else:raise AssertionError('noexec capsule accepted')
  capsule=namespace['root'];assert len(calls)==1 and namespace['root_id']==(real_lstat(capsule).st_dev,real_lstat(capsule).st_ino);capsule.rmdir();flags['capsule']=0
  # Changed parent identity after acquisition cannot advance to copies/exec.
  original=namespace['execution_parent_identity'];count=[0]
  def changed_parent():
   count[0]+=1;value=original();return value if count[0]==1 else(value[0],value[1]+1)
  namespace['execution_parent_identity']=changed_parent
  try:exec(create,namespace)
  except AssertionError:pass
  else:raise AssertionError('changed parent accepted')
  namespace['execution_parent_identity']=original;capsule=namespace['root'];assert namespace['root_id']==(real_lstat(capsule).st_dev,real_lstat(capsule).st_ino);capsule.rmdir()
  checks['parentAndCapsuleNoExecUnknownAndIdentityDenyBeforeEffects']=True
  # Exact generated preflight guard/ready expression: parent and BOTH capsule
  # locations plus actual regular/dangling helper paths. Runtime is synthetic.
  preflight=ast.parse(C.preflight_code());ready=next(n for n in preflight.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ready'for t in n.targets))
  predicate=compile(ast.Expression(ready.value),'exact-ready-both-capsule-roots','eval')
  environment={**namespace,'NATIVE':native,'b':dict.fromkeys(keys,True),'parent_ready':True,'read':lambda *_:'13.7'}
  environment['os']=types.SimpleNamespace(uname=lambda:types.SimpleNamespace(release='6.12.113+deb13-amd64'))
  assert eval(predicate,environment)is True
  for location,kind in ((run,'directory'),(run,'dangling'),(native,'directory'),(native,'dangling')):
   leftover=location/'linuxcast-s003-root-proof-leftover'
   if kind=='directory':leftover.mkdir()
   else:leftover.symlink_to(location/'absent')
   assert eval(predicate,environment)is False
   if kind=='directory':leftover.rmdir()
   else:leftover.unlink()
  helper=native/'linuxcast-input-spike-denial-helper'
  helper.write_bytes(b'synthetic');assert eval(predicate,environment)is False;helper.unlink()
  helper.symlink_to(native/'absent');assert eval(predicate,environment)is False;helper.unlink()
  environment['parent_ready']=False;assert eval(predicate,environment)is False
  checks['exactReadyRejectsOldRunNewNativeAndDanglingCapsules']=True
 # Actual native spawn code has the mount check immediately before spawn,
 # after fixed stage assignment; extract and deny without a process call.
 tree=ast.parse(G.collect.__code__.co_filename and (BASE/'linuxcast-s003-root-proof-guest.py').read_text())
 collect=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='collect')
 body=next(n for n in ast.walk(collect)if isinstance(n,ast.Try)and any(isinstance(x,ast.Expr)and isinstance(x.value,ast.Call)and isinstance(x.value.func,ast.Name)and x.value.func.id=='verify_installed_helper'for x in n.body)).body
 spawn=next(i for i,n in enumerate(body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='process'for t in n.targets))
 check=body[spawn-1];assert isinstance(check,ast.Assert)and 'statvfs'in ast.unparse(check)
 deny=compile(ast.Module(body=[check],type_ignores=[]),'exact-pre-spawn-mount-guard','exec')
 try:exec(deny,{'os':types.SimpleNamespace(statvfs=lambda *_:types.SimpleNamespace(f_flag=os.ST_NOEXEC),ST_NOEXEC=os.ST_NOEXEC),'capsule':native})
 except AssertionError:pass
 else:raise AssertionError('native spawn noexec guard accepted')
 checks['exactPreSpawnCapsuleMountDeniesWithoutProcessExecution']=True

print(json.dumps({'schemaVersion':1,'privateHarmlessFixtures':checks,'allPassed':all(checks.values()),'rootExecutions':0,'liveQueries':0,'vmCalls':0,'deviceOperations':0},sort_keys=True))
