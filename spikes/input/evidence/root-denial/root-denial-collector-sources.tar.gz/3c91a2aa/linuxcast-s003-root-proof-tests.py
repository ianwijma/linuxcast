"""Harmless owned-process/file fixtures only; no root, bus, VM or devices."""
import copy,importlib.util,json,os,pathlib,signal,subprocess,sys,tempfile,time
BASE=pathlib.Path('/tmp')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
F=load('family',BASE/'linuxcast-s003-root-proof-family.py');G=load('guest',BASE/'linuxcast-s003-root-proof-guest.py');C=load('control',BASE/'linuxcast-s003-root-proof-control.py')
assert os.getuid()!=0
checks={}
def denied(call):
 try:call()
 except (AssertionError,ValueError,TypeError,FileExistsError):return
 raise AssertionError('negative accepted')
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-offline-') as raw:
 root=pathlib.Path(raw);target=root/'unrelated';target.write_bytes(b'unchanged');link=root/'collision';link.symlink_to(target)
 journal=G.Journal()
 with F.Cancellation() as guard:denied(lambda:journal.create(link,b'new',guard=guard))
 assert target.read_bytes()==b'unchanged' and link.is_symlink() and journal.entries==[];checks['exclusiveCollisionPreserved']=True
 journal=G.Journal();a=root/'a';b=root/'b'
 with F.Cancellation() as guard:journal.create(a,b'a',guard=guard);journal.create(b,b'b',guard=guard)
 a.unlink();a.write_bytes(b'replacement')
 assert journal.cleanup()is False and a.read_bytes()==b'replacement' and not b.exists();checks['independentInodeCleanup']=True
 journal=G.Journal();partial=root/'partial';fsync=G.os.fsync
 def fault(fd):raise OSError()
 G.os.fsync=fault
 try:
  with F.Cancellation() as guard:denied(lambda:journal.create(partial,b'partial',guard=guard))
 except OSError:pass
 finally:G.os.fsync=fsync
 assert journal.cleanup() and not partial.exists();checks['partialWriteOwnedCleanup']=True
 # Exact critical-spawn method restores the pre-critical signal mask.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import signal;assert not signal.pthread_sigmask(signal.SIG_BLOCK,set()) & {signal.SIGTERM,signal.SIGHUP,signal.SIGINT};print('READY',flush=True);signal.pause()"],guard,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert p.stdout.readline()==b'READY\n';clean=family.stop()
  assert all(clean.values()) and p.returncode==-signal.SIGTERM
  p.stdout.close();p.stderr.close()
 checks['guardedSpawnMaskRestored']=True
 # Post-Popen bookkeeping failure cannot hide an internally owned process.
 family=F.Family();adopt=family.adopt
 def post_spawn_fault():adopt();raise RuntimeError()
 family.adopt=post_spawn_fault
 with F.Cancellation() as guard:
  try:family.spawn([sys.executable,'-I','-S','-c','import signal;signal.pause()'],guard)
  except RuntimeError:pass
  else:raise AssertionError()
  family.adopt=adopt;assert all(family.stop().values())
 checks['postSpawnFailureCleanup']=True
 # Already-exited leader leaves a real descendant; pidfd-group cleanup must
 # reach it instead of deciding the entire experiment ended with the leader.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import os,signal;pid=os.fork();os._exit(0) if pid else signal.pause()"],guard)
  end=time.monotonic()+1
  while family.exited(p.pid)is None and time.monotonic()<end:time.sleep(.005)
  assert family.exited(p.pid)==0;assert all(family.stop().values())
 checks['exitedLeaderDescendantCleanup']=True
 # Ordinary cancellation enters all independent owned-file cleanup steps.
 journal=G.Journal();marker=root/'marker';old=root/'old';old.write_bytes(b'old')
 with F.Cancellation() as guard:
  try:journal.create(marker,b'canary',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:guard.cleanup();ok=journal.cleanup()
 assert ok and not marker.exists() and old.read_bytes()==b'old';checks['ordinaryCancellationCleanup']=True
 # Bounded controller transport rejects flood without retaining raw output.
 try:C.command([sys.executable,'-I','-S','-c',"import sys;sys.stdout.write('X'*1000000)"],timeout=1)
 except AssertionError:pass
 else:raise AssertionError()
 checks['transportFloodBound']=True
# Schema rejects additional fields and private content, duplicate JSON keys,
# malformed rows, missing evidence and unsupported-as-success. No native run.
minimal={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootReport':{'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','failureCode':'ROOT_DENIAL_BOOTSTRAP_INCOMPLETE','wrapperGatePassed':False},'rootCapsuleRemoved':False,'bootstrapCancellationObserved':False,'complete':False}
C.validate(minimal)
for path in ('outer','root','row'):
 bad=copy.deepcopy(minimal)
 if path=='outer':bad['PrivateCanary']='/private/path'
 elif path=='root':bad['rootReport']['PrivateCanary']='/private/path'
 else:bad['rootReport']['actualRows']=[{'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'PrivateCanary','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}]
 denied(lambda:C.validate(bad))
bad=copy.deepcopy(minimal);bad['complete']=True;denied(lambda:C.validate(bad))
denied(lambda:C.strict('{"a":1,"a":2}'));denied(lambda:C.strict('{"a":NaN}'))
row={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'UNSUPPORTED','decisionVeto':'PENDING','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
bad=copy.deepcopy(minimal);bad['rootReport']['actualRows']=[row];C.validate(bad)
bad['complete']=True;denied(lambda:C.validate(bad));checks['strictPublicSchemaAndUnsupportedIncomplete']=True
goodrow={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'REMOTE','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
first=copy.deepcopy(goodrow);first['evidenceVeto']='PENDING';first['decisionVeto']='PENDING'
keys={'nativeOriginalsUnchanged','inputProgramsAbsent','graphicalSessionsAbsent','manufacturedDevicesAbsent','markerAbsent','privateDesktopRootsAbsent','guiProcessesAbsent','busBaselineUnchanged'}
good={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootCapsuleRemoved':True,'bootstrapCancellationObserved':False,'complete':True,'rootReport':{
 'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','preflight':dict.fromkeys(keys,True),'postflight':dict.fromkeys(keys,True),'runtime':{'distribution':'debian','debianVersion':'13.7','kernel':'6.12.113+deb13-amd64','architecture':'x86_64','libsystemdVersion':'257.13-1~deb13u1','pythonVersion':'3.13.5'},
 'supervisorSha256':G.PINS['linuxcast-input-spike-supervisor'],'helperSha256':G.PINS['linuxcast-input-spike-denial-helper'],'actualRows':[first]+[copy.deepcopy(goodrow) for _ in range(19)],'diagnostics':[],'actualRootDropProof':True,'ownConnectorPeerBound':True,'pdeathProofKind':'READY_REQUIRES_REVIEWED_HELPER_SELF_READBACK','directParentDeathTrialPerformed':False,'noInputBranchExecuted':True,'wrapperGatePassed':True,'nativeExitCode':0,'nativeElapsedMs':4751,
 'credentialProof':dict.fromkeys({'allUserIdsMatchExpected','allGroupIdsMatchPrimary','supplementalGroupsEmpty','capabilitiesAndAmbientEmpty','noNewPrivileges','coreSoftHardZero','descriptorCategoriesPrivate','helperExecutableHashMatches','helperParentBindingObserved','helperAliveDuringObservation'},True),
 'helperStartupSelfReadbacksEstablishedByReady':True,'cleanup':dict.fromkeys({'ownedChildrenAbsent','ownedGroupsAbsent','signalOperationsSucceeded','ownedObjectsRemoved','withinCleanupBudget'},True),'helperPathAbsent':True,'ownedLifetimeObservation':{'knownLive':1,'knownExitReady':1,'unknown':0,'knownReaped':0},'ownedStopElapsedMs':5,'criticalCleanupElapsedMs':6,'ordinaryCancellationObserved':False}}
C.validate(good)
for mutate in (
 lambda r:r.pop('runtime'),lambda r:r['credentialProof'].update({'capabilitiesAndAmbientEmpty':False}),lambda r:r['actualRows'][1].update({'decisionVeto':'PENDING'}),lambda r:r['actualRows'][1].update({'evidenceVeto':'UNSUPPORTED'}),lambda r:r.update({'ownedStopElapsedMs':2001}),lambda r:r.update({'directParentDeathTrialPerformed':True}),lambda r:r.update({'diagnostics':[{'component':'PrivateCanary','stage':'STARTUP','code':'PANIC','io_kind':None,'errno':None}]})):
 bad=copy.deepcopy(good);mutate(bad['rootReport']);denied(lambda:C.validate(bad))
checks['successRequiresActualNegativeAndCredentialEvidence']=True
# Exact post-fork own-child binding rejects another live same-UID connector.
import socket,select,contextlib,io,shlex,ast
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-peer-') as raw:
 listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);listener.bind(raw+'/peer');listener.listen(2);listener.settimeout(1)
 def child(parent):
  assert F.libc.prctl(1,signal.SIGKILL,0,0,0)==0 and os.getppid()==parent
  s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(raw+'/peer')
  while True:signal.pause()
 family=F.Family()
 with F.Cancellation() as guard:
  try:
   first=family.fork(child,guard);assert os.getpgid(first)==first
   accepted,_=listener.accept();G.own_peer(accepted,first,family,os.getuid())
   second=family.fork(child,guard);assert os.getpgid(second)==second
   wrong,_=listener.accept();denied(lambda:G.own_peer(wrong,first,family,os.getuid()))
   wrong.close();accepted.close()
  finally:guard.cleanup();assert all(family.stop().values());listener.close()
 checks['exactOwnPeerAndPreAdoptGroupBinding']=True
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cancel-') as raw:
 p=pathlib.Path(raw)/'owned';journal=G.Journal()
 with F.Cancellation() as guard:
  try:journal.create(p,b'owned',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:
   # These occur BEFORE the cleanup-state assignment, the formerly unsafe gap.
   for number in (signal.SIGHUP,signal.SIGTERM,signal.SIGINT,signal.SIGTERM):os.kill(os.getpid(),number)
   guard.cleanup();assert journal.cleanup()
 assert not p.exists();checks['repeatedCancellationCannotSkipFinally']=True
 # fdopen failure after O_EXCL must close the acquired descriptor too.
 before=len(os.listdir('/proc/self/fd'));original=G.os.fdopen;journal=G.Journal()
 def fdopen_fault(*args,**kwargs):raise OSError()
 G.os.fdopen=fdopen_fault
 try:
  with F.Cancellation() as guard:
   try:journal.create(p,b'owned',guard=guard)
   except OSError:pass
 finally:G.os.fdopen=original
 assert len(os.listdir('/proc/self/fd'))==before and journal.cleanup();checks['partialDescriptorAcquisitionClosed']=True
# Real harmless own executable with a synthetic proc directory avoids reading
# other users' host processes; tests the exact retention predicate and journal.
import types
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-exe-') as raw:
 root=pathlib.Path(raw);exe=root/'owned-sleep';journal=G.Journal()
 with F.Cancellation() as guard:journal.create(exe,pathlib.Path('/usr/bin/sleep').read_bytes(),guard=guard,executable=True)
 process=subprocess.Popen([str(exe),'2'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 fake=root/'proc';fake.mkdir();(fake/str(process.pid)).symlink_to('/proc/'+str(process.pid),target_is_directory=True)
 previous=G.pathlib;G.pathlib=types.SimpleNamespace(Path=lambda raw:fake if str(raw)=='/proc' else pathlib.Path(raw))
 try:
  assert G.executable_in_use(exe) and journal.cleanup()is False and exe.exists()
  process.kill();process.wait();assert journal.cleanup() and not exe.exists()
 finally:
  G.pathlib=previous
  if process.poll()is None:process.kill();process.wait()
 checks['actualOwnExecutableRetainedUntilDeathMockedProcNamespace']=True
# Controller-level TERM/HUP must stop its real CLI leader and descendant.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cli-') as raw:
 for index,number in enumerate((signal.SIGTERM,signal.SIGHUP)):
  ready=pathlib.Path(raw)/str(index)
  target="import json,os,pathlib,signal;pid=os.fork();\nif pid==0:signal.pause()\nelse:\n pathlib.Path("+repr(str(ready))+").write_text(json.dumps([os.getpid(),pid]));signal.pause()"
  script="import importlib.util,json,sys;s=importlib.util.spec_from_file_location('c','/tmp/linuxcast-s003-root-proof-control.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)\ntry:c.command([sys.executable,'-I','-S','-c',"+repr(target)+"],timeout=3)\nexcept BaseException:print('{\"cancelled\":true}',flush=True)"
  process=subprocess.Popen([sys.executable,'-I','-S','-c',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  handles=[]
  try:
   end=time.monotonic()+2
   while not ready.exists() and time.monotonic()<end:time.sleep(.005)
   assert ready.exists()
   for pid in json.loads(ready.read_text()):handles.append(os.pidfd_open(pid,0))
   for _ in range(4):os.kill(process.pid,number);time.sleep(.002)
   out,err=process.communicate(timeout=4);assert process.returncode==0 and out==b'{"cancelled":true}\n' and not err
   for fd in handles:
    poll=select.poll();poll.register(fd,select.POLLIN);assert poll.poll(100)
  finally:
   if process.poll()is None:process.kill();process.wait()
   for fd in handles:
    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
    except ProcessLookupError:pass
    os.close(fd)
 checks['fullTransportTermAndHupDescendantCleanup']=True
# Durable UNKNOWN intent is created before transport: a lost first reply may
# never cause a second dispatch, even with no first-result file written.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-attempt-') as raw:
 original=(C.STATE,C.local_gate,C.own_state,C.command);C.STATE=pathlib.Path(raw);calls=[]
 C.local_gate=lambda:'fixture';C.own_state=lambda:{'guest':'/not-executed','files':{}}
 def lost_reply(*args,**kwargs):calls.append(True);raise RuntimeError()
 C.command=lost_reply
 try:
  try:C.run()
  except RuntimeError:pass
  denied(C.run);assert len(calls)==1 and json.loads((C.STATE/'attempt.json').read_text())['outcome']=='UNKNOWN_BEFORE_DISPATCH'
 finally:C.STATE,C.local_gate,C.own_state,C.command=original
 checks['durableIntentPreventsSecondDispatch']=True
# Mocked transport only; actual ordinary private files exercise the exact
# generated partial-cleanup inode/hash logic with a synthetic /proc directory.
# No root preflight/query/copy is executed or counted as platform evidence.
class RemoteFixture:
 def __init__(self,root,fault):self.root=root;self.paths={};self.counter=0;self.fault=fault
 def call(self,argv,**kwargs):
  code=argv[-1] if argv[-2]=='-c' else shlex.split(argv[-1])[-1];answer=None;mutation=False
  if code.startswith('PATH='):
   values={node.targets[0].id:ast.literal_eval(node.value) for node in ast.parse(code).body[:6]}
   physical=self.paths[values['PATH']]
   revised=C.stage_cleanup_code(str(physical),values['IDENTITY'],values['FILES'],os.getuid(),values['ENTRIES'],partial=values['PARTIAL'])
   fake=self.root/'proc';fake.mkdir(exist_ok=True);revised=revised.replace("pathlib.Path('/proc')",'pathlib.Path('+repr(str(fake))+')')
   output=io.StringIO();status=0
   with contextlib.redirect_stdout(output):
    try:exec(compile(revised,'private-generated-cleanup','exec'),{})
    except SystemExit as e:status=e.code
   result=subprocess.CompletedProcess(argv,status,output.getvalue().encode(),b'');result.owned_cli_cleanup=True;return result
  tree=ast.parse(code)
  if kwargs.get('data')is not None:
   call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='open')
   logical=ast.literal_eval(call.args[0]);base,name=logical.rsplit('/',1);path=self.paths[base]/name
   with open(path,'wb') as f:f.write(kwargs['data'])
   path.chmod(0o500);answer={'stagedPinnedBytesVerified':True};mutation=True
  elif 'tempfile.mkdtemp('in code:
   logical='/home/debian/linuxcast-s003-root-proof-fixture';path=self.root/'guest';path.mkdir(mode=0o700);self.paths[logical]=path;m=path.stat();answer=[logical,[m.st_dev,m.st_ino]];mutation=True
  elif 'os.mkdir('in code:
   call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='mkdir');logical=ast.literal_eval(call.args[0]);path=self.root/'container';path.mkdir(mode=0o700);self.paths[logical]=path;m=path.stat();answer=[m.st_dev,m.st_ino];mutation=True
  elif 'fd=os.open(p/'in code:
   logical=next(ast.literal_eval(n.value.args[0]) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='p')
   call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='open');name=ast.literal_eval(call.args[0].right);path=self.paths[logical]/name
   fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);m=os.fstat(fd);os.close(fd);answer=[m.st_dev,m.st_ino];mutation=True
  else:answer={'ready':True}
  if mutation:
   self.counter+=1
   if self.counter==self.fault:raise OSError()
  result=subprocess.CompletedProcess(argv,0,json.dumps(answer).encode(),b'');result.owned_cli_cleanup=True;return result
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-prepare-') as raw:
 root=pathlib.Path(raw);original=(C.STATE,C.local_gate,C.command,C.save,C.SOURCES)
 dummy=root/'dummy';dummy.write_bytes(b'public synthetic bytes')
 C.SOURCES={'collector.py':BASE/'linuxcast-s003-root-proof-guest.py','family.py':dummy,'linuxcast-input-spike-supervisor':dummy,'linuxcast-input-spike-denial-helper':dummy}
 C.local_gate=lambda:'mocked-fixed-manifest';cases=0
 try:
  for remote_fault,save_fault,after in [(n,0,False) for n in range(1,19)]+[(0,n,a) for n in range(1,28) for a in (False,True)]:
   case=root/str(cases);case.mkdir();C.STATE=case/'state';remote=RemoteFixture(case,remote_fault);C.command=remote.call;count=[0]
   def save_faulted(value):
    count[0]+=1
    if count[0]==save_fault and not after:raise OSError()
    original[3](value)
    if count[0]==save_fault and after:raise OSError()
   C.save=save_faulted
   try:
    with contextlib.redirect_stdout(io.StringIO()):C.prepare()
   except OSError:pass
   cleanup=json.loads((C.STATE/'prepare-cleanup.json').read_text());remaining=any(p.exists() for p in remote.paths.values())
   assert cleanup['prepareComplete']is False and (not remaining or cleanup['retainedResources']is True)
   if not cleanup['retainedResources']:assert not remaining
   cases+=1
 finally:C.STATE,C.local_gate,C.command,C.save,C.SOURCES=original
 assert cases==72;checks['mockedPrepare72AcquisitionAndStateFaults']=True
# Strict integers reject booleans at both version positions.
for key in ('outer','root'):
 bad=copy.deepcopy(minimal)
 if key=='outer':bad['schemaVersion']=True
 else:bad['rootReport']['schemaVersion']=True
 denied(lambda:C.validate(bad))
checks['booleanSchemaVersionsRejected']=True
# Parse-only all fixed remote bootstrap/preflight/release code; execute none.
compile('STAGE="/private/notexecuted"\nPINS={}\n'+C.BOOTSTRAP,'bootstrap','exec')
compile(C.preflight_code(),'preflight','exec')
compile(C.stage_cleanup_code('/private/notexecuted',[1,2],{},1000,{}),'release','exec')
checks['remoteCodeSyntaxOnly']=True
print(json.dumps({'schemaVersion':1,'privateHarmlessFixtures':checks,'allPassed':all(checks.values()),'rootExecutions':0,'liveQueries':0,'vmCalls':0,'deviceOperations':0},sort_keys=True))
