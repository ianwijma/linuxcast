"""Harmless owned-process/file fixtures only; no root, bus, VM or devices."""
import copy,hashlib,importlib.util,json,os,pathlib,signal,subprocess,sys,tempfile,time
BASE=pathlib.Path('/tmp')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
F=load('family',BASE/'linuxcast-s003-root-proof-family.py');G=load('guest',BASE/'linuxcast-s003-root-proof-guest.py');C=load('control',BASE/'linuxcast-s003-root-proof-control.py')
assert os.getuid()!=0
checks={}
def denied(call):
 try:call()
 except (AssertionError,ValueError,TypeError,FileExistsError):return
 raise AssertionError('negative accepted')
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-offline-') as raw:
 root=pathlib.Path(raw);target=root/'unrelated';target.write_bytes(b'unchanged');link=root/'collision';link.symlink_to(target)
 journal=G.Journal()
 with F.Cancellation() as guard:denied(lambda:journal.create(link,b'new',guard=guard))
 assert target.read_bytes()==b'unchanged' and link.is_symlink() and journal.entries==[];checks['exclusiveCollisionPreserved']=True
 journal=G.Journal();a=root/'a';b=root/'b'
 with F.Cancellation() as guard:journal.create(a,b'a',guard=guard);journal.create(b,b'b',guard=guard)
 a.unlink();a.write_bytes(b'replacement')
 assert journal.cleanup()is False and a.read_bytes()==b'replacement' and not b.exists();checks['independentInodeCleanup']=True
 journal=G.Journal();partial=root/'partial';fsync=G.os.fsync
 def fault(fd):raise OSError()
 G.os.fsync=fault
 try:
  with F.Cancellation() as guard:denied(lambda:journal.create(partial,b'partial',guard=guard))
 except OSError:pass
 finally:G.os.fsync=fsync
 assert journal.cleanup() and not partial.exists();checks['partialWriteOwnedCleanup']=True
 # Exact critical-spawn method restores the pre-critical signal mask.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import signal;assert not signal.pthread_sigmask(signal.SIG_BLOCK,set()) & {signal.SIGTERM,signal.SIGHUP,signal.SIGINT};print('READY',flush=True);signal.pause()"],guard,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert p.stdout.readline()==b'READY\n';clean=family.stop()
  assert all(clean.values()) and p.returncode==-signal.SIGTERM
  p.stdout.close();p.stderr.close()
 checks['guardedSpawnMaskRestored']=True
 # Post-Popen bookkeeping failure cannot hide an internally owned process.
 family=F.Family();adopt=family.adopt
 def post_spawn_fault():adopt();raise RuntimeError()
 family.adopt=post_spawn_fault
 with F.Cancellation() as guard:
  try:family.spawn([sys.executable,'-I','-S','-c','import signal;signal.pause()'],guard)
  except RuntimeError:pass
  else:raise AssertionError()
  family.adopt=adopt;assert all(family.stop().values())
 checks['postSpawnFailureCleanup']=True
 # Already-exited leader leaves a real descendant; pidfd-group cleanup must
 # reach it instead of deciding the entire experiment ended with the leader.
 family=F.Family()
 with F.Cancellation() as guard:
  p=family.spawn([sys.executable,'-I','-S','-c',"import os,signal;pid=os.fork();os._exit(0) if pid else signal.pause()"],guard)
  end=time.monotonic()+1
  while family.exited(p.pid)is None and time.monotonic()<end:time.sleep(.005)
  assert family.exited(p.pid)==0;assert all(family.stop().values())
 checks['exitedLeaderDescendantCleanup']=True
 # Ordinary cancellation enters all independent owned-file cleanup steps.
 journal=G.Journal();marker=root/'marker';old=root/'old';old.write_bytes(b'old')
 with F.Cancellation() as guard:
  try:journal.create(marker,b'canary',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:guard.cleanup();ok=journal.cleanup()
 assert ok and not marker.exists() and old.read_bytes()==b'old';checks['ordinaryCancellationCleanup']=True
 # Bounded controller transport rejects flood without retaining raw output.
 try:C.command([sys.executable,'-I','-S','-c',"import sys;sys.stdout.write('X'*1000000)"],timeout=1)
 except AssertionError:pass
 else:raise AssertionError()
 checks['transportFloodBound']=True
# Schema rejects additional fields and private content, duplicate JSON keys,
# malformed rows, missing evidence and unsupported-as-success. No native run.
minimal={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootReport':{'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','failureCode':'ROOT_DENIAL_BOOTSTRAP_INCOMPLETE','wrapperGatePassed':False},'rootCapsuleRemoved':False,'bootstrapCancellationObserved':False,'complete':False}
C.validate(minimal)
for path in ('outer','root','row'):
 bad=copy.deepcopy(minimal)
 if path=='outer':bad['PrivateCanary']='/private/path'
 elif path=='root':bad['rootReport']['PrivateCanary']='/private/path'
 else:bad['rootReport']['actualRows']=[{'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'PrivateCanary','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}]
 denied(lambda:C.validate(bad))
bad=copy.deepcopy(minimal);bad['complete']=True;denied(lambda:C.validate(bad))
denied(lambda:C.strict('{"a":1,"a":2}'));denied(lambda:C.strict('{"a":NaN}'))
row={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'UNSUPPORTED','decisionVeto':'PENDING','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
bad=copy.deepcopy(minimal);bad['rootReport']['actualRows']=[row];C.validate(bad)
bad['complete']=True;denied(lambda:C.validate(bad));checks['strictPublicSchemaAndUnsupportedIncomplete']=True
goodrow={'phase':'ROOT_LIVE_DENIAL_PREBOOTSTRAP','evidenceVeto':'REMOTE','decisionVeto':'REMOTE','canArm':False,'workerArmEmitted':False,'deviceBootstrapReached':False}
first=copy.deepcopy(goodrow);first['evidenceVeto']='PENDING';first['decisionVeto']='PENDING'
keys={'nativeOriginalsUnchanged','inputProgramsAbsent','graphicalSessionsAbsent','manufacturedDevicesAbsent','markerAbsent','privateDesktopRootsAbsent','guiProcessesAbsent','busBaselineUnchanged'}
good={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootCapsuleRemoved':True,'bootstrapCancellationObserved':False,'complete':True,'rootReport':{
 'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','preflight':dict.fromkeys(keys,True),'postflight':dict.fromkeys(keys,True),'runtime':{'distribution':'debian','debianVersion':'13.7','kernel':'6.12.113+deb13-amd64','architecture':'x86_64','libsystemdVersion':'257.13-1~deb13u1','pythonVersion':'3.13.5'},
 'supervisorSha256':G.PINS['linuxcast-input-spike-supervisor'],'helperSha256':G.PINS['linuxcast-input-spike-denial-helper'],'actualRows':[first]+[copy.deepcopy(goodrow) for _ in range(19)],'diagnostics':[],'actualRootDropProof':True,'ownConnectorPeerBound':True,'pdeathProofKind':'READY_REQUIRES_REVIEWED_HELPER_SELF_READBACK','directParentDeathTrialPerformed':False,'noInputBranchExecuted':True,'wrapperGatePassed':True,'nativeExitCode':0,'nativeElapsedMs':4751,
 'credentialProof':dict.fromkeys({'allUserIdsMatchExpected','allGroupIdsMatchPrimary','supplementalGroupsEmpty','capabilitiesAndAmbientEmpty','noNewPrivileges','coreSoftHardZero','descriptorCategoriesPrivate','helperExecutableHashMatches','helperParentBindingObserved','helperAliveDuringObservation'},True),
 'helperStartupSelfReadbacksEstablishedByReady':True,'cleanup':dict.fromkeys({'ownedChildrenAbsent','ownedGroupsAbsent','signalOperationsSucceeded','ownedObjectsRemoved','withinCleanupBudget'},True),'helperPathAbsent':True,'ownedLifetimeObservation':{'knownLive':1,'knownExitReady':1,'unknown':0,'knownReaped':0},'ownedStopElapsedMs':5,'criticalCleanupElapsedMs':6,'ordinaryCancellationObserved':False}}
C.validate(good)
for mutate in (
 lambda r:r.pop('runtime'),lambda r:r['credentialProof'].update({'capabilitiesAndAmbientEmpty':False}),lambda r:r['actualRows'][1].update({'decisionVeto':'PENDING'}),lambda r:r['actualRows'][1].update({'evidenceVeto':'UNSUPPORTED'}),lambda r:r.update({'ownedStopElapsedMs':2001}),lambda r:r.update({'directParentDeathTrialPerformed':True}),lambda r:r.update({'diagnostics':[{'component':'PrivateCanary','stage':'STARTUP','code':'PANIC','io_kind':None,'errno':None}]})):
 bad=copy.deepcopy(good);mutate(bad['rootReport']);denied(lambda:C.validate(bad))
checks['successRequiresActualNegativeAndCredentialEvidence']=True
# Exact post-fork own-child binding rejects another live same-UID connector.
import socket,select,contextlib,io,shlex,ast
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-peer-') as raw:
 listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);listener.bind(raw+'/peer');listener.listen(2);listener.settimeout(1)
 def child(parent):
  assert F.libc.prctl(1,signal.SIGKILL,0,0,0)==0 and os.getppid()==parent
  s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(raw+'/peer')
  while True:signal.pause()
 family=F.Family()
 with F.Cancellation() as guard:
  try:
   first=family.fork(child,guard);assert os.getpgid(first)==first
   accepted,_=listener.accept();G.own_peer(accepted,first,family,os.getuid())
   second=family.fork(child,guard);assert os.getpgid(second)==second
   wrong,_=listener.accept();denied(lambda:G.own_peer(wrong,first,family,os.getuid()))
   wrong.close();accepted.close()
  finally:guard.cleanup();assert all(family.stop().values());listener.close()
 checks['exactOwnPeerAndPreAdoptGroupBinding']=True
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cancel-') as raw:
 p=pathlib.Path(raw)/'owned';journal=G.Journal()
 with F.Cancellation() as guard:
  try:journal.create(p,b'owned',guard=guard);os.kill(os.getpid(),signal.SIGTERM);guard.check()
  except F.Cancelled:pass
  finally:
   # These occur BEFORE the cleanup-state assignment, the formerly unsafe gap.
   for number in (signal.SIGHUP,signal.SIGTERM,signal.SIGINT,signal.SIGTERM):os.kill(os.getpid(),number)
   guard.cleanup();assert journal.cleanup()
 assert not p.exists();checks['repeatedCancellationCannotSkipFinally']=True
 # fdopen failure after O_EXCL must close the acquired descriptor too.
 before=len(os.listdir('/proc/self/fd'));original=G.os.fdopen;journal=G.Journal()
 def fdopen_fault(*args,**kwargs):raise OSError()
 G.os.fdopen=fdopen_fault
 try:
  with F.Cancellation() as guard:
   try:journal.create(p,b'owned',guard=guard)
   except OSError:pass
 finally:G.os.fdopen=original
 assert len(os.listdir('/proc/self/fd'))==before and journal.cleanup();checks['partialDescriptorAcquisitionClosed']=True
# Real harmless own executable with a synthetic proc directory avoids reading
# other users' host processes; tests the exact retention predicate and journal.
import types
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-exe-') as raw:
 root=pathlib.Path(raw);exe=root/'owned-sleep';journal=G.Journal()
 with F.Cancellation() as guard:journal.create(exe,pathlib.Path('/usr/bin/sleep').read_bytes(),guard=guard,executable=True)
 process=subprocess.Popen([str(exe),'2'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 fake=root/'proc';fake.mkdir();(fake/str(process.pid)).symlink_to('/proc/'+str(process.pid),target_is_directory=True)
 previous=G.pathlib;G.pathlib=types.SimpleNamespace(Path=lambda raw:fake if str(raw)=='/proc' else pathlib.Path(raw))
 try:
  assert G.executable_in_use(exe) and journal.cleanup()is False and exe.exists()
  process.kill();process.wait();assert journal.cleanup() and not exe.exists()
 finally:
  G.pathlib=previous
  if process.poll()is None:process.kill();process.wait()
 checks['actualOwnExecutableRetainedUntilDeathMockedProcNamespace']=True
# Controller-level TERM/HUP must stop its real CLI leader and descendant.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-cli-') as raw:
 for index,number in enumerate((signal.SIGTERM,signal.SIGHUP)):
  ready=pathlib.Path(raw)/str(index)
  target="import json,os,pathlib,signal;pid=os.fork();\nif pid==0:signal.pause()\nelse:\n pathlib.Path("+repr(str(ready))+").write_text(json.dumps([os.getpid(),pid]));signal.pause()"
  script="import importlib.util,json,sys;s=importlib.util.spec_from_file_location('c','/tmp/linuxcast-s003-root-proof-control.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)\ntry:c.command([sys.executable,'-I','-S','-c',"+repr(target)+"],timeout=3)\nexcept BaseException:print('{\"cancelled\":true}',flush=True)"
  process=subprocess.Popen([sys.executable,'-I','-S','-c',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  handles=[]
  try:
   end=time.monotonic()+2
   while not ready.exists() and time.monotonic()<end:time.sleep(.005)
   assert ready.exists()
   for pid in json.loads(ready.read_text()):handles.append(os.pidfd_open(pid,0))
   for _ in range(4):os.kill(process.pid,number);time.sleep(.002)
   out,err=process.communicate(timeout=4);assert process.returncode==0 and out==b'{"cancelled":true}\n' and not err
   for fd in handles:
    poll=select.poll();poll.register(fd,select.POLLIN);assert poll.poll(100)
  finally:
   if process.poll()is None:process.kill();process.wait()
   for fd in handles:
    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
    except ProcessLookupError:pass
    os.close(fd)
 checks['fullTransportTermAndHupDescendantCleanup']=True
# Durable UNKNOWN intent is created before transport: a lost first reply may
# never cause a second dispatch, even with no first-result file written.
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-attempt-') as raw:
 original=(C.STATE,C.local_gate,C.own_state,C.command);C.STATE=pathlib.Path(raw);calls=[]
 C.local_gate=lambda:'fixture';C.own_state=lambda:{'guest':'/not-executed','files':{}}
 def lost_reply(*args,**kwargs):calls.append(True);raise RuntimeError()
 C.command=lost_reply
 try:
  try:C.run()
  except RuntimeError:pass
  denied(C.run);assert len(calls)==1 and json.loads((C.STATE/'attempt.json').read_text())['outcome']=='UNKNOWN_BEFORE_DISPATCH'
 finally:C.STATE,C.local_gate,C.own_state,C.command=original
 checks['durableIntentPreventsSecondDispatch']=True
# Mocked transport only; actual ordinary private files exercise the exact
# generated partial-cleanup inode/hash logic with a synthetic /proc directory.
# No root preflight/query/copy is executed or counted as platform evidence.
from unittest import mock

def generated(code,data=None,proc_mock=False):
 # Execute unchanged generated guards on actual ordinary UID1000 files.
 # Only external /proc executable enumeration is synthetic, not UID/mode/
 # inode checks. The byte writer gets an actual bounded in-memory stdin.
 output=io.StringIO();old_stdin=sys.stdin;remaining=signal.alarm(0);status=0
 original_readlink=os.readlink
 def fixture_readlink(path,*args,**kwargs):
  if str(path).startswith('/proc/') and str(path).endswith('/exe'):return '/synthetic/not-a-staged-executable'
  return original_readlink(path,*args,**kwargs)
 try:
  if data is not None:sys.stdin=types.SimpleNamespace(buffer=io.BytesIO(data))
  with contextlib.redirect_stdout(output),mock.patch('os.readlink',side_effect=fixture_readlink) if proc_mock else contextlib.nullcontext():
   try:exec(compile(code,'exact-generated-uid1000-guard','exec'),{})
   except SystemExit as e:status=e.code
 finally:
  signal.alarm(0);sys.stdin=old_stdin
  if remaining:signal.alarm(remaining)
 return status,output.getvalue().encode()

class RemoteFixture:
 def __init__(self,root,fault):self.root=root;self.paths={};self.counter=0;self.fault=fault
 def call(self,argv,**kwargs):
  code=argv[-1] if argv[-2]=='-c' else shlex.split(argv[-1])[-1];answer=None;mutation=False
  if code.startswith('PATH='):
   values={node.targets[0].id:ast.literal_eval(node.value) for node in ast.parse(code).body[:6]}
   physical=self.paths[values['PATH']]
   revised=C.stage_cleanup_code(str(physical),values['IDENTITY'],values['FILES'],values['UID'],values['ENTRIES'],partial=values['PARTIAL'])
   status,output=generated(revised,proc_mock=True)
   result=subprocess.CompletedProcess(argv,status,output,b'');result.owned_cli_cleanup=True;return result
  tree=ast.parse(code)
  if kwargs.get('data')is not None:
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:5]};base,name=values['TARGET'].rsplit('/',1);path=self.paths[base]/name
   status,output=generated(C.write_code(str(path),values['IDENTITY'],values['EXPECTED_UID'],values['LENGTH'],values['WANTED']),kwargs['data'])
   assert status==0;answer=json.loads(output);mutation=True
  elif code.startswith('TARGET=') and 'GENERATED='in code:
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:3]}
   if values['GENERATED']:
    status,output=generated(C.directory_code(str(self.root),values['EXPECTED_UID'],generated=True));assert status==0
    physical,identity=json.loads(output);logical='/home/debian/linuxcast-s003-root-proof-fixture';self.paths[logical]=pathlib.Path(physical);answer=[logical,identity]
   else:
    logical=values['TARGET'];path=self.root/'container';status,output=generated(C.directory_code(str(path),values['EXPECTED_UID']));assert status==0
    self.paths[logical]=path;answer=json.loads(output)
   mutation=True
  elif code.startswith('DIRECTORY='):
   values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body[:4]}
   physical=self.paths[values['DIRECTORY']]
   status,output=generated(C.precreate_code(str(physical),values['IDENTITY'],values['NAME'],values['EXPECTED_UID']))
   assert status==0;answer=json.loads(output);mutation=True
  else:answer={'ready':True}
  if mutation:
   self.counter+=1
   if self.counter==self.fault:raise OSError()
  result=subprocess.CompletedProcess(argv,0,json.dumps(answer).encode(),b'');result.owned_cli_cleanup=True;return result
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-prepare-') as raw:
 root=pathlib.Path(raw);original=(C.STATE,C.local_gate,C.command,C.save,C.SOURCES)
 dummy=root/'dummy';dummy.write_bytes(b'public synthetic bytes')
 C.SOURCES={'collector.py':BASE/'linuxcast-s003-root-proof-guest.py','family.py':dummy,'linuxcast-input-spike-supervisor':dummy,'linuxcast-input-spike-denial-helper':dummy}
 C.local_gate=lambda:'mocked-fixed-manifest';cases=0
 try:
  healthy=root/'healthy';healthy.mkdir();C.STATE=healthy/'state';remote=RemoteFixture(healthy,0);C.command=remote.call
  with contextlib.redirect_stdout(io.StringIO()):C.prepare()
  state=json.loads((C.STATE/'state.json').read_bytes());assert C.CONTAINER_UID==C.GUEST_UID==os.getuid()==1000
  assert C.cleanup_stages(state)=={'guest':True,'container':True} and all(not p.exists() for p in remote.paths.values())
  checks['exactGeneratedUid1000HealthyPrepareAndCleanup']=True
  for remote_fault,save_fault,after in [(n,0,False) for n in range(1,19)]+[(0,n,a) for n in range(1,28) for a in (False,True)]:
   case=root/str(cases);case.mkdir();C.STATE=case/'state';remote=RemoteFixture(case,remote_fault);C.command=remote.call;count=[0]
   def save_faulted(value):
    count[0]+=1
    if count[0]==save_fault and not after:raise OSError()
    original[3](value)
    if count[0]==save_fault and after:raise OSError()
   C.save=save_faulted
   try:
    with contextlib.redirect_stdout(io.StringIO()):C.prepare()
   except OSError:pass
   cleanup=json.loads((C.STATE/'prepare-cleanup.json').read_text());remaining=any(p.exists() for p in remote.paths.values())
   assert cleanup['prepareComplete']is False and (not remaining or cleanup['retainedResources']is True)
   if not cleanup['retainedResources']:assert not remaining
   cases+=1
 finally:C.STATE,C.local_gate,C.command,C.save,C.SOURCES=original
 assert cases==72;checks['mockedPrepare72AcquisitionAndStateFaults']=True
with tempfile.TemporaryDirectory(prefix='linuxcast-root-proof-uid-contract-') as raw:
 root=pathlib.Path(raw);directory=root/'stage'
 # Both exact generated directory guards reject UID0 BEFORE mkdir/mkdtemp,
 # not merely before later file creation. No UID function is mocked.
 for generated_directory,target in ((False,directory),(True,root)):
  before=set(root.iterdir())
  denied(lambda:generated(C.directory_code(str(target),0,generated=generated_directory)))
  assert set(root.iterdir())==before and not directory.exists()
 status,output=generated(C.directory_code(str(directory),1000));assert status==0;identity=json.loads(output)
 status,output=generated(C.directory_code(str(root),1000,generated=True));assert status==0
 temporary,temporary_id=json.loads(output);temporary=pathlib.Path(temporary)
 assert temporary.parent==root and temporary.stat().st_uid==1000 and temporary.stat().st_mode & 0o777==0o700
 status,output=generated(C.stage_cleanup_code(str(temporary),temporary_id,{},1000,{}),proc_mock=True);assert status==0 and not temporary.exists()
 checks['bothDirectoryGuardsRejectWrongUidBeforeCreation']=True
 try:generated(C.precreate_code(str(directory),identity,'collector.py',0))
 except AssertionError:pass
 else:raise AssertionError('wrong UID accepted')
 assert list(directory.iterdir())==[]
 status,output=generated(C.precreate_code(str(directory),identity,'collector.py',1000));assert status==0;file_id=json.loads(output)
 data=b'fixed public bytes';wanted=hashlib.sha256(data).hexdigest()
 status,output=generated(C.write_code(str(directory/'collector.py'),file_id,1000,len(data),wanted),data);assert status==0 and (directory/'collector.py').read_bytes()==data and (directory/'collector.py').stat().st_uid==1000
 entries={'collector.py':{'identity':file_id,'complete':True}};files={'collector.py':wanted}
 try:generated(C.stage_cleanup_code(str(directory),identity,files,0,entries),proc_mock=True)
 except AssertionError:pass
 else:raise AssertionError('wrong UID cleanup accepted')
 assert directory.exists() and (directory/'collector.py').read_bytes()==data
 status,output=generated(C.stage_cleanup_code(str(directory),identity,files,1000,entries),proc_mock=True);assert status==0 and not directory.exists()
 checks['wrongUidZeroRejectedBeforeCreateAndCleanup']=True
# Strict integers reject booleans at both version positions.
for key in ('outer','root'):
 bad=copy.deepcopy(minimal)
 if key=='outer':bad['schemaVersion']=True
 else:bad['rootReport']['schemaVersion']=True
 denied(lambda:C.validate(bad))
checks['booleanSchemaVersionsRejected']=True
# Parse-only all fixed remote bootstrap/preflight/release code; execute none.
compile('STAGE="/private/notexecuted"\nPINS={}\n'+C.BOOTSTRAP,'bootstrap','exec')
compile(C.preflight_code(),'preflight','exec')
compile(C.stage_cleanup_code('/private/notexecuted',[1,2],{},1000,{}),'release','exec')
checks['remoteCodeSyntaxOnly']=True
print(json.dumps({'schemaVersion':1,'privateHarmlessFixtures':checks,'allPassed':all(checks.values()),'rootExecutions':0,'liveQueries':0,'vmCalls':0,'deviceOperations':0},sort_keys=True))
