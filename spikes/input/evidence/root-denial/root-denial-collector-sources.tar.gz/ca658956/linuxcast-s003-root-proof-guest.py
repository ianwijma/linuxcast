"""SOURCE ONLY until independently approved. Fixed disposable-root fixture."""
import array,ctypes,fcntl,hashlib,json,os,pathlib,pwd,resource,selectors,signal,socket,stat,subprocess,sys,tempfile,time
# Controller copies this exact helper module into a root-owned0700 capsule.
from family import Family,Cancellation
libc=ctypes.CDLL(None,use_errno=True)
NATIVE=pathlib.Path('/opt/linuxcast-input-spike')
PINS={'linuxcast-input-spike-supervisor':'4fd4609ab5acfd5131c403fe0b9dd9a8460bf35f698798d1025ef401401fba00','linuxcast-input-spike-denial-helper':'b80cc6a4c5577040ee679a9c657d6e6db04c8b4478cbb46ab70d6d2d883d1bc9'}
OLD={'linuxcast-input-spike-supervisor':'1060b44313a1536926d89303625b9f91272a1f59a5d05ac803e026843e11ef7a','linuxcast-input-spike-worker':'45fae18d283eee7bfbff39fbe060b29c040d951db248d04bc5aa5eba1ce00eb8','linuxcast-input-spike-synthetic-lab':'9211ceb29ae2373717f2fc74d591544898ac2931c3f83deaf21186b7b6da7e51'}
DIAGNOSTIC_CODES={'PRIVATE_NONROOT_BOUNDARY_REQUIRED', 'ROOT_DENIAL_UNEXPECTED_PARENT_PACKET', 'DENIAL_NONROOT_CONNECTION_REQUIRED', 'FIXTURE_DESCRIPTOR_NOT_CLOSED', 'DENIAL_PRIVATE_DIRECTORY', 'DENIAL_AUTHORIZED_PEER_MISMATCH', 'ROOT_DENIAL_AUTHORIZATION_INVALID', 'PRIVATE_READBACK_SETUP', 'DENIAL_CONNECTOR_MISMATCH', 'DENIAL_DESCRIPTOR_CLOSURE_FAILED', 'DENIAL_CONNECTOR_FAILED', 'FD_BOUND', 'DENIAL_UNEXPECTED_WORKER_EFFECT', 'DENIAL_TERMINAL_REVIVAL', 'DENIAL_AUTHORIZED_ACCOUNT_UNAVAILABLE', 'DENIAL_PRIVATE_CLEANUP', 'DENIAL_PARENT_PIDFD', 'UNCLASSIFIED_FAILURE', 'DENIAL_SOCKET_METADATA', 'DENIAL_PRIVATE_SOCKET', 'PRIVATE_CANARY_DESCRIPTOR', 'DENIAL_AUTHORIZED_PEER_DEAD', 'PANIC', 'DENIAL_SEQUENCE_OVERFLOW', 'INTERNAL_SEND_FAILED', 'DENIAL_CHILD_REAPER_POLICY', 'PACKET_BOUND', 'PARENT_DEATH_RACE', 'DENIAL_OBSERVATION_INCOMPLETE', 'DENIAL_HELPER_BINARY_UNTRUSTED', 'DENIAL_HELPER_DIRECTORY_UNTRUSTED', 'CORE_POLICY_FAILED', 'IO_FAILURE', 'DENIAL_SOCKET_KIND', 'DENIAL_BOOTSTRAP_PARENT', 'FIXTURE_PEER_PIDFD', 'INTERNAL_TIMEOUT', 'PRIVATE_PARENT_FORK_FAILED', 'PRIVATE_CASE', 'DENIAL_BOOTSTRAP_INVALID', 'DENIAL_PUBLIC_BOUND', 'DENIAL_GUARD_FAILED', 'DENIAL_BOOTSTRAP_PARENT_LOST', 'DENIAL_HELPER_PRIVILEGES', 'DENIAL_HELPER_STARTUP_READBACK', 'INTERNAL_PACKET_INVALID', 'DENIAL_GUARD_SIGNAL_MASK', 'DENIAL_SEQUENCE_INVALID', 'PRIVATE_PARENT_CHILD_TIMEOUT', 'DENIAL_HELPER_START_FAILED', 'PRIVATE_READBACK_CHILD_TIMEOUT', 'FIXTURE_PEER_UID', 'PRIVATE_READBACK_FORK_FAILED', 'DENIAL_CONNECTOR_UNAVAILABLE', 'DENIAL_CONNECTOR_CLEANUP', 'DENIAL_CANCELLED', 'PEERCRED_UNAVAILABLE', 'DENIAL_OWNED_CLEANUP', 'DENIAL_HELPER_ENV_OR_UID', 'DENIAL_ROOT_AUTHORIZATION_REQUIRED', 'ROOT_DENIAL_EMPTY_ENV_AND_ROOT_REQUIRED', 'JSON_SCHEMA_FAILURE'}
VETO={'PENDING','REMOTE','INACTIVE','NOT_GRAPHICAL','NOT_SEAT_ZERO','LOCKED','COMPANION_UNAVAILABLE','UNSUPPORTED','UNKNOWN_CONTEXT','STALE','TIMEOUT','PEER_DEAD','PEER_DISCONNECTED','EPOCH_CHANGED','CHANNEL_DISCONNECTED','HELPER_EXITED','INVALID_OBSERVATION','TERMINAL'}
FAILURE_STAGES={'INSTALL_HELPER','CREATE_PEER_DIRECTORY','BIND_LISTENER','FORK_CONNECTOR','ACCEPT_CONNECTOR','BIND_OWN_PEER','CREATE_PARENT_CHANNEL','RESERVE_PARENT_FD','SPAWN_SUPERVISOR','SEND_BOOTSTRAP','OBSERVE_NATIVE','READ_HELPER_PROOF','VALIDATE_NATIVE_RESULT'}
HELPER_INSTALL_MODE=0o555
FALSE_FIELDS=('canArm','workerArmEmitted','deviceBootstrapReached')
ROWS={'phase','evidenceVeto','decisionVeto',*FALSE_FIELDS}
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(131072),b''):h.update(block)
 return h.hexdigest()
def read(path,limit=16384):
 with open(path,'rb') as f:value=f.read(limit+1)
 assert len(value)<=limit
 return value.decode('ascii')
def json_exact(data):
 def unique(items):
  value={}
  for key,item in items:
   assert key not in value;value[key]=item
  return value
 return json.loads(data,object_pairs_hook=unique)
def verified_bytes(path,wanted):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  m=os.fstat(fd);assert stat.S_ISREG(m.st_mode) and m.st_uid==0 and m.st_nlink==1 and m.st_size<=32*1024*1024
  with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(32*1024*1024+1)
  assert len(data)==m.st_size and hashlib.sha256(data).hexdigest()==wanted
  return data
 finally:os.close(fd)
def helper_install_metadata(info,identity):
 assert (info.st_dev,info.st_ino)==identity and stat.S_ISREG(info.st_mode) and info.st_uid==0 and info.st_nlink==1 and stat.S_IMODE(info.st_mode)==HELPER_INSTALL_MODE
 assert not info.st_mode&0o7222 and info.st_size<=32*1024*1024

def verify_installed_helper(path,identity,wanted):
 # Check the same opened inode, root-only write authority and fixed public bytes.
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  info=os.fstat(fd);helper_install_metadata(info,identity)
  with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(32*1024*1024+1)
  assert len(data)==info.st_size and hashlib.sha256(data).hexdigest()==wanted
  assert inode(path)==identity
 finally:os.close(fd)

def record_failure(public,stage):
 assert type(stage)is str and stage in FAILURE_STAGES
 public['failureCode']='ROOT_DENIAL_OBSERVATION_INCOMPLETE';public['failureStage']=stage

def inode(path):
 m=path.lstat();return (m.st_dev,m.st_ino)
def trusted(path,mode=None):
 m=path.lstat();assert m.st_uid==0 and not m.st_mode&0o022 and not stat.S_ISLNK(m.st_mode)
 if mode is not None:assert stat.S_IMODE(m.st_mode)==mode
 return m
def executable_in_use(path):
 for process in pathlib.Path('/proc').iterdir():
  if not process.name.isdecimal():continue
  try:
   if os.readlink(process/'exe')==str(path):return True
  except (FileNotFoundError,ProcessLookupError):pass
 return False
class Journal:
 def __init__(self):self.entries=[]
 def own(self,path,kind,sha=None):
  self.entries.append((path,inode(path),kind,sha));return path
 def create(self,path,data,mode=0o500,guard=None,executable=False):
  fd=None
  try:
   with guard.critical():
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    info=os.fstat(fd);entry=len(self.entries);kind='executable' if executable else 'file';self.entries.append((path,(info.st_dev,info.st_ino),kind,None))
   with os.fdopen(fd,'wb',closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno());os.fchmod(fd,mode)
   self.entries[entry]=(path,(info.st_dev,info.st_ino),kind,hashlib.sha256(data).hexdigest())
  finally:
   if fd is not None:os.close(fd)
  return path
 def cleanup(self):
  result=True
  for path,identity,kind,sha in reversed(self.entries):
   try:
    assert inode(path)==identity
    if sha is not None:assert digest(path)==sha
    if kind=='executable':assert not executable_in_use(path)
    assert inode(path)==identity
    if kind=='dir':path.rmdir()
    else:path.unlink()
   except BaseException:result=False
  return result

def runtime():
 release=dict(line.split('=',1) for line in read(pathlib.Path('/etc/os-release')).splitlines() if '='in line)
 result=subprocess.run(['/usr/bin/dpkg-query','-W','-f=${Version}','libsystemd0:amd64'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=2)
 version=result.stdout.decode('ascii');assert result.returncode==0 and 0<len(version)<=128 and all(c.isalnum() or c in '.+:~_-' for c in version)
 value={'distribution':release.get('ID','').strip('"'),'debianVersion':read(pathlib.Path('/etc/debian_version'),32).strip(),'kernel':os.uname().release,'architecture':os.uname().machine,'libsystemdVersion':version,'pythonVersion':'.'.join(map(str,sys.version_info[:3]))}
 assert value['distribution']=='debian' and value['debianVersion']=='13.7' and value['kernel']=='6.12.113+deb13-amd64' and value['architecture']=='x86_64' and value['libsystemdVersion']=='257.13-1~deb13u1'
 return value

def baseline():
 counts={name:0 for name in ('gnome-shell','kwin_wayland','kwin_x11','Xvfb','electron','node','gdb','dbus-daemon')};input_absent=True
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   comm=read(p/'comm',128).strip()
   if comm in counts:counts[comm]+=1
   name=pathlib.Path(os.readlink(p/'exe')).name
   if name.startswith('linuxcast-input-spike-'):input_absent=False
  except (FileNotFoundError,ProcessLookupError):pass
 sessions=pathlib.Path('/run/systemd/sessions');graphical=False
 if sessions.exists():
  for p in sessions.iterdir():
   if p.is_file():graphical |= any(line in ('TYPE=x11','TYPE=wayland') for line in read(p).splitlines())
 manufactured=False
 for p in pathlib.Path('/sys/class/input').glob('event*/device/name'):
  manufactured |= read(p,256).strip() in ('Linuxcast S0-03 synthetic source','Linuxcast S0-03 passthrough virtual')
 roots=not any(pathlib.Path('/run').glob('linuxcast-root-peer-*')) and all(not any(pathlib.Path('/tmp').glob(pattern)) for pattern in ('linuxcast-s001-matrix-*','linuxcast-s002-*','linuxcast-peer-observer-*','linuxcast-denial-*'))
 originals=True
 for name,wanted in OLD.items():
  m=trusted(NATIVE/name);originals &= stat.S_ISREG(m.st_mode) and digest(NATIVE/name)==wanted
 result={'nativeOriginalsUnchanged':bool(originals),'inputProgramsAbsent':input_absent,'graphicalSessionsAbsent':not graphical,'manufacturedDevicesAbsent':not manufactured,'markerAbsent':not pathlib.Path('/run/linuxcast-input-spike-lab').exists(),'privateDesktopRootsAbsent':roots,'guiProcessesAbsent':all(n==0 for name,n in counts.items() if name!='dbus-daemon'),'busBaselineUnchanged':counts['dbus-daemon']==2}
 assert all(type(v)is bool for v in result.values());return result

def row(value):
 assert type(value)is dict and set(value)==ROWS and value['phase']=='ROOT_LIVE_DENIAL_PREBOOTSTRAP'
 assert value['evidenceVeto'] in VETO and value['decisionVeto'] in VETO
 assert all(value[k]is False for k in FALSE_FIELDS)
 return value

def proc_proof(supervisor_pid,uid,gid,helper):
 # This is observation of our sole known helper, never authentication by PID.
 candidates=[int(x) for x in read(pathlib.Path('/proc',str(supervisor_pid),'task',str(supervisor_pid),'children'),128).split()]
 assert len(candidates)==1;pid=candidates[0];fd=os.pidfd_open(pid,0)
 try:
  poll=selectors.DefaultSelector();poll.register(fd,selectors.EVENT_READ)
  assert not poll.select(0)
  root=pathlib.Path('/proc',str(pid));data={}
  for line in read(root/'status').splitlines():
   if ':'in line:k,v=line.split(':',1);data[k]=v.strip()
  assert int(data['PPid'])==supervisor_pid
  assert pathlib.Path(os.readlink(root/'exe'))==helper and digest(root/'exe')==PINS[helper.name]
  fdpaths=list((root/'fd').iterdir());assert len(fdpaths)<=64
  allowed=True
  for entry in fdpaths:
   n=int(entry.name);target=os.readlink(entry)
   allowed &= (n in (0,1) and target=='/dev/null') or (n==2 and target.startswith('pipe:[')) or (n>=3 and (target.startswith('socket:[') or target in ('anon_inode:[pidfd]','anon_inode:[eventpoll]','anon_inode:[eventfd]','anon_inode:[timerfd]')))
  limits=read(root/'limits');core=[line.split() for line in limits.splitlines() if line.startswith('Max core file size')]
  result={'allUserIdsMatchExpected':list(map(int,data['Uid'].split()))==[uid]*4,'allGroupIdsMatchPrimary':list(map(int,data['Gid'].split()))==[gid]*4,'supplementalGroupsEmpty':not data['Groups'],'capabilitiesAndAmbientEmpty':all(int(data[k],16)==0 for k in ('CapInh','CapPrm','CapEff','CapAmb')),'noNewPrivileges':data['NoNewPrivs']=='1','coreSoftHardZero':len(core)==1 and core[0][4:6]==['0','0'],'descriptorCategoriesPrivate':bool(allowed),'helperExecutableHashMatches':True,'helperParentBindingObserved':True,'helperAliveDuringObservation':not bool(poll.select(0))}
  assert int(dict(line.split(':',1) for line in read(root/'status').splitlines() if ':'in line)['PPid'])==supervisor_pid
  assert pathlib.Path(os.readlink(root/'exe'))==helper and not poll.select(0)
  poll.close();assert all(result.values());return result
 finally:os.close(fd)

def own_peer(stream,pid,family,uid):
 assert family.alive(pid)
 peer=array.array('i');peer.frombytes(stream.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
 # Stable, unreaped own child + live retained pidfd prevents numeric reuse.
 # The actual kernel creator must match; another same-UID client is rejected.
 assert peer[0]==pid and peer[1]==uid and family.alive(pid)

def connector(path,uid,gid,parent):
 # Fork first, then drop all IDs/groups, then create/connect the socket.
 signal.signal(signal.SIGALRM,signal.SIG_DFL)
 os.setgroups([]);os.setresgid(gid,gid,gid);os.setresuid(uid,uid,uid)
 class Header(ctypes.Structure):_fields_=[('version',ctypes.c_uint32),('pid',ctypes.c_int)]
 class Data(ctypes.Structure):_fields_=[('effective',ctypes.c_uint32),('permitted',ctypes.c_uint32),('inheritable',ctypes.c_uint32)]
 header=Header(0x20080522,0);caps=(Data*2)()
 assert libc.capset(ctypes.byref(header),ctypes.byref(caps))==0 and libc.prctl(47,4,0,0,0)==0
 assert libc.prctl(1,signal.SIGKILL,0,0,0)==0 and os.getppid()==parent
 assert libc.prctl(4,0,0,0,0)==0 and libc.prctl(38,1,0,0,0)==0
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 # No parent channels, directories or source files cross into this child.
 os.closerange(3,1048576)
 stream=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);stream.connect(str(path))
 while True:signal.pause()

def collect():
 assert sys.argv[1:]==['--collect'] and os.getresuid()==(0,0,0)
 assert signal.getsignal(signal.SIGCHLD)==signal.SIG_DFL
 for name in os.listdir('/proc/self/fd'):
  fd=int(name)
  if fd>2:
   try:fcntl.fcntl(fd,fcntl.F_GETFD)
   except OSError:continue
   raise AssertionError()
 capsule=pathlib.Path(__file__).parent;assert trusted(capsule,0o700) and capsule.name.startswith('linuxcast-s003-root-proof-')
 for name,wanted in PINS.items():assert stat.S_ISREG(trusted(capsule/name,0o500).st_mode) and digest(capsule/name)==wanted
 account=pwd.getpwnam('debian');assert account.pw_uid==1000 and account.pw_gid==1000
 assert os.uname().release=='6.12.113+deb13-amd64' and read(pathlib.Path('/etc/debian_version'),32).strip()=='13.7'
 for parent in (pathlib.Path('/opt'),NATIVE):assert stat.S_ISDIR(trusted(parent).st_mode)
 platform=runtime();before=baseline();assert all(before.values())
 helper=NATIVE/'linuxcast-input-spike-denial-helper'
 assert not helper.exists() and not helper.is_symlink() # CREATE ONLY; no overwrite.
 journal=Journal();family=Family();objects=[];process=None;native_started=None;rows=[];diag=[];proof=None;failure=True;clean={};selector=None;public={'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','preflight':before,'runtime':platform,'supervisorSha256':PINS['linuxcast-input-spike-supervisor'],'helperSha256':PINS[helper.name],'actualRows':rows,'diagnostics':diag,'actualRootDropProof':False,'ownConnectorPeerBound':False,'pdeathProofKind':'READY_REQUIRES_REVIEWED_HELPER_SELF_READBACK','directParentDeathTrialPerformed':False,'noInputBranchExecuted':False,'wrapperGatePassed':False}
 stage='INSTALL_HELPER'
 with Cancellation() as guard:
  try:
   guard.check();journal.create(helper,verified_bytes(capsule/helper.name,PINS[helper.name]),mode=HELPER_INSTALL_MODE,guard=guard,executable=True)
   verify_installed_helper(helper,journal.entries[-1][1],PINS[helper.name])
   stage='CREATE_PEER_DIRECTORY'
   with guard.critical():directory=journal.own(pathlib.Path(tempfile.mkdtemp(prefix='linuxcast-root-peer-',dir='/run')),'dir');directory.chmod(0o711)
   stage='BIND_LISTENER'
   listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);objects.append(listener)
   path=directory/'peer'
   with guard.critical():listener.bind(str(path));journal.own(path,'socket');path.chmod(0o600);os.chown(path,account.pw_uid,account.pw_gid)
   listener.listen(1);listener.settimeout(.5)
   stage='FORK_CONNECTOR'
   connector_pid=family.fork(lambda parent:connector(path,account.pw_uid,account.pw_gid,parent),guard)
   stage='ACCEPT_CONNECTOR'
   stream,_=listener.accept();objects.append(stream);listener.close()
   stage='BIND_OWN_PEER'
   own_peer(stream,connector_pid,family,account.pw_uid);guard.check()
   stage='CREATE_PARENT_CHANNEL'
   parent,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_SEQPACKET);objects.extend((parent,child))
   # Preserve the creator's endpoint before reserving FD3. Both were created
   # in this actual root parent; FD3 is the only explicit exec descriptor.
   duplicate=fcntl.fcntl(parent.fileno(),fcntl.F_DUPFD_CLOEXEC,64);parent.close();parent=socket.socket(fileno=duplicate);objects.append(parent)
   stage='RESERVE_PARENT_FD'
   with guard.critical():
    os.dup2(child.fileno(),3,inheritable=True);reserved=socket.socket(fileno=3);objects.append(reserved)
   stage='SPAWN_SUPERVISOR'
   process=family.spawn([str(capsule/'linuxcast-input-spike-supervisor'),'--live-denial'],guard,env={},cwd='/',stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=(3,))
   reserved.close()
   native_started=time.monotonic();child.close()
   stage='SEND_BOOTSTRAP'
   own_peer(stream,connector_pid,family,account.pw_uid)
   parent.sendmsg([b'{"version":1,"authorized_uid":1000}'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',[stream.fileno()]))]);assert family.alive(connector_pid);public['ownConnectorPeerBound']=True;stream.close();listener.close()
   stage='OBSERVE_NATIVE'
   selector=selectors.DefaultSelector();buffers={'stdout':bytearray(),'stderr':bytearray()};totals={'stdout':0,'stderr':0}
   for kind,file in (('stdout',process.stdout),('stderr',process.stderr)):
    os.set_blocking(file.fileno(),False);selector.register(file,selectors.EVENT_READ,kind)
   while time.monotonic()-native_started<7.75:
    guard.check()
    for key,_ in selector.select(.01):
     kind=key.data;data=os.read(key.fd,2048)
     if not data:selector.unregister(key.fileobj);continue
     totals[kind]+=len(data);assert totals[kind]<=(10260 if kind=='stdout' else 384)
     buffers[kind].extend(data)
     while b'\n'in buffers[kind]:
      line,_,rest=buffers[kind].partition(b'\n');buffers[kind]=bytearray(rest)
      if kind=='stdout':
       assert len(line)<=512 and len(rows)<20;rows.append(row(json_exact(line)))
       if len(rows)==1:
        stage='READ_HELPER_PROOF'
        proof=proc_proof(process.pid,account.pw_uid,account.pw_gid,helper);public['credentialProof']=proof;public['helperStartupSelfReadbacksEstablishedByReady']=True
        stage='OBSERVE_NATIVE'
      else:
       # Only bounded fixed native diagnostics are retained; no raw strings.
       value=json_exact(line);assert set(value)=={'component','stage','code','io_kind','errno'}
       assert value['component'] in {'SUPERVISOR','DENIAL_HELPER'} and value['stage']=='STARTUP' and value['code'] in DIAGNOSTIC_CODES
       assert value['io_kind'] is None or value['io_kind'] in {'NOT_FOUND','PERMISSION_DENIED','WOULD_BLOCK','TIMED_OUT','INTERRUPTED','UNEXPECTED_EOF','BROKEN_PIPE','OTHER'}
       assert value['errno'] is None or type(value['errno'])is int and 1<=value['errno']<=4095
       diag.append(value)
    status=family.exited(process.pid)
    if status is not None and not selector.get_map():break
   else:raise AssertionError()
   stage='VALIDATE_NATIVE_RESULT'
   public['nativeExitCode']=status;public['nativeElapsedMs']=round((time.monotonic()-native_started)*1000,3)
   assert not any(buffers.values()) and status==0 and not diag and len(rows)==20 and proof is not None
   assert rows[0]['decisionVeto']=='PENDING'
   assert all(v['decisionVeto']=='REMOTE' and v['evidenceVeto']=='REMOTE' for v in rows[1:])
   public['credentialProof']=proof;public['actualRootDropProof']=True;public['noInputBranchExecuted']=True;failure=False
  except BaseException:record_failure(public,stage)
  finally:
   guard.cleanup();started=time.monotonic()
   try:public['ownedLifetimeObservation']=family.observation()
   except BaseException:public['ownedLifetimeObservation']={'knownLive':0,'knownExitReady':0,'unknown':1,'knownReaped':0}
   try:clean.update(family.stop(2))
   except BaseException:clean.update({'ownedChildrenAbsent':False,'ownedGroupsAbsent':False,'signalOperationsSucceeded':False})
   public['ownedStopElapsedMs']=round((time.monotonic()-started)*1000,3)
   for obj in objects:
    try:obj.close()
    except BaseException:pass
   if selector is not None:
    try:selector.close()
    except BaseException:pass
   try:clean['ownedObjectsRemoved']=journal.cleanup()
   except BaseException:clean['ownedObjectsRemoved']=False
   public['criticalCleanupElapsedMs']=round((time.monotonic()-started)*1000,3)
   clean['withinCleanupBudget']=time.monotonic()-started<=3
 public['cleanup']=clean;public['ordinaryCancellationObserved']=guard.cancelled
 try:public['postflight']=baseline()
 except BaseException:public['postflight']={'baselineReadable':False}
 public['helperPathAbsent']=not helper.exists() and not helper.is_symlink()
 public['wrapperGatePassed']=not failure and not guard.cancelled and all(clean.values()) and all(public['postflight'].values()) and public['helperPathAbsent']
 # No IDs, paths, bus errors, session identifiers, environment or events.
 payload=json.dumps(public,separators=(',',':'));assert len(payload)<=20000
 print(payload,flush=True)
 return 0 if public['wrapperGatePassed'] else 3
if __name__=='__main__':
 try:code=collect()
 except BaseException:
  print('{"schemaVersion":1,"operation":"ROOT_DEVICE_FREE_DENIAL_ONCE","failureCode":"ROOT_DENIAL_PREFLIGHT_INCOMPLETE","wrapperGatePassed":false}',flush=True);code=3
 raise SystemExit(code)
