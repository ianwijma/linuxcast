"""Fixed future lab collector. NO calls are authorized by this source file itself."""
import ast,hashlib,importlib.util,json,os,pathlib,re,secrets,selectors,shlex,signal,stat,subprocess,sys,time
HERE=pathlib.Path('/tmp');STATE=HERE/'linuxcast-s003-root-proof-control-helper0555'
SSH=['docker','exec','linuxcast-s0-04-vm','ssh','-q','-i','/lab/test-key','-p','2222','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/lab/known_hosts','-T','debian@127.0.0.1']
FAILURE_STAGES={'INSTALL_HELPER','CREATE_PEER_DIRECTORY','BIND_LISTENER','FORK_CONNECTOR','ACCEPT_CONNECTOR','BIND_OWN_PEER','CREATE_PARENT_CHANNEL','RESERVE_PARENT_FD','SPAWN_SUPERVISOR','SEND_BOOTSTRAP','OBSERVE_NATIVE','READ_HELPER_PROOF','VALIDATE_NATIVE_RESULT'}
CONTAINER_UID=1000
GUEST_UID=1000
SOURCES={'collector.py':HERE/'linuxcast-s003-root-proof-guest.py','family.py':HERE/'linuxcast-s003-root-proof-family.py','linuxcast-input-spike-supervisor':HERE/'linuxcast-s003-root-review-target/debug/linuxcast-input-spike-supervisor','linuxcast-input-spike-denial-helper':HERE/'linuxcast-s003-root-review-target/debug/linuxcast-input-spike-denial-helper'}
VETO={'PENDING','REMOTE','INACTIVE','NOT_GRAPHICAL','NOT_SEAT_ZERO','LOCKED','COMPANION_UNAVAILABLE','UNSUPPORTED','UNKNOWN_CONTEXT','STALE','TIMEOUT','PEER_DEAD','PEER_DISCONNECTED','EPOCH_CHANGED','CHANNEL_DISCONNECTED','HELPER_EXITED','INVALID_OBSERVATION','TERMINAL'}
DIAGNOSTIC_CODES={'PRIVATE_NONROOT_BOUNDARY_REQUIRED', 'ROOT_DENIAL_UNEXPECTED_PARENT_PACKET', 'DENIAL_NONROOT_CONNECTION_REQUIRED', 'FIXTURE_DESCRIPTOR_NOT_CLOSED', 'DENIAL_PRIVATE_DIRECTORY', 'DENIAL_AUTHORIZED_PEER_MISMATCH', 'ROOT_DENIAL_AUTHORIZATION_INVALID', 'PRIVATE_READBACK_SETUP', 'DENIAL_CONNECTOR_MISMATCH', 'DENIAL_DESCRIPTOR_CLOSURE_FAILED', 'DENIAL_CONNECTOR_FAILED', 'FD_BOUND', 'DENIAL_UNEXPECTED_WORKER_EFFECT', 'DENIAL_TERMINAL_REVIVAL', 'DENIAL_AUTHORIZED_ACCOUNT_UNAVAILABLE', 'DENIAL_PRIVATE_CLEANUP', 'DENIAL_PARENT_PIDFD', 'UNCLASSIFIED_FAILURE', 'DENIAL_SOCKET_METADATA', 'DENIAL_PRIVATE_SOCKET', 'PRIVATE_CANARY_DESCRIPTOR', 'DENIAL_AUTHORIZED_PEER_DEAD', 'PANIC', 'DENIAL_SEQUENCE_OVERFLOW', 'INTERNAL_SEND_FAILED', 'DENIAL_CHILD_REAPER_POLICY', 'PACKET_BOUND', 'PARENT_DEATH_RACE', 'DENIAL_OBSERVATION_INCOMPLETE', 'DENIAL_HELPER_BINARY_UNTRUSTED', 'DENIAL_HELPER_DIRECTORY_UNTRUSTED', 'CORE_POLICY_FAILED', 'IO_FAILURE', 'DENIAL_SOCKET_KIND', 'DENIAL_BOOTSTRAP_PARENT', 'FIXTURE_PEER_PIDFD', 'INTERNAL_TIMEOUT', 'PRIVATE_PARENT_FORK_FAILED', 'PRIVATE_CASE', 'DENIAL_BOOTSTRAP_INVALID', 'DENIAL_PUBLIC_BOUND', 'DENIAL_GUARD_FAILED', 'DENIAL_BOOTSTRAP_PARENT_LOST', 'DENIAL_HELPER_PRIVILEGES', 'DENIAL_HELPER_STARTUP_READBACK', 'INTERNAL_PACKET_INVALID', 'DENIAL_GUARD_SIGNAL_MASK', 'DENIAL_SEQUENCE_INVALID', 'PRIVATE_PARENT_CHILD_TIMEOUT', 'DENIAL_HELPER_START_FAILED', 'PRIVATE_READBACK_CHILD_TIMEOUT', 'FIXTURE_PEER_UID', 'PRIVATE_READBACK_FORK_FAILED', 'DENIAL_CONNECTOR_UNAVAILABLE', 'DENIAL_CONNECTOR_CLEANUP', 'DENIAL_CANCELLED', 'PEERCRED_UNAVAILABLE', 'DENIAL_OWNED_CLEANUP', 'DENIAL_HELPER_ENV_OR_UID', 'DENIAL_ROOT_AUTHORIZATION_REQUIRED', 'ROOT_DENIAL_EMPTY_ENV_AND_ROOT_REQUIRED', 'JSON_SCHEMA_FAILURE'}
BINARIES={'linuxcast-input-spike-supervisor':'4fd4609ab5acfd5131c403fe0b9dd9a8460bf35f698798d1025ef401401fba00','linuxcast-input-spike-denial-helper':'b80cc6a4c5577040ee679a9c657d6e6db04c8b4478cbb46ab70d6d2d883d1bc9'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def strict(data):
 def fields(items):
  result={}
  for k,v in items:assert k not in result;result[k]=v
  return result
 return json.loads(data,object_pairs_hook=fields,parse_constant=lambda value:(_ for _ in ()).throw(ValueError()))
LIFETIME=None
def lifetime():
 global LIFETIME
 if LIFETIME is None:
  spec=importlib.util.spec_from_file_location('root_proof_lifetime',HERE/'linuxcast-s003-root-proof-family.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);LIFETIME=module
 return LIFETIME

def command(argv,timeout=15,data=None,cleanup=False):
 # Production phase entry checks the complete source manifest before calling
 # this private transport primitive. The same reviewed owned-family code is
 # used here and in the guest, including adopted-descendant cleanup.
 if globals().get('controller_cancelled',False) and not cleanup:raise InterruptedError()
 assert data is None or type(data)is bytes and len(data)<=32*1024*1024
 module=lifetime();owner=module.Family();selector=selectors.DefaultSelector();result=None;process=None
 with module.Cancellation() as guard:
  if cleanup:guard.cleanup()
  try:
   process=owner.spawn(argv,guard,stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   buffers={'stdout':bytearray(),'stderr':bytearray()};sent=0;deadline=time.monotonic()+timeout;status=None
   for name,file in (('stdout',process.stdout),('stderr',process.stderr)):
    os.set_blocking(file.fileno(),False);selector.register(file,selectors.EVENT_READ,name)
   if data is not None:
    os.set_blocking(process.stdin.fileno(),False);selector.register(process.stdin,selectors.EVENT_WRITE,'stdin')
   while time.monotonic()<deadline:
    guard.check()
    for key,_ in selector.select(.01):
     if key.data=='stdin':
      if sent<len(data):sent+=os.write(key.fd,data[sent:sent+16384])
      if sent==len(data):selector.unregister(key.fileobj);key.fileobj.close()
      continue
     part=os.read(key.fd,2048)
     if not part:selector.unregister(key.fileobj);continue
     buffers[key.data].extend(part);assert len(buffers[key.data])<=(24000 if key.data=='stdout' else 384)
    status=owner.exited(process.pid)
    if status is not None and not selector.get_map():break
   else:raise TimeoutError()
   result=subprocess.CompletedProcess(argv,status,bytes(buffers['stdout']),bytes(buffers['stderr']));result.owned_cli_cleanup=False
   return result
  finally:
   # Signal handlers only mark flags, even before this first assignment.
   guard.cleanup();ok=True
   try:ok=all(owner.stop(2).values())
   except BaseException:ok=False
   for item in (selector,process.stdin if process else None,process.stdout if process else None,process.stderr if process else None):
    if item is not None:
     try:item.close()
     except BaseException:ok=False
   if result is not None:result.owned_cli_cleanup=ok and (cleanup or not guard.cancelled)

def local_gate():
 assert all(sha(SOURCES[n])==wanted for n,wanted in BINARIES.items())
 manifest=HERE/'linuxcast-s003-root-proof-files.sha256'
 for line in manifest.read_text().splitlines():
  wanted,name=line.split('  ',1);assert sha(pathlib.Path(name))==wanted
 # Runtime source gate is frozen independently of collector source; no shared
 # files, whole source tree, dependencies, keys or unrelated logs are copied.
 for line in (HERE/'linuxcast-s003-root-proof-runtime.sha256').read_text().splitlines():
  wanted,name=line.split('  ',1);assert sha(pathlib.Path('/tmp/linuxcast-s0-03')/name)==wanted
 return sha(manifest)

def own_state():
 m=STATE.lstat();assert stat.S_ISDIR(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o700
 p=STATE/'state.json';m=p.lstat();assert stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o600
 value=strict(p.read_bytes());assert set(value)=={'container','guest','files','collectorManifest','containerIdentity','guestIdentity','containerFiles','guestFiles','writerUnknown'}
 assert re.fullmatch('/lab/linuxcast-s003-root-proof-[0-9a-f]{32}',value['container'])
 assert re.fullmatch('/home/debian/linuxcast-s003-root-proof-[A-Za-z0-9_]{6,32}',value['guest'])
 assert value['writerUnknown']=={}
 assert value['files']=={n:sha(p) for n,p in SOURCES.items()} and value['collectorManifest']==sha(HERE/'linuxcast-s003-root-proof-files.sha256')
 for key in ('containerIdentity','guestIdentity'):
  assert type(value[key])is list and len(value[key])==2 and all(type(n)is int and n>=0 for n in value[key])
 for key in ('containerFiles','guestFiles'):
  assert type(value[key])is dict and set(value[key])==set(SOURCES) and all(type(a)is dict and set(a)=={'identity','complete'} and a['complete']is True and type(a['identity'])is list and len(a['identity'])==2 and all(type(n)is int and n>=0 for n in a['identity']) for a in value[key].values())
 return value

def preflight_code():
 tree=ast.parse(SOURCES['collector.py'].read_text());selected=[]
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in {'digest','read','trusted','baseline','runtime'}:selected.append(node)
  elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in {'NATIVE','OLD'} for t in node.targets):selected.append(node)
 code='import hashlib,json,os,pathlib,stat,subprocess,sys\n'+ast.unparse(ast.Module(body=selected,type_ignores=[]))
 code+="\nplatform=runtime();b=baseline();ready=all(b.values()) and os.uname().release=='6.12.113+deb13-amd64' and read(pathlib.Path('/etc/debian_version'),32).strip()=='13.7' and not (NATIVE/'linuxcast-input-spike-denial-helper').exists() and not (NATIVE/'linuxcast-input-spike-denial-helper').is_symlink() and not any(pathlib.Path('/run').glob('linuxcast-s003-root-proof-*'));print(json.dumps({'ready':ready,'baseline':b,'runtime':platform}));raise SystemExit(0 if ready else 3)"
 return code

def directory_code(path,uid,generated=False):
 # Establish the ordinary-user contract BEFORE mkdir/mkdtemp can have effects.
 return 'TARGET='+repr(path)+'\nEXPECTED_UID='+repr(uid)+'\nGENERATED='+repr(generated)+'\n'+r"""
import json,os,stat,tempfile
assert os.getuid()==os.geteuid()==EXPECTED_UID==1000
if GENERATED:p=tempfile.mkdtemp(prefix='linuxcast-s003-root-proof-',dir=TARGET)
else:os.mkdir(TARGET,0o700);p=TARGET
m=os.lstat(p);assert stat.S_ISDIR(m.st_mode) and m.st_uid==EXPECTED_UID and stat.S_IMODE(m.st_mode)==0o700
identity=[m.st_dev,m.st_ino]
print(json.dumps([p,identity] if GENERATED else identity))
"""

def precreate_code(path,identity,name,uid):
 # Both staging roles are ordinary UID1000. Root guest helper/bootstrap code
 # is a separate later phase; no Docker user override is introduced here.
 return 'DIRECTORY='+repr(path)+'\nIDENTITY='+repr(identity)+'\nNAME='+repr(name)+'\nEXPECTED_UID='+repr(uid)+'\n'+r"""
import json,os,pathlib,stat
assert os.getuid()==os.geteuid()==EXPECTED_UID
p=pathlib.Path(DIRECTORY);m=p.lstat()
assert stat.S_ISDIR(m.st_mode) and not stat.S_ISLNK(m.st_mode) and [m.st_dev,m.st_ino]==IDENTITY and m.st_uid==EXPECTED_UID and stat.S_IMODE(m.st_mode)==0o700
fd=os.open(p/NAME,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
try:
 m=os.fstat(fd);assert stat.S_ISREG(m.st_mode) and m.st_uid==EXPECTED_UID and m.st_nlink==1
 identity=[m.st_dev,m.st_ino]
finally:os.close(fd)
print(json.dumps(identity))
"""

def write_code(path,identity,uid,length,wanted):
 return 'TARGET='+repr(path)+'\nIDENTITY='+repr(identity)+'\nEXPECTED_UID='+repr(uid)+'\nLENGTH='+repr(length)+'\nWANTED='+repr(wanted)+'\n'+r"""
import hashlib,json,os,signal,stat,sys
signal.alarm(5)
assert os.getuid()==os.geteuid()==EXPECTED_UID
fd=os.open(TARGET,os.O_WRONLY|os.O_NOFOLLOW)
try:
 m=os.fstat(fd);assert [m.st_dev,m.st_ino]==IDENTITY and m.st_uid==EXPECTED_UID and stat.S_ISREG(m.st_mode) and m.st_nlink==1 and m.st_size==0
 h=hashlib.sha256();total=0
 while True:
  block=sys.stdin.buffer.read(131072)
  if not block:break
  total+=len(block);assert total<=LENGTH;h.update(block);view=memoryview(block)
  while view:
   n=os.write(fd,view);assert n>0;view=view[n:]
 assert total==LENGTH and h.hexdigest()==WANTED
 os.fsync(fd);os.fchmod(fd,0o500)
finally:os.close(fd)
print('{"stagedPinnedBytesVerified":true}')
"""

def remote_args(location,code,stdin=False):
 if location=='guest':return ['docker','exec']+(['-i'] if stdin else [])+SSH[2:]+['python3 -I -S -c '+shlex.quote(code)]
 assert location=='container'
 return ['docker','exec']+(['-i'] if stdin else [])+['linuxcast-s0-04-vm','python3','-I','-S','-c',code]
def cleanup_stages(value):
 outcomes={}
 for location,uid in (('guest',GUEST_UID),('container',CONTAINER_UID)):
  try:
   identity=value[location+'Identity'];assert identity is not None
   code=stage_cleanup_code(value[location],identity,value['files'],uid,value[location+'Files'],partial=True)
   assert not value.get('writerUnknown',{}).get(location,False)
   result=command(remote_args(location,code),cleanup=True);v=strict(result.stdout)
   outcomes[location]=result.owned_cli_cleanup and result.returncode==0 and not result.stderr and v=={'ownedStageRemoved':True,'ownedPathsAbsent':True}
  except BaseException:outcomes[location]=False
 return outcomes

def prepare():
 manifest=local_gate()
 result=command(SSH+['sudo -n /usr/bin/python3 -I -S -c '+shlex.quote(preflight_code())]);assert result.owned_cli_cleanup and result.returncode==0 and not result.stderr and strict(result.stdout)['ready']is True
 os.mkdir(STATE,0o700)
 value={'container':'/lab/linuxcast-s003-root-proof-'+secrets.token_hex(16),'guest':'','files':{n:sha(p) for n,p in SOURCES.items()},'collectorManifest':manifest,'containerIdentity':None,'guestIdentity':None,'containerFiles':{},'guestFiles':{},'writerUnknown':{}}
 complete=False
 try:
  save(value)
  code=directory_code(value['container'],CONTAINER_UID)
  result=command(remote_args('container',code));assert result.returncode==0 and not result.stderr
  value['containerIdentity']=strict(result.stdout);save(value);assert result.owned_cli_cleanup
  code=directory_code('/home/debian',GUEST_UID,generated=True)
  result=command(remote_args('guest',code));assert result.returncode==0 and not result.stderr
  guest,identity=strict(result.stdout);assert re.fullmatch('/home/debian/linuxcast-s003-root-proof-[A-Za-z0-9_]{6,32}',guest)
  value['guest']=guest;value['guestIdentity']=identity;save(value);assert result.owned_cli_cleanup
  for location,uid in (('container',CONTAINER_UID),('guest',GUEST_UID)):
   for name,path in SOURCES.items():
    # Metadata arrives and is journalled BEFORE any byte transfer. An unknown
    # create outcome remains explicitly retained; never infer its ownership.
    code=precreate_code(value[location],value[location+'Identity'],name,uid)
    result=command(remote_args(location,code));assert result.returncode==0 and not result.stderr
    entry={'identity':strict(result.stdout),'complete':False};value[location+'Files'][name]=entry;save(value);assert result.owned_cli_cleanup
    data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==value['files'][name] and len(data)<=32*1024*1024
    code=write_code(value[location]+'/'+name,entry['identity'],uid,len(data),value['files'][name])
    value['writerUnknown'][location]=True;save(value)
    result=command(remote_args(location,code,stdin=True),data=data);assert result.returncode==0 and not result.stderr and strict(result.stdout)=={'stagedPinnedBytesVerified':True}
    entry['complete']=True;value['writerUnknown'].pop(location);save(value);assert result.owned_cli_cleanup
  complete=True
 finally:
  if not complete:
   # These callbacks are independent and use the freshest in-memory ownership
   # records even when an atomic state write itself failed.
   outcomes=cleanup_stages(value)
   try:
    fd=os.open(STATE/'prepare-cleanup.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as f:json.dump({'ownedStageCleanup':outcomes,'retainedResources':not all(outcomes.values()),'prepareComplete':False},f)
   except BaseException:pass
 assert complete
 print('{"operation":"ROOT_PROOF_PREPARED","stagedPinnedBytesVerified":true}')
def save(value):
 path=STATE/'state.json'
 # First creation is exclusive; later replacement is inside our owned0700dir.
 if not path.exists():
  fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'w') as f:json.dump(value,f)
 else:
  temp=STATE/'next.json';fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'w') as f:json.dump(value,f)
  os.replace(temp,path)

BOOTSTRAP=r'''
import contextlib,ctypes,hashlib,io,json,os,pathlib,signal,stat,sys,tempfile
stage=pathlib.Path(STAGE);expected=PINS
assert os.getresuid()==(0,0,0)
cancelled=False
def interrupted(*args):
 global cancelled
 cancelled=True
def check_cancelled():
 if cancelled:raise KeyboardInterrupt()
for number in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(number,interrupted)
assert not signal.pthread_sigmask(signal.SIG_BLOCK,set()) & {signal.SIGALRM,signal.SIGTERM,signal.SIGINT}
assert signal.getsignal(signal.SIGCHLD)==signal.SIG_DFL
signal.signal(signal.SIGCHLD,signal.SIG_DFL)
parent=os.getppid();assert ctypes.CDLL(None).prctl(1,signal.SIGTERM,0,0,0)==0 and os.getppid()==parent
@contextlib.contextmanager
def critical():
 old=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGHUP,signal.SIGINT})
 try:yield
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,old)
 check_cancelled()
root=None;owned=[];cleanup=True;capture=io.StringIO();code=3
try:
 m=stage.lstat();assert stat.S_ISDIR(m.st_mode) and m.st_uid==1000 and stat.S_IMODE(m.st_mode)==0o700
 assert set(x.name for x in stage.iterdir())==set(expected)
 with critical():
  root=pathlib.Path(tempfile.mkdtemp(prefix='linuxcast-s003-root-proof-',dir='/run'));root_id=(root.stat().st_dev,root.stat().st_ino)
 for name,wanted in expected.items():
  check_cancelled()
  fd=os.open(stage/name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
  try:
   m=os.fstat(fd);assert stat.S_ISREG(m.st_mode) and m.st_uid==1000 and m.st_nlink==1 and m.st_size<=32*1024*1024
   with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(32*1024*1024+1)
   assert len(data)==m.st_size and hashlib.sha256(data).hexdigest()==wanted
  finally:os.close(fd)
  with critical():
   fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o500);m=os.fstat(fd);index=len(owned);owned.append((root/name,(m.st_dev,m.st_ino),None))
  try:
   with os.fdopen(fd,'wb',closefd=False) as f:f.write(data)
  finally:os.close(fd)
  owned[index]=(root/name,(m.st_dev,m.st_ino),wanted)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(root));sys.argv=[str(root/'collector.py'),'--collect']
 scope={'__file__':str(root/'collector.py'),'__name__':'root_fixture'}
 with contextlib.redirect_stdout(capture):
  exec(compile((root/'collector.py').read_bytes(),str(root/'collector.py'),'exec'),scope)
  code=scope['collect']()
 check_cancelled()
except BaseException:pass
finally:
 # Ordinary cancellation cannot bypass any remaining owned inode cleanup.
 for number in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(number,interrupted)
 for path,identity,wanted in reversed(owned):
  try:
   m=path.lstat();assert (m.st_dev,m.st_ino)==identity and m.st_uid==0
   if wanted is not None:assert hashlib.sha256(path.read_bytes()).hexdigest()==wanted
   # Do not delete bytes still used as any process executable.
   for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdecimal():continue
    try:assert os.readlink(p/'exe')!=str(path)
    except (FileNotFoundError,ProcessLookupError):pass
   path.unlink()
  except BaseException:cleanup=False
 if root is not None:
  try:
   m=root.lstat();assert (m.st_dev,m.st_ino)==root_id;root.rmdir()
  except BaseException:cleanup=False
try:
 raw=capture.getvalue();assert len(raw)<=20000 and len(raw.splitlines())==1
 report=json.loads(raw);assert type(report)is dict
except BaseException:report={'schemaVersion':1,'operation':'ROOT_DEVICE_FREE_DENIAL_ONCE','failureCode':'ROOT_DENIAL_BOOTSTRAP_INCOMPLETE','wrapperGatePassed':False}
result={'schemaVersion':1,'operation':'ROOT_PROOF_COLLECT_ONCE','rootReport':report,'rootCapsuleRemoved':cleanup,'bootstrapCancellationObserved':cancelled,'complete':not cancelled and code==0 and cleanup and report.get('wrapperGatePassed')is True}
print(json.dumps(result,separators=(',',':')),flush=True)
sys.exit(0 if result['complete'] else 3)
'''
def reserve_attempt(path):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:f.write('{"operation":"ROOT_PROOF_ATTEMPT","outcome":"UNKNOWN_BEFORE_DISPATCH"}\n');f.flush();os.fsync(f.fileno())
def run():
 local_gate();state=own_state();assert not (STATE/'first-result.json').exists() and not (STATE/'controller-first-failure.json').exists()
 reserve_attempt(STATE/'attempt.json')
 code='STAGE='+repr(state['guest'])+'\nPINS='+repr(state['files'])+'\n'+BOOTSTRAP
 result=command(SSH+['sudo -n /usr/bin/python3 -I -S -c '+shlex.quote(code)],timeout=22)
 assert result.returncode in (0,3) and not result.stderr
 value=strict(result.stdout);assert value['operation']=='ROOT_PROOF_COLLECT_ONCE'
 # Save the first safe result BEFORE acceptance assertions; never retry.
 validate(value)
 fd=os.open(STATE/'first-result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2);f.write('\n')
 fd=os.open(STATE/'transport-cleanup.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:json.dump({'ownedCliCleanup':result.owned_cli_cleanup},f)
 assert result.owned_cli_cleanup and result.returncode==0 and value['complete'] is True
 print('{"operation":"ROOT_PROOF_CAPTURED","complete":true}')
def validate(value):
 assert type(value)is dict and set(value)=={'schemaVersion','operation','rootReport','rootCapsuleRemoved','bootstrapCancellationObserved','complete'} and type(value['schemaVersion'])is int and value['schemaVersion']==1 and value['operation']=='ROOT_PROOF_COLLECT_ONCE'
 assert type(value['complete'])is bool and type(value['rootCapsuleRemoved'])is bool and type(value['bootstrapCancellationObserved'])is bool
 report=value['rootReport'];allowed={'schemaVersion','operation','runtime','preflight','postflight','supervisorSha256','helperSha256','actualRows','diagnostics','actualRootDropProof','ownConnectorPeerBound','pdeathProofKind','directParentDeathTrialPerformed','noInputBranchExecuted','wrapperGatePassed','failureCode','failureStage','nativeExitCode','nativeElapsedMs','credentialProof','helperStartupSelfReadbacksEstablishedByReady','cleanup','helperPathAbsent','ownedLifetimeObservation','ownedStopElapsedMs','criticalCleanupElapsedMs','ordinaryCancellationObserved'}
 assert type(report)is dict and set(report)<=allowed and type(report['schemaVersion'])is int and report['schemaVersion']==1 and report['operation']=='ROOT_DEVICE_FREE_DENIAL_ONCE'
 maps={
 'preflight':{'nativeOriginalsUnchanged','inputProgramsAbsent','graphicalSessionsAbsent','manufacturedDevicesAbsent','markerAbsent','privateDesktopRootsAbsent','guiProcessesAbsent','busBaselineUnchanged'},
 'postflight':{'nativeOriginalsUnchanged','inputProgramsAbsent','graphicalSessionsAbsent','manufacturedDevicesAbsent','markerAbsent','privateDesktopRootsAbsent','guiProcessesAbsent','busBaselineUnchanged'},
 'credentialProof':{'allUserIdsMatchExpected','allGroupIdsMatchPrimary','supplementalGroupsEmpty','capabilitiesAndAmbientEmpty','noNewPrivileges','coreSoftHardZero','descriptorCategoriesPrivate','helperExecutableHashMatches','helperParentBindingObserved','helperAliveDuringObservation'},
 'cleanup':{'ownedChildrenAbsent','ownedGroupsAbsent','signalOperationsSucceeded','ownedObjectsRemoved','withinCleanupBudget'}}
 if 'runtime'in report:
  x=report['runtime'];assert type(x)is dict and set(x)=={'distribution','debianVersion','kernel','architecture','libsystemdVersion','pythonVersion'}
  assert x['distribution']=='debian' and x['debianVersion']=='13.7' and x['kernel']=='6.12.113+deb13-amd64' and x['architecture']=='x86_64' and x['libsystemdVersion']=='257.13-1~deb13u1' and re.fullmatch('[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2}',x['pythonVersion'])
 for key,keys in maps.items():
  if key in report:
   assert type(report[key])is dict and (set(report[key])==keys or key=='postflight' and report[key]=={'baselineReadable':False}) and all(type(v)is bool for v in report[key].values())
 for key in ('actualRootDropProof','ownConnectorPeerBound','directParentDeathTrialPerformed','noInputBranchExecuted','wrapperGatePassed','helperStartupSelfReadbacksEstablishedByReady','helperPathAbsent','ordinaryCancellationObserved'):
  if key in report:assert type(report[key])is bool
 if 'actualRows'in report:
  assert type(report['actualRows'])is list and len(report['actualRows'])<=20
  for row in report['actualRows']:
   assert type(row)is dict and set(row)=={'phase','evidenceVeto','decisionVeto','canArm','workerArmEmitted','deviceBootstrapReached'} and row['phase']=='ROOT_LIVE_DENIAL_PREBOOTSTRAP'
   assert all(row[k]is False for k in ('canArm','workerArmEmitted','deviceBootstrapReached'))
   assert row['evidenceVeto'] in VETO and row['decisionVeto'] in VETO
 if 'diagnostics'in report:
  assert type(report['diagnostics'])is list and len(report['diagnostics'])<=2
  for d in report['diagnostics']:
   assert type(d)is dict and set(d)=={'component','stage','code','io_kind','errno'} and d['component']in {'SUPERVISOR','DENIAL_HELPER'} and d['stage']=='STARTUP' and d['code']in DIAGNOSTIC_CODES
   assert d['io_kind']is None or d['io_kind'] in {'NOT_FOUND','PERMISSION_DENIED','WOULD_BLOCK','TIMED_OUT','INTERRUPTED','UNEXPECTED_EOF','BROKEN_PIPE','OTHER'}
   assert d['errno']is None or type(d['errno'])is int and 1<=d['errno']<=4095
 if 'failureCode'in report:assert report['failureCode'] in {'ROOT_DENIAL_OBSERVATION_INCOMPLETE','ROOT_DENIAL_PREFLIGHT_INCOMPLETE','ROOT_DENIAL_BOOTSTRAP_INCOMPLETE'} and report['wrapperGatePassed'] is False
 if 'failureStage'in report:assert type(report['failureStage'])is str and report['failureStage']in FAILURE_STAGES and report.get('failureCode')=='ROOT_DENIAL_OBSERVATION_INCOMPLETE' and report['wrapperGatePassed']is False
 if report.get('failureCode')=='ROOT_DENIAL_OBSERVATION_INCOMPLETE':assert 'failureStage'in report
 if 'pdeathProofKind'in report:assert report['pdeathProofKind']=='READY_REQUIRES_REVIEWED_HELPER_SELF_READBACK'
 if 'directParentDeathTrialPerformed'in report:assert report['directParentDeathTrialPerformed']is False
 if 'supervisorSha256'in report:assert report['supervisorSha256']=='4fd4609ab5acfd5131c403fe0b9dd9a8460bf35f698798d1025ef401401fba00'
 if 'helperSha256'in report:assert report['helperSha256']=='b80cc6a4c5577040ee679a9c657d6e6db04c8b4478cbb46ab70d6d2d883d1bc9'
 if 'ownedLifetimeObservation'in report:
  x=report['ownedLifetimeObservation'];assert type(x)is dict and set(x)=={'knownLive','knownExitReady','unknown','knownReaped'} and all(type(n)is int and 0<=n<=64 for n in x.values())
 for key in ('ownedStopElapsedMs','criticalCleanupElapsedMs'):
  if key in report:assert type(report[key])in (int,float) and 0<=report[key]<=10000
 if 'nativeExitCode'in report:assert type(report['nativeExitCode'])is int and -64<=report['nativeExitCode']<=255
 if 'nativeElapsedMs'in report:assert type(report['nativeElapsedMs'])in (int,float) and 0<=report['nativeElapsedMs']<=8000
 if value['complete']:
  assert value['rootCapsuleRemoved']is True and value['bootstrapCancellationObserved']is False and report['ordinaryCancellationObserved']is False and report['wrapperGatePassed']is True and set(report)==allowed-{'failureCode','failureStage'}
  assert report['ownedLifetimeObservation']['unknown']==0 and report['ownedStopElapsedMs']<=2000 and report['criticalCleanupElapsedMs']<=3000
  assert all(key in report and all(report[key].values()) for key in maps)
  assert all(report[k]is True for k in ('actualRootDropProof','ownConnectorPeerBound','noInputBranchExecuted','helperStartupSelfReadbacksEstablishedByReady','helperPathAbsent'))
  assert report['nativeExitCode']==0 and report['nativeElapsedMs']<=7750 and report['diagnostics']==[] and len(report['actualRows'])==20
  assert report['actualRows'][0]['decisionVeto']=='PENDING' and all(r['decisionVeto']=='REMOTE' and r['evidenceVeto']=='REMOTE' for r in report['actualRows'][1:])
 else:assert report['wrapperGatePassed']is False or value['rootCapsuleRemoved']is False or value['bootstrapCancellationObserved']is True

def stage_cleanup_code(path,identity,files,uid,identities,partial=False):
 prefix='PATH='+repr(path)+'\nIDENTITY='+repr(identity)+'\nFILES='+repr(files)+'\nUID='+repr(uid)+'\nENTRIES='+repr(identities)+'\nPARTIAL='+repr(partial)+'\n'
 return prefix+r"""
import hashlib,json,os,pathlib,stat
p=pathlib.Path(PATH);m=p.lstat();assert [m.st_dev,m.st_ino]==IDENTITY and m.st_uid==UID and stat.S_ISDIR(m.st_mode) and stat.S_IMODE(m.st_mode)==0o700
assert set(ENTRIES)<=set(FILES)
if not PARTIAL:assert set(ENTRIES)==set(FILES) and all(x['complete']is True for x in ENTRIES.values())
ok=set(x.name for x in p.iterdir())==set(ENTRIES)
for n,entry in ENTRIES.items():
 try:
  f=p/n;m=f.lstat();assert [m.st_dev,m.st_ino]==entry['identity'] and m.st_uid==UID and stat.S_ISREG(m.st_mode) and m.st_nlink==1
  if entry['complete']:assert hashlib.sha256(f.read_bytes()).hexdigest()==FILES[n]
  for proc in pathlib.Path('/proc').iterdir():
   if not proc.name.isdecimal():continue
   try:assert os.readlink(proc/'exe')!=str(f)
   except (FileNotFoundError,ProcessLookupError):pass
  m=f.lstat();assert [m.st_dev,m.st_ino]==entry['identity'];f.unlink()
 except BaseException:ok=False
try:
 m=p.lstat();assert [m.st_dev,m.st_ino]==IDENTITY;p.rmdir()
except BaseException:ok=False
print(json.dumps({'ownedStageRemoved':ok,'ownedPathsAbsent':not p.exists()}));raise SystemExit(0 if ok else 3)
"""
def release():
 local_gate();state=own_state();value=strict((STATE/'first-result.json').read_bytes());validate(value)
 assert value['complete'] is True and not (STATE/'controller-first-failure.json').exists() and strict((STATE/'transport-cleanup.json').read_bytes())=={'ownedCliCleanup':True} and not (STATE/'release-result.json').exists()
 result=command(SSH+['sudo -n /usr/bin/python3 -I -S -c '+shlex.quote(preflight_code())]);assert result.owned_cli_cleanup and result.returncode==0 and not result.stderr and strict(result.stdout)['ready']is True
 outcomes={}
 # Independent source-stage cleanup attempts: first outcome remains unchanged.
 for name,argv in (
  ('guest',SSH+['sudo -n /usr/bin/python3 -I -S -c '+shlex.quote(stage_cleanup_code(state['guest'],state['guestIdentity'],state['files'],GUEST_UID,state['guestFiles']))]),
  ('container',['docker','exec','linuxcast-s0-04-vm','python3','-I','-S','-c',stage_cleanup_code(state['container'],state['containerIdentity'],state['files'],CONTAINER_UID,state['containerFiles'])])):
  try:
   result=command(argv,cleanup=True);report=strict(result.stdout);assert result.owned_cli_cleanup and result.returncode==0 and not result.stderr and report=={'ownedStageRemoved':True,'ownedPathsAbsent':True};outcomes[name]=True
  except BaseException:outcomes[name]=False
 result=command(SSH+['sudo -n /usr/bin/python3 -I -S -c '+shlex.quote(preflight_code())],cleanup=True);outcomes['finalBaseline']=result.owned_cli_cleanup and result.returncode==0 and not result.stderr and strict(result.stdout)['ready']is True
 fd=os.open(STATE/'release-result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:json.dump(outcomes,f,indent=2);f.write('\n')
 assert all(outcomes.values());print('{"operation":"ROOT_PROOF_OWNED_RELEASE","complete":true}')

controller_cancelled=False
def controller_signal(number,frame):
 global controller_cancelled
 controller_cancelled=True
def main():
 assert sys.argv[1:]in (['--prepare'],['--run'],['--release'])
 if sys.argv[1]=='--prepare':prepare()
 elif sys.argv[1]=='--run':run()
 else:release()
if __name__=='__main__':
 for number in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(number,controller_signal)
 try:
  main();assert not controller_cancelled
 except BaseException:
  try:
   m=STATE.lstat();assert stat.S_ISDIR(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o700
   fd=os.open(STATE/'controller-first-failure.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
   with os.fdopen(fd,'w') as f:f.write('{"operation":"ROOT_PROOF_CONTROLLER","code":"FIRST_OUTCOME_INCOMPLETE"}\n')
  except BaseException:pass
  print('{"operation":"ROOT_PROOF_CONTROLLER","code":"FIRST_OUTCOME_INCOMPLETE"}');raise SystemExit(3)
