"""Fixed read-only disposable-guest preflight. Never starts an input program."""
import hashlib,json,pathlib,shlex,subprocess,sys
ROOT=pathlib.Path('/tmp/linuxcast-s0-03')
SSH=['docker','exec','linuxcast-s0-04-vm','ssh','-q','-i','/lab/test-key','-p','2222','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/lab/known_hosts','-T','debian@127.0.0.1']
CODE=r'''
import hashlib,json,os,pathlib,pwd,stat,subprocess
EXPECTED={
'linuxcast-input-spike-supervisor':'1060b44313a1536926d89303625b9f91272a1f59a5d05ac803e026843e11ef7a',
'linuxcast-input-spike-worker':'45fae18d283eee7bfbff39fbe060b29c040d951db248d04bc5aa5eba1ce00eb8',
'linuxcast-input-spike-synthetic-lab':'9211ceb29ae2373717f2fc74d591544898ac2931c3f83deaf21186b7b6da7e51'}
NODE='e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'
BUN='10702245766b225e70bbf6235fd6b47214fd94b4760d00ffaed8ab0df57ac235'
def digest(p):
 try:return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
 except OSError:return None
counts={n:0 for n in ('gnome-shell','kwin_wayland','kwin_x11','Xvfb','electron','node','gdb','dbus-daemon')};input_count=0
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  name=(p/'comm').read_text().strip()
  if name in counts:counts[name]+=1
  exe=os.readlink(p/'exe')
  if pathlib.Path(exe).name in set(EXPECTED)|{'linuxcast-input-spike-denial-probe','linuxcast-input-spike-denial-helper','linuxcast-input-spike-peer-probe','linuxcast-input-spike-context-probe'}:input_count+=1
 except (OSError,UnicodeError):pass
sessions=pathlib.Path('/run/systemd/sessions');graphical=False
if sessions.exists():
 for p in sessions.iterdir():
  if p.is_file():graphical |= any(line in ('TYPE=x11','TYPE=wayland') for line in p.read_text().splitlines())
artifacts={}
for name,wanted in EXPECTED.items():
 p=pathlib.Path('/opt/linuxcast-input-spike')/name
 try:m=p.lstat();safe=stat.S_ISREG(m.st_mode) and m.st_uid==0 and m.st_mode&0o022==0
 except OSError:safe=False
 artifacts[name]={'sha256':digest(p),'expectedSha256':wanted,'rootOwnedRegularNonWritable':safe,'matches':safe and digest(p)==wanted}
def version(package):
 result=subprocess.run(['dpkg-query','-W','-f','${Version}',package],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=2)
 value=result.stdout.decode().strip()
 return value if result.returncode==0 and len(value)<=128 and all(c.isalnum() or c in '.+:~_-' for c in value) else None
try:
 account=pwd.getpwnam('linuxcast-input-spike');dedicated=account.pw_uid not in (0,1000) and account.pw_shell.endswith('/nologin')
except KeyError:dedicated=False
manufactured=False
for p in pathlib.Path('/sys/class/input').glob('event*/device/name'):
 try:manufactured |= p.read_text().strip() in ('Linuxcast S0-03 synthetic source','Linuxcast S0-03 passthrough virtual')
 except OSError:pass
packages={}
for name in ('vitest','vite','typescript'):
 p=pathlib.Path('/home/debian/linuxcast-input-source/node_modules')/name/'package.json'
 try:packages[name]=json.loads(p.read_text())['version']
 except (OSError,ValueError,KeyError):packages[name]=None
bun_found=any(digest(p)==BUN for p in ('/home/debian/.bun/bin/bun','/usr/local/bin/bun','/usr/bin/bun','/opt/bun/bun','/tmp/linuxcast-bun144/bun-linux-x64/bun'))
roots_absent=all(not any(pathlib.Path('/tmp').glob(prefix)) for prefix in ('linuxcast-s001-matrix-*','linuxcast-s002-*','linuxcast-peer-observer-*','linuxcast-denial-*'))
release=dict(line.split('=',1) for line in pathlib.Path('/etc/os-release').read_text().splitlines() if '=' in line)
value={'schemaVersion':1,'task':'S0-03','operation':'READ_ONLY_PREFLIGHT','distribution':release.get('ID','').strip('"'),'debianVersion':pathlib.Path('/etc/debian_version').read_text().strip(),'kernel':os.uname().release,'architecture':os.uname().machine,'libsystemdVersion':version('libsystemd0:amd64'),'libevdevVersion':version('libevdev2:amd64'),'processCounts':counts,'inputProcessesAbsent':input_count==0,'graphicalSessionsAbsent':not graphical,'markerAbsent':not pathlib.Path('/run/linuxcast-input-spike-lab').exists(),'manufacturedDevicesAbsent':not manufactured,'privateRootsAbsent':roots_absent,'dedicatedNonloginAccountValid':dedicated,'acceptedArtifacts':artifacts,'nodeChecksumMatches':digest('/tmp/linuxcast-node24/node')==NODE,'acceptedBunFound':bun_found,'fixturePackageVersions':packages,'inputProgramsExecuted':False,'markerCreated':False,'policyChanged':False}
value['ready']=value['distribution']=='debian' and value['debianVersion']=='13.7' and value['kernel']=='6.12.113+deb13-amd64' and value['architecture']=='x86_64' and value['libsystemdVersion']=='257.13-1~deb13u1' and value['libevdevVersion'] is not None and (value['libevdevVersion']=='1.13.4' or value['libevdevVersion'].startswith(('1.13.4+','1.13.4-'))) and all(n==0 for k,n in counts.items() if k!='dbus-daemon') and counts['dbus-daemon']==2 and all(value[k] for k in ('inputProcessesAbsent','graphicalSessionsAbsent','markerAbsent','manufacturedDevicesAbsent','privateRootsAbsent','dedicatedNonloginAccountValid','nodeChecksumMatches','acceptedBunFound')) and all(v['matches'] for v in artifacts.values()) and packages['vitest']=='4.1.12'
print(json.dumps(value))
'''
def main():
 for line in pathlib.Path('/tmp/linuxcast-s003-denial-files.sha256').read_text().splitlines():
  expected,p=line.split('  ',1)
  assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==expected
 result=subprocess.run(SSH+['sudo -n python3 -c '+shlex.quote(CODE)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert result.returncode==0 and not result.stderr and len(result.stdout)<=20000
 value=json.loads(result.stdout);assert value['operation']=='READ_ONLY_PREFLIGHT'
 assert sys.argv[1:] in ([],['--after-runtime'])
 name='denial-guest-preflight-after-runtime.json' if sys.argv[1:] else 'denial-guest-preflight.json'
 path=ROOT/'spikes/input/evidence'/name;assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')
 print(json.dumps(value))
 if not value['ready']:sys.exit(3)
if __name__=='__main__':
 try:main()
 except Exception:
  print('{"code":"READ_ONLY_PREFLIGHT_INCOMPLETE"}');sys.exit(3)
