"""Reviewed fixed private-stage observer capture; not a general process runner."""
import hashlib,json,os,pathlib,re,selectors,signal,stat,subprocess,sys,time
import importlib.util
_group_spec=importlib.util.spec_from_file_location('fixed_owned_group',pathlib.Path(__file__).with_name('linuxcast-s003-denial-owned-group.py' if pathlib.Path(__file__).parent==pathlib.Path('/tmp') else 'owned_group.py'))
_group_module=importlib.util.module_from_spec(_group_spec);_group_spec.loader.exec_module(_group_module)
OwnedExperiment=_group_module.OwnedExperiment

EXPECTED={'linuxcast-input-spike-denial-probe':'b6c526b5bb853cab416b27bea36c0b216c2cd11bd946de266dc7e301eef7b7d4','linuxcast-input-spike-denial-helper':'f0e96dbc18b9a2726b52f3a80ad9b0b6f8e2973146d849a48c2d90f563b1a9e2'}
VETO={'PENDING','REMOTE','INACTIVE','NOT_GRAPHICAL','NOT_SEAT_ZERO','LOCKED','COMPANION_UNAVAILABLE','UNSUPPORTED','UNKNOWN_CONTEXT','STALE','TIMEOUT','PEER_DEAD','PEER_DISCONNECTED','EPOCH_CHANGED','CHANNEL_DISCONNECTED','HELPER_EXITED','INVALID_OBSERVATION','TERMINAL'}
PHASE=('BEFORE_CONTROLLED_TERMINATION','AFTER_CONTROLLED_TERMINATION')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checked_stage():
 p=pathlib.Path(__file__).resolve().parent
 assert p.parent==pathlib.Path('/tmp') and re.fullmatch('linuxcast-s003-denial-stage-[A-Za-z0-9_]+',p.name)
 m=p.lstat();assert stat.S_ISDIR(m.st_mode) and m.st_uid==os.getuid()!=0 and stat.S_IMODE(m.st_mode)==0o700
 for name,expected in EXPECTED.items():
  f=p/name;m=f.lstat();assert stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o500 and digest(f)==expected
 return p
def safe_platform():
 version=subprocess.run(['dpkg-query','-W','-f','${Version}','libsystemd0:amd64'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=2)
 text=version.stdout.decode().strip();assert version.returncode==0 and re.fullmatch('[A-Za-z0-9.+:~_-]{1,128}',text)
 kernel=os.uname().release;assert kernel=='6.12.113+deb13-amd64'
 assert pathlib.Path('/etc/debian_version').read_text().strip()=='13.7' and os.uname().machine=='x86_64' and text=='257.13-1~deb13u1'
 query=subprocess.run(['loginctl','show-session','self','-p','Type','--value'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=2)
 assert query.returncode==0 and not query.stderr and query.stdout.strip() in (b'tty',b'x11',b'wayland',b'unspecified')
 return {'distribution':'Debian','debianVersion':'13.7','architecture':'x86_64','kernel':kernel,'libsystemdVersion':text,'selfType':query.stdout.decode().strip(),'stdinIsTty':os.isatty(0)}
def validate_rows(data):
 rows=[];rejected=False
 for line in data.splitlines():
  try:
   assert len(rows)<20 and 0<len(line)<=512
   row=json.loads(line);assert type(row)is dict and set(row)=={'phase','evidenceVeto','decisionVeto','canArm','workerArmEmitted'}
   assert row['phase'] in PHASE and row['evidenceVeto'] in VETO and row['decisionVeto'] in VETO
   assert type(row['canArm'])is bool and type(row['workerArmEmitted'])is bool and not row['canArm'] and not row['workerArmEmitted']
   rows.append(row)
  except (AssertionError,ValueError,TypeError):rejected=True;break
 if data and not data.endswith(b'\n'):rejected=True
 return rows,rejected
def valid_success(rows):
 if len(rows)!=20:return False
 for i,row in enumerate(rows):
  if row['phase']!=PHASE[i>=10]:return False
  if row['decisionVeto']!=('PENDING' if i==0 else 'REMOTE'):return False
  allowed={'PENDING'} if i==0 else {'REMOTE'} if i<10 else {'REMOTE','PEER_DEAD'} if i<12 else {'PEER_DEAD'}
  if row['evidenceVeto'] not in allowed:return False
 return True
def diagnostics(data):
 result=[]
 for line in data.splitlines():
  item=json.loads(line)
  assert type(item)is dict and set(item)=={'component','stage','code','io_kind','errno'} and len(result)<1
  assert item['component']=='DENIAL_PROBE' and item['stage']=='STARTUP'
  assert item['code'] in {'DENIAL_OBSERVATION_INCOMPLETE','DENIAL_OWNED_CLEANUP','DENIAL_CONNECTOR_CLEANUP','DENIAL_CANCELLED','DENIAL_UNEXPECTED_WORKER_EFFECT','IO_FAILURE','UNCLASSIFIED_FAILURE','JSON_SCHEMA_FAILURE','PANIC'}
  assert item['io_kind'] is None or item['io_kind'] in {'NOT_FOUND','PERMISSION_DENIED','WOULD_BLOCK','TIMED_OUT','INTERRUPTED','UNEXPECTED_EOF','BROKEN_PIPE','OTHER'}
  assert item['errno'] is None or type(item['errno'])is int and 1<=item['errno']<=4095
  result.append(item)
 return result

def capture(stage):
 metadata=safe_platform();assert not pathlib.Path('/run/linuxcast-input-spike-lab').exists()
 # One-shot private capture token; never the input-lab enabling marker.
 fd=os.open(stage/'capture.started',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.close(fd)
 started=time.monotonic();end=started+7.75;cleanup_end=started+8
 owner=OwnedExperiment();process=None;survivors=False;group_status={};selector=selectors.DefaultSelector();buffers={'stdout':bytearray(),'stderr':bytearray()};timeout=False;bounds=False;reaped=False;group_absent=False
 try:
  process=owner.start([str(stage/'linuxcast-input-spike-denial-probe'),'--observe-private-denial'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={})
  for name,stream in [('stdout',process.stdout),('stderr',process.stderr)]:
   os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,name)
  while selector.get_map():
   remaining=end-time.monotonic()
   if remaining<=0:timeout=True;break
   for key,_ in selector.select(min(.025,remaining)):
    data=os.read(key.fileobj.fileno(),4096)
    if not data:selector.unregister(key.fileobj);continue
    buffers[key.data].extend(data)
    if len(buffers[key.data])>(10260 if key.data=='stdout' else 384):bounds=True;break
   if bounds:break
  if not(timeout or bounds):
   while owner.leader_exit()is None and time.monotonic()<end:time.sleep(.005)
   timeout=owner.leader_exit()is None
  survivors=owner.surviving_group()
 finally:
  if owner.process is not None:
   process=owner.process
   try:group_status=owner.stop(cleanup_end,.05)
   except Exception:group_status={}
   reaped=group_status.get('leaderReaped',False)
   group_absent=group_status.get('ownedProcessGroupsAbsent',False) and group_status.get('ownedChildrenAbsent',False)
   for stream in (process.stdout,process.stderr):
    if stream:stream.close()
  selector.close()
 rows,rejected=validate_rows(buffers['stdout'])
 try:diags=diagnostics(buffers['stderr']);diag_rejected=False
 except (AssertionError,ValueError,TypeError):diags=[];diag_rejected=True
 hashes={name:digest(stage/name) for name in EXPECTED}
 paths_absent=not any(pathlib.Path('/tmp').glob('linuxcast-denial-*'))
 complete=process is not None and process.returncode==0 and reaped and group_absent and not(timeout or bounds or rejected or diag_rejected or buffers['stderr'] or survivors) and group_status.get('signalOperationsSucceeded',False) and paths_absent and hashes==EXPECTED and metadata['selfType']=='tty' and valid_success(rows)
 return {'schemaVersion':1,'task':'S0-03','outcome':'ACTUAL_NEGATIVE_DECISION_CONSUMPTION' if complete else 'ACTUAL_DENIAL_CAPTURE_INCOMPLETE','runtime':metadata,'elapsedMs':round((time.monotonic()-started)*1000,3),'exitCode':process.returncode if process else None,'outerTimeout':timeout,'boundsRejected':bounds,'schemaRejected':rejected or diag_rejected,'stdoutBytes':len(buffers['stdout']),'stderrBytes':len(buffers['stderr']),'rows':rows,'diagnostics':diags,'wrapperReaped':reaped,'ownedProcessGroupAbsent':group_absent,'survivingGroupDetected':survivors,'observerTemporaryPathsAbsent':paths_absent,'binaryHashesAfter':hashes,'complete':complete,'inputOperationsPerformed':False,'supervisorLiveEnforcementEstablished':False,'ac01Complete':False,'ac02Complete':False}

def main():
 assert sys.argv[1:]==['--capture-denial']
 stage=checked_stage();value=capture(stage);print(json.dumps(value))
if __name__=='__main__':
 try:main()
 except Exception:
  print('{"schemaVersion":1,"task":"S0-03","outcome":"CAPTURE_PLUMBING_INCOMPLETE","code":"FIXED_CAPTURE_FAILED","complete":false}')
  sys.exit(3)
