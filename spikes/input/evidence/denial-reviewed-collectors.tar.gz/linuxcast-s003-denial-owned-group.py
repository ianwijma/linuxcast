"""Owned experiment cleanup. Never signals a caller-selected PID or PGID.
Primary constants: Linux v6.12 include/uapi/linux/pidfd.h and linux/prctl.h.
https://raw.githubusercontent.com/torvalds/linux/v6.12/include/uapi/linux/pidfd.h
https://man7.org/linux/man-pages/man2/pidfd_send_signal.2.html
"""
import ctypes,os,pathlib,signal,subprocess,time
PIDFD_SIGNAL_PROCESS_GROUP=1<<2
PR_SET_CHILD_SUBREAPER=36

def children():
 return [int(x) for x in pathlib.Path('/proc/self/task',str(os.getpid()),'children').read_text().split()]

def group_absent(pgid):
 try:os.killpg(pgid,0);return False  # Read-only absence check; never a signal target.
 except ProcessLookupError:return True
 except PermissionError:return False

class OwnedExperiment:
 def __init__(self):
  # Dedicated single-threaded wrapper must have no unrelated asynchronous child.
  assert not children() and signal.getsignal(signal.SIGCHLD)==signal.SIG_DFL
  libc=ctypes.CDLL(None,use_errno=True)
  assert libc.prctl(PR_SET_CHILD_SUBREAPER,1,0,0,0)==0
  self.process=None;self.handles={};self.groups=set();self.signal_fault=False;self.leader_status=None;self.unbound=set()
 def start(self,argv,**kwargs):
  assert self.process is None and not children() and 'start_new_session' not in kwargs
  self.process=subprocess.Popen(argv,start_new_session=True,**kwargs)
  # Direct, unreaped child: its PID cannot have been reused before pidfd_open.
  self._adopt()
  assert self.process.pid in self.handles
  return self.process
 def _adopt(self):
  try:current=children()
  except Exception:self.signal_fault=True;return
  for pid in current:
   if pid in self.handles:continue
   fd=None
   try:
    # This dedicated subreaper has no unrelated children or competing reaper.
    # A direct unreaped child's numeric PID cannot be reused before waitpid.
    fd=os.pidfd_open(pid,0)
    assert pid in children()
    pgid=os.getpgid(pid);self.handles[pid]=(fd,pgid);self.groups.add(pgid);self.unbound.discard(pid)
   except Exception:
    if fd is not None:os.close(fd)
    self.unbound.add(pid);self.signal_fault=True
 def leader_exit(self):
  if self.process is None:return None
  if self.process.returncode is not None:return self.process.returncode
  result=os.waitid(os.P_PID,self.process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
  if result is None:return None
  self.leader_status=result.si_status if result.si_code==os.CLD_EXITED else -result.si_status
  return self.leader_status
 def surviving_group(self):
  if self.leader_exit()is None:return False
  self._adopt()
  return any(pid!=self.process.pid for pid in set(self.handles)|self.unbound)
 def _signal(self,number):
  self._adopt()
  for pid,(fd,pgid) in list(self.handles.items()):
   # Group scope requires a real group leader. Other owned orphan members
   # are stopped individually; no numeric-PGID mutation fallback exists.
   flags=PIDFD_SIGNAL_PROCESS_GROUP if pid==pgid and pgid!=os.getpgrp() else 0
   try:signal.pidfd_send_signal(fd,number,None,flags)
   except ProcessLookupError:pass
   except OSError:self.signal_fault=True
  # Operational cleanup only, never peer authentication: if acquiring a pidfd
  # failed, stop only a still-unreaped direct child from the kernel child list.
  # Do not use a numeric group signal or reap it before this last signal.
  for pid in list(self.unbound):
   try:
    if pid in children():os.kill(pid,number)
    else:self.unbound.discard(pid)
   except ProcessLookupError:pass
   except Exception:self.signal_fault=True
 def _reap(self):
  self._adopt()
  for pid,(fd,_) in list(self.handles.items()):
   try:done,status=os.waitpid(pid,os.WNOHANG)
   except ChildProcessError:
    # A known Popen leader may already have been reaped by an earlier caller;
    # orphan children remain separately bound and must still be stopped.
    if self.process is None or pid!=self.process.pid or self.process.returncode is None:self.signal_fault=True
    done=pid;status=None
   if done:
    if self.process is not None and pid==self.process.pid and status is not None:self.process.returncode=os.waitstatus_to_exitcode(status)
    os.close(fd);del self.handles[pid]
  for pid in list(self.unbound):
   try:done,status=os.waitpid(pid,os.WNOHANG)
   except ChildProcessError:done=pid;status=None
   except Exception:self.signal_fault=True;continue
   if done:
    if self.process is not None and pid==self.process.pid and status is not None:self.process.returncode=os.waitstatus_to_exitcode(status)
    self.unbound.discard(pid)
 def stop(self,deadline,term_grace):
  if self.process is None:return {'leaderReaped':True,'ownedChildrenAbsent':True,'ownedProcessGroupsAbsent':True,'signalOperationsSucceeded':True}
  # Always TERM the owned group, even if its leader has already exited.
  self._signal(signal.SIGTERM)
  hard_after=min(deadline,time.monotonic()+term_grace)
  while time.monotonic()<deadline:
   self._reap()
   if not self.handles and not self.unbound and not children():break
   self._signal(signal.SIGTERM if time.monotonic()<hard_after else signal.SIGKILL)
   time.sleep(min(.005,max(0,deadline-time.monotonic())))
  self._reap()
  return {'leaderReaped':self.process.returncode is not None,'ownedChildrenAbsent':not self.handles and not self.unbound and not children(),'ownedProcessGroupsAbsent':all(group_absent(g) for g in self.groups),'signalOperationsSucceeded':not self.signal_fault}
