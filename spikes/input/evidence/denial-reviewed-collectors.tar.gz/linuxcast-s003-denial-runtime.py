"""Create/cleanup only the two MISSING disposable pinned runtime trees.
Existing objects are never replaced. Unexpected existing metadata stops this tool.
"""
import hashlib,json,os,pathlib,stat,sys
TOOLS=(('/tmp/linuxcast-node24','node','node-runtime','e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'),('/tmp/linuxcast-bun144/bun-linux-x64','bun','bun-runtime','10702245766b225e70bbf6235fd6b47214fd94b4760d00ffaed8ab0df57ac235'))
DIRECTORIES=('/tmp/linuxcast-node24','/tmp/linuxcast-bun144','/tmp/linuxcast-bun144/bun-linux-x64')
def stage():
 p=pathlib.Path(__file__).resolve().parent;m=p.lstat()
 assert p.parent==pathlib.Path('/tmp') and p.name.startswith('linuxcast-s003-denial-stage-') and m.st_uid==os.getuid()!=0 and stat.S_IMODE(m.st_mode)==0o700
 return p
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_journal(p,value):
 data=json.dumps(value).encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
 try:os.ftruncate(fd,0);os.write(fd,data);os.fsync(fd)
 finally:os.close(fd)
def install(p):
 journal=p/'runtime-journal.json';assert not journal.exists()
 # This exact observation was reviewed as all MISSING. Any appearance before
 # creation is a prerequisite change: do not replace, chmod or follow it.
 assert all(not pathlib.Path(d).exists() and not pathlib.Path(d).is_symlink() for d in DIRECTORIES)
 for _,_,source,wanted in TOOLS:
  s=p/source;m=s.lstat();assert stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and digest(s)==wanted
 value={'previousState':'ALL_MISSING','directories':[],'files':[]};write_journal(journal,value)
 try:
  for d in DIRECTORIES:
   os.mkdir(d,0o700);m=pathlib.Path(d).lstat();value['directories'].append({'path':d,'device':m.st_dev,'inode':m.st_ino});write_journal(journal,value)
  for directory,name,source,wanted in TOOLS:
   target=pathlib.Path(directory)/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o500)
   try:
    m=os.fstat(fd);value['files'].append({'path':str(target),'device':m.st_dev,'inode':m.st_ino,'sha256':wanted});write_journal(journal,value)
    data=(p/source).read_bytes();offset=0
    while offset<len(data):offset+=os.write(fd,data[offset:])
    os.fsync(fd)
   finally:os.close(fd)
   assert digest(target)==wanted and stat.S_IMODE(target.stat().st_mode)==0o500
 except Exception:
  # Leave the private journal for exact-object cleanup, never delete unknown
  # prior bytes or conceal an incomplete operation.
  raise
 return {'operation':'CREATE_MISSING_PINNED_RUNTIME','complete':True,'priorRuntimeObjectsReplaced':False,'nodeHashMatches':True,'bunHashMatches':True}
def cleanup(p):
 journal=p/'runtime-journal.json';m=journal.lstat();assert m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o600
 value=json.loads(journal.read_text());assert value['previousState']=='ALL_MISSING'
 allowed={str(pathlib.Path(d)/n) for d,n,_,_ in TOOLS}
 for f in reversed(value['files']):
  assert f['path'] in allowed;target=pathlib.Path(f['path']);m=target.lstat()
  assert stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and (m.st_dev,m.st_ino)==(f['device'],f['inode'])
  # A partial write is still this exclusively-created inode; no prior file
  # existed. Never follow a symlink or remove an unrelated replacement.
  target.unlink()
 for item in reversed(value['directories']):
  assert item['path'] in DIRECTORIES;d=pathlib.Path(item['path']);m=d.lstat()
  assert stat.S_ISDIR(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o700 and (m.st_dev,m.st_ino)==(item['device'],item['inode']);d.rmdir()
 journal.unlink()
 return {'operation':'REMOVE_CREATED_PINNED_RUNTIME','complete':True,'originalAllMissingStateRestored':all(not pathlib.Path(d).exists() for d in DIRECTORIES)}
def main():
 p=stage()
 if sys.argv[1:]==['--install-missing']:value=install(p)
 elif sys.argv[1:]==['--cleanup-created']:value=cleanup(p)
 else:raise AssertionError()
 print(json.dumps(value))
if __name__=='__main__':
 try:main()
 except Exception:
  print('{"operation":"RUNTIME_PREPARATION","complete":false,"code":"FIXED_RUNTIME_PREREQUISITE_CHANGED"}');sys.exit(3)
