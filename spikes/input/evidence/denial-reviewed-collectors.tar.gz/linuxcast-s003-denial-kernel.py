"""Fixed guest-only mapped synthetic regression wrapper. Requires root review.
No physical target, dependency installer, arbitrary executable or policy input.
"""
import contextlib,hashlib,json,os,pathlib,re,selectors,signal,stat,subprocess,sys,time,uuid
import importlib.util
_group_spec=importlib.util.spec_from_file_location('fixed_owned_group',pathlib.Path(__file__).with_name('linuxcast-s003-denial-owned-group.py' if pathlib.Path(__file__).parent==pathlib.Path('/tmp') else 'owned_group.py'))
_group_module=importlib.util.module_from_spec(_group_spec);_group_spec.loader.exec_module(_group_module)
OwnedExperiment=_group_module.OwnedExperiment

NATIVE=pathlib.Path('/opt/linuxcast-input-spike');MARKER=pathlib.Path('/run/linuxcast-input-spike-lab')
OLD={'linuxcast-input-spike-supervisor':'1060b44313a1536926d89303625b9f91272a1f59a5d05ac803e026843e11ef7a','linuxcast-input-spike-worker':'45fae18d283eee7bfbff39fbe060b29c040d951db248d04bc5aa5eba1ce00eb8','linuxcast-input-spike-synthetic-lab':'9211ceb29ae2373717f2fc74d591544898ac2931c3f83deaf21186b7b6da7e51'}
NEW='2e959061d64eff7e2e051cc8ec402d0270512a9dd8bc1cbbd184675604d9953d'
NODE='e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb';BUN='10702245766b225e70bbf6235fd6b47214fd94b4760d00ffaed8ab0df57ac235'
SCENARIOS=['worker-sigkill','supervisor-sigkill','worker-watchdog','app-lease','emergency','locked','unknown-lock','inactive','tty','remote','stale-context','stale-generation','peer-credentials-and-context-revoke','prearm-completed-input-backlog']
BOOLS={'syntheticModifiersObserved','otherClientRegrabbed','virtualDeviceRemoved','noAutomaticRearm','armDenied','otherClientCanGrab','wrongUidDenied','rootPeerPassedDAC','rootPeerUidDeniedBeforeAuthorizedClient','contextRevocationDisarms','preArmCompletedInputNotForwarded','freshPostArmInputObserved','withinLimit','grabReleased'}
NUMBERS={'recoveryMs','observedMs','mechanismDeadlineMs','observerToleranceMs','kernelTeardownBudgetMs'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe_file(p):
 m=p.lstat();return stat.S_ISREG(m.st_mode) and m.st_uid==0 and m.st_mode&0o022==0
def baseline():
 names={'gnome-shell','kwin_wayland','kwin_x11','Xvfb','electron','node','gdb'};clear=True;input_clear=True
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   clear &= (p/'comm').read_text().strip() not in names
   input_clear &= pathlib.Path(os.readlink(p/'exe')).name not in OLD
  except (OSError,UnicodeError):pass
 graphical=False
 for p in pathlib.Path('/run/systemd/sessions').glob('*'):
  if p.is_file():graphical |= any(s in ('TYPE=x11','TYPE=wayland') for s in p.read_text().splitlines())
 manufactured=False
 for p in pathlib.Path('/sys/class/input').glob('event*/device/name'):
  try:manufactured |= p.read_text().strip() in ('Linuxcast S0-03 synthetic source','Linuxcast S0-03 passthrough virtual')
  except OSError:pass
 return {'graphicalProcessesAbsent':clear,'inputProcessesAbsent':input_clear,'graphicalSessionsAbsent':not graphical,'manufacturedDevicesAbsent':not manufactured}
def copy_exclusive(source,target,mode,owned):
 fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
 try:
  m=os.fstat(fd);owned[str(target)]=(m.st_dev,m.st_ino)
  data=source.read_bytes();offset=0
  while offset<len(data):offset+=os.write(fd,data[offset:])
  os.fchmod(fd,mode);os.fchown(fd,0,0);os.fsync(fd)
 finally:os.close(fd)
def unlink_owned(path,owned):
 if str(path) not in owned:return True  # Unowned/pre-existing object is preserved.
 try:m=path.lstat()
 except FileNotFoundError:return True
 if not stat.S_ISREG(m.st_mode) or m.st_uid!=os.getuid() or (m.st_dev,m.st_ino)!=owned[str(path)]:return False
 path.unlink();return True

def cleanup_steps(steps):
 result={}
 for name,action in steps:
  try:result[name]=action() is True
  except Exception:result[name]=False
 return result

class OrdinaryCancellation(Exception):pass
class CancellationGuard:
 def __init__(self):
  assert not {signal.SIGTERM,signal.SIGHUP,signal.SIGINT}&signal.pthread_sigmask(signal.SIG_BLOCK,set())
  self.cancelled=False
  for number in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(number,self.cancel)
 def cancel(self,number,frame):
  self.cancelled=True
  self.begin_cleanup()
  raise OrdinaryCancellation()
 @contextlib.contextmanager
 def critical(self):
  numbers={signal.SIGTERM,signal.SIGHUP,signal.SIGINT}
  old=signal.pthread_sigmask(signal.SIG_BLOCK,numbers)
  try:yield old
  finally:signal.pthread_sigmask(signal.SIG_SETMASK,old)
 def start_owned(self,owner,argv,**kwargs):
  assert 'preexec_fn' not in kwargs
  # Dedicated single-threaded wrapper only. Parent bookkeeping stays protected,
  # while exec descendants receive the original mask, not this critical mask.
  with self.critical() as previous:
   def restore_child_mask():signal.pthread_sigmask(signal.SIG_SETMASK,previous)
   return owner.start(argv,preexec_fn=restore_child_mask,**kwargs)
 def begin_cleanup(self):
  # Further ordinary cancellation cannot interrupt bounded independent cleanup.
  for number in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(number,signal.SIG_IGN)

def kernel_report(path):
 value=json.loads(path.read_text());assert type(value)is dict and set(value)=={'exitCode','report'}
 assert value['exitCode']is None or type(value['exitCode'])is int
 report=value['report'];assert type(report)is dict and set(report)=={'task','physicalHardwareProof','status','results'}
 assert report['task'] in ('S0-03',None) and (report['physicalHardwareProof'] is False or report['physicalHardwareProof'] is None) and report['status'] in ('PASSED','FAILED','INVALID_REPORT')
 assert type(report['results'])is list and len(report['results'])<=14
 for i,row in enumerate(report['results']):
  assert type(row)is dict and set(row)<=BOOLS|NUMBERS|{'scenario','watchdogKill','leaseDisarm','status','failureCode'} and row['scenario']==SCENARIOS[i]
  assert all(type(v)is bool for k,v in row.items() if k in BOOLS)
  assert all(type(v)is int and 0<=v<2**64 for k,v in row.items() if k in NUMBERS)
  for key,fields in [('watchdogKill',{'lastHeartbeatMs','detectedMs','killIssuedMs'}),('leaseDisarm',{'leaseUntilMs','requestedMs'})]:
   obj=row.get(key)
   assert obj is None or type(obj)is dict and set(obj)==fields and all(type(v)is int and 0<=v<2**64 for v in obj.values())
  assert row.get('status') in (None,'FAILED') and row.get('failureCode') in (None,'KERNEL_RECOVERY_TIMEOUT','ACTION_OR_KERNEL_TEARDOWN_BOUND')
 return value

def main():
 assert sys.argv[1:]==['--run-mapped-synthetic-gate'] and os.getuid()==0
 stage=pathlib.Path(__file__).resolve().parent;assert stage.parent==pathlib.Path('/tmp') and stage.name.startswith('linuxcast-s003-denial-stage-')
 meta=stage.lstat();assert stat.S_ISDIR(meta.st_mode) and meta.st_uid==1000 and stat.S_IMODE(meta.st_mode)==0o700
 # Caller stages only a reviewed archive plus immutable existing package cache.
 source=stage/'source';manifest=json.loads((stage/'kernel-source-manifest.json').read_text());assert type(manifest)is dict
 assert manifest and all(type(k)is str and not k.startswith('/') and '..' not in pathlib.PurePosixPath(k).parts and re.fullmatch('[a-f0-9]{64}',v) for k,v in manifest.items())
 assert all(digest(source/k)==v for k,v in manifest.items())
 assert digest(pathlib.Path('/tmp/linuxcast-node24/node'))==NODE and digest(pathlib.Path('/tmp/linuxcast-bun144/bun-linux-x64/bun'))==BUN
 assert digest(stage/'refactored-supervisor')==NEW
 for p in (pathlib.Path('/opt'),NATIVE):
  m=p.lstat();assert stat.S_ISDIR(m.st_mode) and m.st_uid==0 and m.st_mode&0o022==0
 assert all(safe_file(NATIVE/n) and digest(NATIVE/n)==wanted for n,wanted in OLD.items())
 for name in ('ssh','pty'):
  evidence=json.loads((stage/('denial-'+name+'-passed.json')).read_text());assert evidence['complete']is True and evidence['outcome']=='ACTUAL_NEGATIVE_DECISION_CONSUMPTION'
 assert all(baseline().values()) and not MARKER.exists()
 owned={}
 prior=(NATIVE/'linuxcast-input-spike-supervisor').stat();backup=stage/'prior-supervisor.bin';copy_exclusive(NATIVE/'linuxcast-input-spike-supervisor',backup,0o500,owned)
 assert digest(backup)==OLD['linuxcast-input-spike-supervisor']
 temp=NATIVE/'.linuxcast-reviewed-supervisor-new';restore_temp=NATIVE/('.linuxcast-reviewed-supervisor-restore-'+uuid.uuid4().hex);marker_identity=None;process=None;replaced=False;result=None;cleanup={};started=time.monotonic();exit_code=None;timeout=False;bounds=False;buffers={'stdout':bytearray(),'stderr':bytearray()};selector=selectors.DefaultSelector();phase_failed=False;owner=None;group_status={};survivors=False;run_end=None
 cancellation=CancellationGuard()
 try:
  with cancellation.critical():
   copy_exclusive(stage/'refactored-supervisor',temp,0o555,owned);assert digest(temp)==NEW;os.replace(temp,NATIVE/'linuxcast-input-spike-supervisor');replaced=True
  # Same root wrapper rechecks graphical baseline immediately before enabling.
  assert all(baseline().values()) and not MARKER.exists()
  with cancellation.critical():
   fd=os.open(MARKER,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
   try:
    m=os.fstat(fd);marker_identity=(m.st_dev,m.st_ino);os.fchmod(fd,0o600)
    data=b'S0-03 disposable Debian synthetic devices only\n';assert os.write(fd,data)==len(data);os.fsync(fd)
   finally:os.close(fd)
  worktmp=stage/'runner-tmp';worktmp.mkdir(mode=0o700)
  owner=OwnedExperiment()
  process=cancellation.start_owned(owner,['/tmp/linuxcast-bun144/bun-linux-x64/bun','run','test:security','--','S0-03'],cwd=source,env={'PATH':'/tmp/linuxcast-bun144/bun-linux-x64:/tmp/linuxcast-node24:/usr/sbin:/usr/bin:/sbin:/bin','TMPDIR':str(worktmp),'LANG':'C.UTF-8'},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  end=time.monotonic()+195;run_end=end
  for name,stream in [('stdout',process.stdout),('stderr',process.stderr)]:os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,name)
  while selector.get_map():
   if time.monotonic()>=end:timeout=True;break
   for key,_ in selector.select(.05):
    data=os.read(key.fileobj.fileno(),4096)
    if not data:selector.unregister(key.fileobj);continue
    buffers[key.data].extend(data)
    if len(buffers[key.data])>256*1024:bounds=True;break
   if bounds:break
  if not(timeout or bounds):
   while owner.leader_exit()is None and time.monotonic()<end:time.sleep(.005)
   exit_code=owner.leader_exit();timeout=exit_code is None
  survivors=owner.surviving_group();phase_failed |= survivors
  try:result=kernel_report(source/'spikes/input/evidence/kernel-debian.json')
  except (AssertionError,ValueError,OSError):result=None
 except Exception:
  phase_failed=True
 finally:
  cancellation.begin_cleanup()
  cleanup_deadline=min(run_end+5,time.monotonic()+5) if run_end else time.monotonic()+5
  # Every cleanup action is attempted even if an earlier step fails. No raw
  # exceptions escape this sequence or suppress restoration of old bytes.
  def stop_owned_process():
   nonlocal group_status,process
   try:
    if owner is None:return process is None
    process=owner.process
    group_status=owner.stop(cleanup_deadline,2)
    return all(group_status.values())
   finally:
    selector.close()
    if process is not None:
     for stream in (process.stdout,process.stderr):
      if stream:stream.close()
  def cleanup_marker():
   if marker_identity is None:return not MARKER.exists()
   m=MARKER.lstat()
   if not stat.S_ISREG(m.st_mode) or m.st_uid!=0 or (m.st_dev,m.st_ino)!=marker_identity:return False
   MARKER.unlink();return True
  def restore_supervisor():
   if replaced:
    if not safe_file(NATIVE/'linuxcast-input-spike-supervisor') or digest(NATIVE/'linuxcast-input-spike-supervisor')!=NEW or digest(backup)!=OLD['linuxcast-input-spike-supervisor']:return False
    copy_exclusive(backup,restore_temp,stat.S_IMODE(prior.st_mode),owned);os.chown(restore_temp,prior.st_uid,prior.st_gid);os.replace(restore_temp,NATIVE/'linuxcast-input-spike-supervisor')
   target=NATIVE/'linuxcast-input-spike-supervisor';m=target.lstat()
   return digest(target)==OLD['linuxcast-input-spike-supervisor'] and (m.st_uid,m.st_gid,stat.S_IMODE(m.st_mode))==(prior.st_uid,prior.st_gid,stat.S_IMODE(prior.st_mode))
  cleanup=cleanup_steps([('ownedProcessStopped',stop_owned_process),('exactMarkerCleanup',cleanup_marker),('oldSupervisorRestored',restore_supervisor),('ownedInstallTemporaryCleanup',lambda:unlink_owned(temp,owned)),('ownedRestoreTemporaryCleanup',lambda:unlink_owned(restore_temp,owned))])
  cleanup['ownedProcessGroupsAbsent']=(owner is None or owner.process is None) or group_status.get('ownedProcessGroupsAbsent',False) and group_status.get('ownedChildrenAbsent',False)
  try:cleanup.update(baseline())
  except Exception:cleanup['finalBaselineVerified']=False
  try:cleanup['markerAbsent']=not MARKER.exists()
  except Exception:cleanup['markerAbsent']=False
  try:cleanup['acceptedNativeArtifactsRestored']=all(digest(NATIVE/n)==h for n,h in OLD.items())
  except Exception:cleanup['acceptedNativeArtifactsRestored']=False
  try:cleanup['sourceHashesUnchanged']=all(digest(source/k)==v for k,v in manifest.items() if k!='spikes/input/evidence/kernel-debian.json')
  except Exception:cleanup['sourceHashesUnchanged']=False
  try:cleanup['ownedBackupCleanup']=cleanup['oldSupervisorRestored'] and unlink_owned(backup,owned)
  except Exception:cleanup['ownedBackupCleanup']=False
  if process is not None and exit_code is None:exit_code=process.returncode
  cleanup['withinCleanupBudget']=time.monotonic()<=cleanup_deadline
  if result is None:
   try:result=kernel_report(source/'spikes/input/evidence/kernel-debian.json')
   except (AssertionError,ValueError,OSError):pass
 text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',buffers['stdout'].decode(errors='replace'))
 named_summary=bool(re.search(r'Test Files\s+2 passed\s+\(2\)',text) and re.search(r'Tests\s+2 passed\s+\(2\)',text))
 complete=not phase_failed and exit_code==0 and not(timeout or bounds) and named_summary and result is not None and result['exitCode']==0 and result['report']['status']=='PASSED' and len(result['report']['results'])==14 and all(cleanup.values())
 output={'schemaVersion':1,'task':'S0-03','outcome':'ACTUAL_MAPPED_SYNTHETIC_REGRESSION' if complete else 'ACTUAL_SYNTHETIC_REGRESSION_INCOMPLETE','complete':complete,'elapsedMs':round((time.monotonic()-started)*1000,3),'exitCode':exit_code,'phaseFailed':phase_failed,'survivingGroupDetected':survivors,'outerTimeout':timeout,'boundsRejected':bounds,'mappedTestsPassed':2 if named_summary else None,'kernel':result,'cleanup':cleanup,'physicalHardwareProof':False,'liveInputEnforcementEstablished':False,'ac01Complete':False,'ac02Complete':False}
 print(json.dumps(output))
if __name__=='__main__':
 try:main()
 except Exception:
  print('{"schemaVersion":1,"task":"S0-03","outcome":"KERNEL_WRAPPER_INCOMPLETE","code":"FIXED_SYNTHETIC_GATE_FAILED","complete":false}');sys.exit(3)
