"""Harmless offline schema/cleanup tests: no guest/input execution; harmless local child fixtures only."""
import copy,hashlib,importlib.util,json,os,pathlib,tempfile

def module(name):
 p=pathlib.Path('/tmp/linuxcast-s003-denial-'+name+'.py');spec=importlib.util.spec_from_file_location('test_'+name,p);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
guest=module('guest');kernel=module('kernel');control=module('control')
rows=[{'phase':guest.PHASE[i>=10],'evidenceVeto':'PENDING' if i==0 else 'REMOTE' if i<12 else 'PEER_DEAD','decisionVeto':'PENDING' if i==0 else 'REMOTE','canArm':False,'workerArmEmitted':False} for i in range(20)]
encoded=lambda value:b''.join(json.dumps(x).encode()+b'\n' for x in value)
assert guest.validate_rows(encoded(rows))==(rows,False) and guest.valid_success(rows)
for index,key,value in [(0,'canArm',True),(3,'extraPrivateCanary','PrivateCanary'),(4,'evidenceVeto','ALLOW')]:
 bad=copy.deepcopy(rows);bad[index][key]=value;safe,rejected=guest.validate_rows(encoded(bad));assert rejected and len(safe)==index
bad=copy.deepcopy(rows);bad[1]['decisionVeto']='PENDING';assert not guest.valid_success(bad)
bad=copy.deepcopy(rows);bad[12]['evidenceVeto']='REMOTE';assert not guest.valid_success(bad)
assert guest.validate_rows(b'X'*513)[1] and guest.validate_rows(encoded(rows)+encoded(rows[:1]))[1]
for bad in [b'{"component":"DENIAL_PROBE","stage":"STARTUP","code":"PrivateCanary","io_kind":null,"errno":null}',b'{"private":"PrivateCanary"}']:
 try:guest.diagnostics(bad)
 except AssertionError:pass
 else:raise AssertionError()
value={'schemaVersion':1,'task':'S0-03','outcome':'ACTUAL_NEGATIVE_DECISION_CONSUMPTION','runtime':{'distribution':'Debian','debianVersion':'13.7','architecture':'x86_64','kernel':'6.12.113+deb13-amd64','libsystemdVersion':'257.13-1~deb13u1','selfType':'tty','stdinIsTty':False},'elapsedMs':5000,'exitCode':0,'outerTimeout':False,'boundsRejected':False,'schemaRejected':False,'stdoutBytes':len(encoded(rows)),'stderrBytes':0,'rows':rows,'diagnostics':[],'wrapperReaped':True,'ownedProcessGroupAbsent':True,'survivingGroupDetected':False,'observerTemporaryPathsAbsent':True,'binaryHashesAfter':guest.EXPECTED,'complete':True,'inputOperationsPerformed':False,'supervisorLiveEnforcementEstablished':False,'ac01Complete':False,'ac02Complete':False}
control.validate_capture(value,False)
for mutate in ('privateMetadata','wrongTransport','latePending','cleanupFailure','overDeadline'):
 bad=copy.deepcopy(value)
 if mutate=='privateMetadata':bad['runtime']['sessionId']='PrivateCanary'
 elif mutate=='wrongTransport':bad['runtime']['stdinIsTty']=True
 elif mutate=='latePending':bad['rows'][1]['decisionVeto']='PENDING'
 elif mutate=='cleanupFailure':bad['ownedProcessGroupAbsent']=False
 else:bad['elapsedMs']=8001
 try:control.validate_capture(bad,False)
 except AssertionError:pass
 else:raise AssertionError()
# Failing process wait and marker validation cannot suppress later restoration.
for failure in ('ownedProcessStopped','exactMarkerCleanup'):
 calls=[]
 def step(name):
  def run():
   calls.append(name)
   if name==failure:raise TimeoutError() if name=='ownedProcessStopped' else AssertionError()
   return True
  return run
 names=('ownedProcessStopped','exactMarkerCleanup','oldSupervisorRestored','ownedInstallTemporaryCleanup','ownedRestoreTemporaryCleanup')
 result=kernel.cleanup_steps([(n,step(n)) for n in names]);assert calls==list(names) and result[failure]is False and result['oldSupervisorRestored']is True
with tempfile.TemporaryDirectory(prefix='linuxcast-denial-offline-') as directory:
 root=pathlib.Path(directory);source=root/'source';source.write_bytes(b'PublicFixture');existing=root/'unowned';existing.write_bytes(b'UnrelatedPublicFixture');owned={}
 try:kernel.copy_exclusive(source,existing,0o500,owned)
 except FileExistsError:pass
 else:raise AssertionError()
 assert owned=={} and kernel.unlink_owned(existing,owned) and existing.read_bytes()==b'UnrelatedPublicFixture'
 target=root/'owned';target.write_bytes(b'OwnedFixture');old=target.open('rb');m=target.lstat();owned[str(target)]=(m.st_dev,m.st_ino)
 target.unlink();target.write_bytes(b'ReplacementFixture');assert not kernel.unlink_owned(target,owned) and target.read_bytes()==b'ReplacementFixture';old.close()
 target.unlink();target.write_bytes(b'OwnedFixture');m=target.lstat();owned[str(target)]=(m.st_dev,m.st_ino);assert kernel.unlink_owned(target,owned) and not target.exists()
 # The archive consists only of known tracked public runner/source files.
 manifest=control.mapped_archive(root/'source.tar');assert 'spikes/input/kernel.security.test.ts' in manifest and 'spikes/input/plugin-socket.security.test.ts' in manifest
 # Predictable collisions (including symlinks) cannot overwrite another file.
 victim=root/'private-canary';victim.write_bytes(b'PrivateCanary');collision=root/'collision.tar';collision.symlink_to(victim)
 try:control.mapped_archive(collision)
 except FileExistsError:pass
 else:raise AssertionError()
 assert victim.read_bytes()==b'PrivateCanary' and collision.is_symlink()
 # Correct S002 prefix includes the actual mkdtemp roots, without reading them.
 baseline=module('baseline');assert "'linuxcast-s002-*'" in baseline.CODE and "'linuxcast-s002-native-*'" not in baseline.CODE
 standin=root/'linuxcast-s002-standin';standin.mkdir();assert any(root.glob('linuxcast-s002-*'))
for line in pathlib.Path('/tmp/linuxcast-s003-denial-files.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);assert hashlib.sha256((pathlib.Path('/tmp/linuxcast-s0-03')/name).read_bytes()).hexdigest()==expected
# Real harmless process-family faults, no guest or device/bus operations.
owned_module=module('owned-group')
import subprocess,sys,time
child_code="""import os,signal,time
for detached in (False,True):
 pid=os.fork()
 if pid==0:
  if detached:os.setsid()
  signal.signal(signal.SIGTERM,signal.SIG_IGN)
  while True:signal.pause()
print('READY',flush=True)
os._exit(0)
"""
for reaped in (False,True):
 owner=owned_module.OwnedExperiment()
 process=owner.start([sys.executable,'-c',child_code],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env={})
 try:
  assert process.stdout.readline()==b'READY\n'
  end=time.monotonic()+1
  while owner.leader_exit()is None and time.monotonic()<end:time.sleep(.005)
  assert owner.leader_exit()==0
  if reaped:assert process.wait(timeout=1)==0
  assert owner.surviving_group()
  result=owner.stop(time.monotonic()+1,.05)
  assert all(result.values())
 finally:
  result=owner.stop(time.monotonic()+1,0)
  process.stdout.close()
  assert all(result.values())
# Post-Popen capture failure must leave the internal handle available for finally.
for persistent in (False,True):
 owner=owned_module.OwnedExperiment();original=owned_module.os.pidfd_open;calls=[0]
 def failed_acquire(pid,flags):
  calls[0]+=1
  if persistent or calls[0]==1:raise OSError(24,'fixture')
  return original(pid,flags)
 owned_module.os.pidfd_open=failed_acquire
 try:
  try:owner.start([sys.executable,'-c','import signal;signal.pause()'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env={})
  except AssertionError:pass
  else:raise AssertionError()
  assert owner.process is not None
  result=owner.stop(time.monotonic()+1,.03)
  assert result['leaderReaped'] and result['ownedChildrenAbsent'] and result['ownedProcessGroupsAbsent'] and not result['signalOperationsSucceeded']
 finally:
  owned_module.os.pidfd_open=original
  owner.stop(time.monotonic()+1,0);owner.process.stdout.close()
# Later acquisition failure cannot prevent already-held pidfd cleanup.
owner=owned_module.OwnedExperiment();process=owner.start([sys.executable,'-c',child_code],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env={})
assert process.stdout.readline()==b'READY\n'
original=owned_module.os.pidfd_open
owned_module.os.pidfd_open=lambda *args:(_ for _ in ()).throw(OSError(24,'fixture'))
try:
 result=owner.stop(time.monotonic()+1,.03)
 assert result['leaderReaped'] and result['ownedChildrenAbsent'] and result['ownedProcessGroupsAbsent'] and not result['signalOperationsSucceeded']
finally:
 owned_module.os.pidfd_open=original;owner.stop(time.monotonic()+1,0);process.stdout.close()
# Ordinary cancellation restores harmless stand-ins despite repeated signals.
with tempfile.TemporaryDirectory(prefix='linuxcast-denial-cancel-fixture-') as directory:
 root=pathlib.Path(directory);target=root/'supervisor';target.write_bytes(b'AcceptedFixture');marker=root/'marker'
 code="""import importlib.util,json,pathlib,signal,sys,time
spec=importlib.util.spec_from_file_location('fixed_kernel','/tmp/linuxcast-s003-denial-kernel.py');kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
target=pathlib.Path(sys.argv[1]);marker=pathlib.Path(sys.argv[2]);guard=kernel.CancellationGuard();prior=target.read_bytes()
try:
 target.write_bytes(b'RefactoredFixture');marker.write_bytes(b'FixtureMarker');print('READY',flush=True)
 while True:signal.pause()
except kernel.OrdinaryCancellation:pass
finally:
 guard.begin_cleanup()
 def remove():
  time.sleep(.03);marker.unlink();return True
 def restore():target.write_bytes(prior);return target.read_bytes()==prior
 result=kernel.cleanup_steps([('markerRemoved',remove),('oldBytesRestored',restore)])
 print(json.dumps(result),flush=True)
"""
 for number in (owned_module.signal.SIGTERM,owned_module.signal.SIGHUP,owned_module.signal.SIGINT):
  process=subprocess.Popen([sys.executable,'-c',code,str(target),str(marker)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={})
  try:
   assert process.stdout.readline()==b'READY\n';process.send_signal(number);time.sleep(.005);process.send_signal(number)
   out,err=process.communicate(timeout=1);assert process.returncode==0 and not err and json.loads(out)=={'markerRemoved':True,'oldBytesRestored':True}
   assert target.read_bytes()==b'AcceptedFixture' and not marker.exists()
  finally:
   if process.poll()is None:process.kill();process.wait(timeout=1)
# Exact guarded spawn restores the pre-critical child signal mask before exec.
code="""import importlib.util,json,signal,subprocess,sys,time
spec=importlib.util.spec_from_file_location('fixed_kernel','/tmp/linuxcast-s003-denial-kernel.py');kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
guard=kernel.CancellationGuard();owner=kernel.OwnedExperiment()
child="import json,signal;mask=signal.pthread_sigmask(signal.SIG_BLOCK,set());print(json.dumps({'ordinarySignalsBlocked':bool(mask&{signal.SIGTERM,signal.SIGHUP,signal.SIGINT})}),flush=True);signal.pause()"
p=guard.start_owned(owner,[sys.executable,'-c',child],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={})
try:
 assert json.loads(p.stdout.readline())=={'ordinarySignalsBlocked':False}
 owner._signal(signal.SIGTERM);end=time.monotonic()+.5
 while owner.leader_exit()is None and time.monotonic()<end:time.sleep(.005)
 assert owner.leader_exit()==-signal.SIGTERM
 result=owner.stop(time.monotonic()+.5,.02);assert all(result.values())
 print('{"childMaskRestored":true,"ordinaryTermWorked":true}',flush=True)
finally:
 guard.begin_cleanup();owner.stop(time.monotonic()+.5,0);p.stdout.close();p.stderr.close()
"""
result=subprocess.run([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={},timeout=2)
assert result.returncode==0 and not result.stderr and json.loads(result.stdout)=={'childMaskRestored':True,'ordinaryTermWorked':True}
print('{"offlineSchemaChecks":true,"cleanupFailuresDoNotSuppressRestoration":true,"unownedTemporaryPreserved":true,"replacedInodePreserved":true,"ownedTemporaryRemoved":true,"trackedMappedArchiveVerified":true,"frozen17FilesUnchanged":true,"exitedAndReapedLeaderOrphanGroupsCleaned":true,"partialSpawnAndLaterPidfdFailuresCleaned":true,"cancelledStandinsRestored":true,"symlinkArchiveCollisionPreserved":true,"actualS002PrefixRejected":true,"guardedChildSignalMaskRestored":true,"guestCalls":0,"inputOperations":0}')
