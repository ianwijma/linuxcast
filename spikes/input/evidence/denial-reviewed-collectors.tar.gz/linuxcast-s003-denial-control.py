"""Fixed disposable-lab orchestration. Each phase requires explicit root approval.
No automatic remediation/retry or probe invocation during preparation.
"""
import hashlib,importlib.util,io,json,os,pathlib,re,shlex,subprocess,sys,tarfile,tempfile,uuid
ROOT=pathlib.Path('/tmp/linuxcast-s0-03');STATE=pathlib.Path('/tmp/linuxcast-s003-denial-private-state.json')
HOST_SOURCES={'capture.py':pathlib.Path('/tmp/linuxcast-s003-denial-guest.py'),'runtime.py':pathlib.Path('/tmp/linuxcast-s003-denial-runtime.py'),'kernel.py':pathlib.Path('/tmp/linuxcast-s003-denial-kernel.py'),'owned_group.py':pathlib.Path('/tmp/linuxcast-s003-denial-owned-group.py')}
FILES={
'linuxcast-input-spike-denial-probe':(ROOT/'spikes/input/.target/debug/linuxcast-input-spike-denial-probe','b6c526b5bb853cab416b27bea36c0b216c2cd11bd946de266dc7e301eef7b7d4'),
'linuxcast-input-spike-denial-helper':(ROOT/'spikes/input/.target/debug/linuxcast-input-spike-denial-helper','f0e96dbc18b9a2726b52f3a80ad9b0b6f8e2973146d849a48c2d90f563b1a9e2'),
'refactored-supervisor':(ROOT/'spikes/input/.target/debug/linuxcast-input-spike-supervisor','2e959061d64eff7e2e051cc8ec402d0270512a9dd8bc1cbbd184675604d9953d'),
'node-runtime':(pathlib.Path('/tmp/linuxcast-node24/node'),'e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'),
'bun-runtime':(pathlib.Path('/tmp/linuxcast-bun144/bun-linux-x64/bun'),'10702245766b225e70bbf6235fd6b47214fd94b4760d00ffaed8ab0df57ac235')}
SSH=['docker','exec','linuxcast-s0-04-vm','ssh','-q','-i','/lab/test-key','-p','2222','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/lab/known_hosts']
TARGET='debian@127.0.0.1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fixed(args,timeout=45):
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 assert r.returncode==0 and not r.stderr and len(r.stdout)<=100000
 return r.stdout

def remote(code,pty=False,root=False,timeout=30):
 return json.loads(fixed(SSH+['-tt' if pty else '-T',TARGET,('sudo -n ' if root else '')+'python3 -c '+shlex.quote(code)],timeout))
def store(value):
 if STATE.exists():
  m=STATE.lstat();assert m.st_uid==os.getuid() and m.st_mode&0o777==0o600
 fd=os.open(STATE,os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
 try:os.ftruncate(fd,0);os.write(fd,json.dumps(value).encode());os.fsync(fd)
 finally:os.close(fd)
def load():
 m=STATE.lstat();assert m.st_uid==os.getuid() and m.st_mode&0o777==0o600
 s=json.loads(STATE.read_text());assert re.fullmatch('/tmp/linuxcast-s003-denial-stage-[A-Za-z0-9_]+',s['stage'])
 return s
def verify_frozen():
 for line in pathlib.Path('/tmp/linuxcast-s003-denial-files.sha256').read_text().splitlines():
  expected,name=line.split('  ',1);assert sha(ROOT/name)==expected
 for p,expected in FILES.values():assert sha(p)==expected
 # The coordinator verifies this manifest's external hash before any phase.
 for line in pathlib.Path('/tmp/linuxcast-s003-denial-collectors.sha256').read_text().splitlines():
  expected,name=line.split('  ',1);assert sha(pathlib.Path(name))==expected

def prepare():
 assert not STATE.exists();verify_frozen()
 # Preparation creates only a private source/binary stage, never executes it.
 value=remote("import tempfile,os,json; p=tempfile.mkdtemp(prefix='linuxcast-s003-denial-stage-');os.chmod(p,0o700);print(json.dumps({'stage':p}))")
 assert set(value)=={'stage'} and re.fullmatch('/tmp/linuxcast-s003-denial-stage-[A-Za-z0-9_]+',value['stage'])
 state={'stage':value['stage'],'nonce':uuid.uuid4().hex,'containerFiles':[],'runtimeInstalled':False,'sshComplete':False,'ptyComplete':False,'kernelRun':False,'sourceHashes':{},'binaryHashes':{}};store(state)
 for name,path in HOST_SOURCES.items():transfer(state,path,name,sha(path),0o600);state['sourceHashes'][name]=sha(path);store(state)
 for name,(path,expected) in FILES.items():transfer(state,path,name,expected,0o500);state['binaryHashes'][name]=expected;store(state)
 print('{"operation":"PREPARE_OWNED_CAPTURE_STAGE","complete":true,"programsExecuted":false}')
def transfer(state,path,name,expected,mode,target_stage=None):
 target_stage=target_stage or state["stage"]
 assert re.fullmatch('[A-Za-z0-9_.-]+',name) and sha(path)==expected
 lab='/lab/linuxcast-s003-denial-'+state['nonce']+'-'+uuid.uuid4().hex+'-'+name
 fixed(['docker','exec','linuxcast-s0-04-vm','test','!','-e',lab]);state['containerFiles'].append(lab);store(state)
 fixed(['docker','cp',str(path),'linuxcast-s0-04-vm:'+lab])
 fixed(['docker','exec','linuxcast-s0-04-vm','scp','-q','-i','/lab/test-key','-P','2222','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/lab/known_hosts',lab,TARGET+':'+target_stage+'/'+name])
 code="import os,pathlib,hashlib,json; p=pathlib.Path("+repr(target_stage+'/'+name)+");assert p.lstat().st_uid==os.getuid() and p.is_file() and not p.is_symlink();assert hashlib.sha256(p.read_bytes()).hexdigest()=="+repr(expected)+";os.chmod(p,"+repr(mode)+");print(json.dumps({'verified':True}))"
 assert remote(code)=={'verified':True}
 fixed(['docker','exec','linuxcast-s0-04-vm','rm','--',lab]);state['containerFiles'].remove(lab);store(state)

def run_staged(state,name,argument,pty=False,root=False,timeout=30,target_stage=None):
 assert name in state['sourceHashes']
 path=(target_stage or state['stage'])+'/'+name
 checks=""
 if name in ('capture.py','kernel.py'):
  helper_path=str(pathlib.Path(path).with_name('owned_group.py'))
  checks="h=pathlib.Path("+repr(helper_path)+");assert h.is_file() and not h.is_symlink() and hashlib.sha256(h.read_bytes()).hexdigest()=="+repr(state['sourceHashes']['owned_group.py'])+";"
 code="import pathlib,hashlib,os; p=pathlib.Path("+repr(path)+");assert not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()=="+repr(state['sourceHashes'][name])+";"+checks+"os.execv('/usr/bin/python3',['python3',str(p),"+repr(argument)+"])"

 return remote(code,pty=pty,root=root,timeout=timeout)

def install_runtime(state):
 assert not state['runtimeInstalled'] and not state['sshComplete'] and not state['ptyComplete']
 state['runtimeAttempted']=True;store(state)
 result=run_staged(state,'runtime.py','--install-missing');assert result=={'operation':'CREATE_MISSING_PINNED_RUNTIME','complete':True,'priorRuntimeObjectsReplaced':False,'nodeHashMatches':True,'bunHashMatches':True}
 state['runtimeInstalled']=True;store(state)
 print(json.dumps(result))

def capture(state,pty):
 assert state['runtimeInstalled'] and not state['kernelRun'] and not state['ptyComplete'] and (state['sshComplete'] if pty else not state['sshComplete'])
 # Exactly one attempt per transport; persisted BEFORE launch, including failure.
 key='ptyAttempted' if pty else 'sshAttempted';assert not state.get(key);state[key]=True;store(state)
 capsule=remote("import tempfile,os,json; p=tempfile.mkdtemp(prefix='linuxcast-s003-denial-stage-');os.chmod(p,0o700);print(json.dumps({'stage':p}))")['stage']
 assert re.fullmatch('/tmp/linuxcast-s003-denial-stage-[A-Za-z0-9_]+',capsule)
 state.setdefault('captureStages',[]).append(capsule);store(state)
 transfer(state,HOST_SOURCES['capture.py'],'capture.py',state['sourceHashes']['capture.py'],0o600,capsule)
 transfer(state,HOST_SOURCES['owned_group.py'],'owned_group.py',state['sourceHashes']['owned_group.py'],0o600,capsule)
 for name in ('linuxcast-input-spike-denial-probe','linuxcast-input-spike-denial-helper'):
  path,expected=FILES[name];transfer(state,path,name,expected,0o500,capsule)
 result={'schemaVersion':1,'task':'S0-03','outcome':'CAPTURE_PLUMBING_INCOMPLETE','code':'FIXED_CAPTURE_FAILED','complete':False}
 try:
  candidate=run_staged(state,'capture.py','--capture-denial',pty=pty,timeout=16,target_stage=capsule)
  validate_capture(candidate,pty)
  result=candidate
 except Exception:pass
 cleanup_ok=False
 try:remove_capture_stage(state,capsule);cleanup_ok=True
 except Exception:pass
 complete=result['complete'] and cleanup_ok
 artifact={'sourceDiffSha256':'d83d44dd8d096cbd59cc9e91867ee042ff647605ad22031bd05c3df3b82b3892','transport':'SSH_ALLOCATED_PTY' if pty else 'SSH_NO_PTY','observation':result,'captureStageRemoved':cleanup_ok,'complete':complete}
 path=ROOT/('spikes/input/evidence/denial-guest-'+('pty' if pty else 'ssh')+'.json');assert not path.exists();path.write_text(json.dumps(artifact,indent=2)+'\n')
 if complete:state['ptyComplete' if pty else 'sshComplete']=True;store(state)
 print(json.dumps({'operation':'FIXED_DENIAL_CAPTURE','complete':complete,'artifactSha256':sha(path)}))
 if not complete:sys.exit(3)

def validate_capture(result,pty):
 keys={'schemaVersion','task','outcome','runtime','elapsedMs','exitCode','outerTimeout','boundsRejected','schemaRejected','stdoutBytes','stderrBytes','rows','diagnostics','wrapperReaped','ownedProcessGroupAbsent','survivingGroupDetected','observerTemporaryPathsAbsent','binaryHashesAfter','complete','inputOperationsPerformed','supervisorLiveEnforcementEstablished','ac01Complete','ac02Complete'}
 if set(result)!=keys:
  assert result=={'schemaVersion':1,'task':'S0-03','outcome':'CAPTURE_PLUMBING_INCOMPLETE','code':'FIXED_CAPTURE_FAILED','complete':False};return
 assert result['schemaVersion']==1 and result['task']=='S0-03' and result['outcome'] in ('ACTUAL_NEGATIVE_DECISION_CONSUMPTION','ACTUAL_DENIAL_CAPTURE_INCOMPLETE')
 spec=importlib.util.spec_from_file_location('denial_capture_schema',HOST_SOURCES['capture.py']);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 data=b''.join(json.dumps(row).encode()+b'\n' for row in result['rows']);rows,rejected=module.validate_rows(data);assert not rejected and rows==result['rows']
 runtime=result['runtime'];assert set(runtime)=={'distribution','debianVersion','architecture','kernel','libsystemdVersion','selfType','stdinIsTty'}
 assert runtime['distribution']=='Debian' and runtime['debianVersion']=='13.7' and runtime['architecture']=='x86_64' and runtime['kernel']=='6.12.113+deb13-amd64' and runtime['libsystemdVersion']=='257.13-1~deb13u1' and runtime['selfType'] in ('tty','x11','wayland','unspecified') and runtime['stdinIsTty']is pty
 assert result['binaryHashesAfter']==module.EXPECTED and type(result['elapsedMs']) in (int,float) and 0<=result['elapsedMs']<60000
 assert result['exitCode']is None or type(result['exitCode'])is int and -128<=result['exitCode']<=255
 for key in keys-{'schemaVersion','task','outcome','runtime','elapsedMs','exitCode','stdoutBytes','stderrBytes','rows','diagnostics','binaryHashesAfter'}:assert type(result[key])is bool
 assert type(result['stdoutBytes'])is int and 0<=result['stdoutBytes']<=14356 and type(result['stderrBytes'])is int and 0<=result['stderrBytes']<=4480
 assert not any(result[k] for k in ('inputOperationsPerformed','supervisorLiveEnforcementEstablished','ac01Complete','ac02Complete'))
 assert module.diagnostics(b''.join(json.dumps(x).encode()+b'\n' for x in result['diagnostics']))==result['diagnostics']
 if result['complete']:
  assert result['outcome']=='ACTUAL_NEGATIVE_DECISION_CONSUMPTION' and result['exitCode']==0 and result['elapsedMs']<=8000 and not result['outerTimeout'] and not result['boundsRejected'] and not result['schemaRejected'] and not result['survivingGroupDetected'] and not result['diagnostics'] and result['stderrBytes']==0 and result['stdoutBytes']<=10260 and all(result[k] for k in ('wrapperReaped','ownedProcessGroupAbsent','observerTemporaryPathsAbsent')) and runtime['selfType']=='tty' and module.valid_success(rows)

def remove_capture_stage(state,path):
 assert path in state.get('captureStages',[])
 code="""import os,pathlib,shutil,stat,json
p=pathlib.Path(STAGE);m=p.lstat();assert p.parent==pathlib.Path('/tmp') and p.name.startswith('linuxcast-s003-denial-stage-') and stat.S_ISDIR(m.st_mode) and m.st_uid==os.getuid() and stat.S_IMODE(m.st_mode)==0o700
for proc in pathlib.Path('/proc').iterdir():
 if proc.name.isdigit():
  try:exe=os.readlink(proc/'exe')
  except OSError:continue
  assert not exe.startswith(str(p)+'/')
shutil.rmtree(p);print(json.dumps({'captureStageRemoved':not p.exists()}))
"""
 assert remote('STAGE='+repr(path)+'\n'+code)=={'captureStageRemoved':True}
 state['captureStages'].remove(path);store(state)

def mapped_archive(destination):
 manifest=json.loads((ROOT/'scripts/test-runner/suites.json').read_text())
 paths={'package.json','bun.lock','tsconfig.base.json','docs/implementation/tasks.json','spikes/sandbox/supervisor.ts','spikes/sandbox/protocol.ts','spikes/sandbox/seccomp.c','spikes/sandbox/task-pressure.c','spikes/sandbox/fixtures/extension.mjs'}
 paths.update(subprocess.check_output(['git','ls-files','scripts/test-runner'],cwd=ROOT,text=True).splitlines())
 paths.update(p for suite in manifest.values() for files in suite.values() for p in files)
 hashes={}
 fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as output,tarfile.open(fileobj=output,mode='w') as tar:
  for path in sorted(paths):
   assert not path.startswith('/') and '..' not in pathlib.PurePosixPath(path).parts
   data=(ROOT/path).read_bytes()
   if path!='docs/implementation/tasks.json':assert data==subprocess.check_output(['git','show','HEAD:'+path],cwd=ROOT)
   info=tarfile.TarInfo(path);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));hashes[path]=hashlib.sha256(data).hexdigest()
 return hashes

PREPARE_SOURCE=r'''
import hashlib,json,os,pathlib,shutil,stat,tarfile
stage=pathlib.Path(STAGE);assert stage.lstat().st_uid==os.getuid()!=0 and stat.S_IMODE(stage.stat().st_mode)==0o700
source=stage/'source';assert not source.exists();source.mkdir(mode=0o700)
with tarfile.open(stage/'mapped-source.tar') as tar:
 for item in tar.getmembers():
  assert item.isfile() and not pathlib.PurePosixPath(item.name).is_absolute() and '..' not in pathlib.PurePosixPath(item.name).parts
 tar.extractall(source,filter='data')
original=pathlib.Path('/home/debian/linuxcast-input-source/node_modules');assert original.is_dir() and not original.is_symlink()
for name,version in [('vitest','4.1.12'),('vite','7.3.7'),('typescript','6.0.3')]:assert json.loads((original/name/'package.json').read_text())['version']==version
shutil.copytree(original,source/'node_modules',symlinks=True,ignore=shutil.ignore_patterns('.vite','.cache'))
for p in (source/'node_modules').rglob('*'):
 if p.is_symlink():assert not os.path.isabs(os.readlink(p)) and p.resolve().is_relative_to(source)
manifest=MANIFEST
for p in (source/'node_modules').rglob('*'):
 if p.is_file() and not p.is_symlink():manifest[str(p.relative_to(source))]=hashlib.sha256(p.read_bytes()).hexdigest()
assert all(hashlib.sha256((source/k).read_bytes()).hexdigest()==h for k,h in manifest.items())
(source/'spikes/input/evidence').mkdir(mode=0o700)
fd=os.open(stage/'kernel-source-manifest.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
try:os.write(fd,json.dumps(manifest).encode())
finally:os.close(fd)
print(json.dumps({'sourcePrepared':True,'sourceFileCount':len(manifest),'manifestSha256':hashlib.sha256((stage/'kernel-source-manifest.json').read_bytes()).hexdigest()}))
'''
def kernel_prepare(state):
 assert state['sshComplete'] and state['ptyComplete'] and not state.get('kernelPrepared') and not state['kernelRun']
 # All local transfer artifacts are beneath a fresh owned 0700 directory.
 with tempfile.TemporaryDirectory(prefix='linuxcast-s003-denial-controller-') as local:
  directory=pathlib.Path(local);assert directory.stat().st_mode&0o777==0o700
  archive=directory/'mapped-source.tar';hashes=mapped_archive(archive);transfer(state,archive,'mapped-source.tar',sha(archive),0o600)
  result=remote('STAGE='+repr(state['stage'])+'\nMANIFEST='+repr(hashes)+'\n'+PREPARE_SOURCE,timeout=60)
  assert set(result)=={'sourcePrepared','sourceFileCount','manifestSha256'} and result['sourcePrepared']is True
  for mode in ('ssh','pty'):
   path=ROOT/('spikes/input/evidence/denial-guest-'+mode+'.json');value=json.loads(path.read_text())['observation'];assert value['complete']is True
   temp=directory/('denial-'+mode+'-passed.json')
   with temp.open('x') as output:json.dump(value,output)
   transfer(state,temp,'denial-'+mode+'-passed.json',sha(temp),0o600)
 state['kernelPrepared']=True;state['kernelSourceManifestSha256']=result['manifestSha256'];store(state);print(json.dumps(result))
def kernel_run(state):
 assert state['kernelPrepared'] and state['sshComplete'] and state['ptyComplete'] and not state['kernelRun']
 state['kernelRun']=True;store(state)
 result=run_staged(state,'kernel.py','--run-mapped-synthetic-gate',root=True,timeout=210)
 assert result.get('task')=='S0-03' and type(result.get('complete'))is bool
 state['kernelCleanupComplete']=type(result.get('cleanup'))is dict and bool(result['cleanup']) and all(v is True for v in result['cleanup'].values());store(state)
 path=ROOT/'spikes/input/evidence/denial-kernel-regression.json';assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'operation':'FIXED_MAPPED_SYNTHETIC_REGRESSION','complete':result['complete'],'artifactSha256':sha(path)}))
 if not result['complete']:sys.exit(3)
def release(state):
 # Cleanup runs even after an incomplete capture; no automatic second attempt.
 assert not state['kernelRun'] or state.get('kernelCleanupComplete')is True
 for capsule in list(state.get('captureStages',[])):remove_capture_stage(state,capsule)
 journal=remote("import pathlib,json;print(json.dumps({'present':(pathlib.Path("+repr(state['stage'])+")/'runtime-journal.json').exists()}))")
 if journal=={'present':True}:
  result=run_staged(state,'runtime.py','--cleanup-created');assert result=={'operation':'REMOVE_CREATED_PINNED_RUNTIME','complete':True,'originalAllMissingStateRestored':True}
 code="import pathlib,shutil,stat,json; p=pathlib.Path("+repr(state['stage'])+");m=p.lstat();assert p.parent==pathlib.Path('/tmp') and p.name.startswith('linuxcast-s003-denial-stage-') and stat.S_ISDIR(m.st_mode) and m.st_uid==1000 and stat.S_IMODE(m.st_mode)==0o700;assert not pathlib.Path('/run/linuxcast-input-spike-lab').exists();shutil.rmtree(p);print(json.dumps({'ownedStageRemoved':not p.exists()}))"
 assert remote(code,root=True)=={'ownedStageRemoved':True}
 for name in state['containerFiles']:
  assert name.startswith('/lab/linuxcast-s003-denial-'+state['nonce']+'-');fixed(['docker','exec','linuxcast-s0-04-vm','rm','-f','--',name])
 STATE.unlink()
 print('{"operation":"OWNED_STAGE_AND_RUNTIME_RELEASE","complete":true}')
def main():
 assert len(sys.argv)==2 and sys.argv[1] in ('prepare','install-runtime','capture-ssh','capture-pty','kernel-prepare','kernel-run','release')
 verify_frozen()
 if sys.argv[1]=='prepare':prepare();return
 state=load()
 {'install-runtime':install_runtime,'capture-ssh':lambda s:capture(s,False),'capture-pty':lambda s:capture(s,True),'kernel-prepare':kernel_prepare,'kernel-run':kernel_run,'release':release}[sys.argv[1]](state)
if __name__=='__main__':
 try:main()
 except Exception:
  print('{"operation":"FIXED_LAB_ORCHESTRATION","complete":false,"code":"PHASE_INCOMPLETE_STOP_NO_RETRY"}');sys.exit(3)
