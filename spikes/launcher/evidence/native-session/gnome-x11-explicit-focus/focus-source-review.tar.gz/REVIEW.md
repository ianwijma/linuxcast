# S0-01 X11 normal focus candidate — source only

Exactly3owned source/test/docs paths over f0596621. Current HEADf09aef6 is a coordinator evidence-only advance; no rebase/reset occurred. Native candidate execution UNEXECUTED. No guest, host display, source-archive/collector preparation, staging, signing, push or acceptance status action occurred. Earlier readiness artifacts and public archives remain immutable.

Only main.applyCommand adds X11 conditional restore-before-existing-Show and one explicit focus immediately after Show. Wayland/unknown receive neither minimized query nor restore/focus. Visible toggle still only hides; quit/unready/destroyed/null/reload paths remain intact. Snapshot/capabilities use actual native isFocused; refusal stays false/unavailable. No timer, loop, app.focus, observer launcher activation, additional wait, retry or native-predicate weakening.

Pinned Electron45 singleton example recommends conditionalrestore/focus, but docs and native_window_views.cc show that Show already calls widget activation. This normal policy candidate may be redundant and does not prove cause/fix. Primary references are recorded in the owned README. Design Shell/navigation, Accessibility and Reviewgate apply; canonical layout/tokens unchanged. Native compositor and actual keyboard/accessibility/affected-state checks remain required before acceptance.

The exact production applyCommand AND actual state-snapshot functions are type-only stripped into an isolated VM with synthetic window spies/traps. Tests assert actual call order and once-per-request behavior across hidden/visible/minimized Show/toggle, X11-hide/Wayland/unknown branches, one-time renderer recovery, refusedfocusfalse vs synthetic acceptedfocus, quit/unready/destroyed/null noactivation. No Electron or native display is imported by those fixtures.

Configured Node24.22.1/Vitest unit21+UIfixture3+nativepreparation178=202/202 PASS6.18s on Pop!_OS22.04 amd64. Strict root TypeScript, affectedTS lint, planning validator and diffcheck PASS. No new native success, screenshot, screen-reader or criterion completion claim. Future real-host/native tests require separate review and authority.
